     <?php $thisPage="careers"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="products-banner">
          <p class="title">
          <span class="">YOU DON’T JUST WORK AT BLACKBUCK. YOU ARE ON A JOURNEY.</span>
          INVITING YOU ON <br/>AN EXTRAORDINARY JOURNEY.</p>
        </div>
      </div>
    </section>
    <section class="section2">
      <div class="container">
        <div class="content">
          <p>Enter BlackBuck and you meet a bunch of highly energetic, imaginative and aspirational individuals who are making a meaningful contribution to the future of freight. Our teams work in a collaborative and collective intelligence culture to deliver infinite value to shippers and fleet operators, with the efficiency of cutting-edge technology. Here you get to own what you do - from conception to execution and delivery. </p>
          <p>At BlackBuck, each day you get the opportunity to create something that can go beyond centuries. And guess what, we have a truck load of opportunities in this journey. Be a part of our journey and take an exciting route to your career development.</p>
          <a href="#positions" class="btn btn-sub">View Open Positions</a>

        </div>
      </div>
    </section>
    <section class="video-player">
      <div class="container">
        <div class="content">
          <button class="btn-play culture-video"> Play video</button>
        </div>
      </div>
    </section>
    <section class="open-positions" id="positions">

<h2>Open Positions</h2>

      <div class="container">
        <div class="dropdown-menu">
          <span class="current">Select position</span>
          <ul class="positions">
            <li>
              <buttons class="btn-pos active" rel="technology">Technology</buttons>
            </li>
            <li>
              <buttons class="btn-pos" rel="sales">Sales</buttons>
            </li>
            <li>
              <buttons class="btn-pos" rel="operations">Operations</buttons>
            </li>
            <li>
              <buttons class="btn-pos" rel="supply">Supply</buttons>
            </li>
          </ul>
          
        </div>
        <div class="pos-banners">
          <div class="pos-banner banner-technology active">
            <div class="row">
              <div class="col-sm-6">
                <div class="content">
                  <p class="txt"> Building technologies and enabling new user experiences that have real impact</p>
                  
                </div>
              </div>
              <div class="col-sm-6">
                <div class="media-content">

                </div>
              </div>
            </div>
          </div>
          <div class="pos-banner banner-sales">
            <div class="row">
              <div class="col-sm-6">
                <div class="content">
                  <p class="txt"> Accelerating business growth of our customers</p>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="media-content">
                </div>
              </div>
            </div>
          </div>
          <div class="pos-banner banner-supply">
            <div class="row ">
              <div class="col-sm-6">
                <div class="content">
                  <p class="txt"> Partnering with the Supply base to provide a delightful and hassle-free experience</p>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="media-content">
                  
                </div>
              </div>
            </div>
          </div>
          <div class="pos-banner banner-operations">
            <div class="row">
              <div class="col-sm-6">
                <div class="content">
                  <p class="txt">Being at forefront of operations innovation to make freight simple and seamless</p>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="media-content">
                  
                </div>
              </div>
            </div>
          </div>
        </div>
        <ul class="position-list">
          <li class="pos-technology pos-all">
            <div class="head">
              <h4>SDE III </h4>
              <div class="overview">Bangalore | Full-time | 2 positions </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Actively drive discussions to improve product across engineering teams, wherever there are inter dependencies across products</li>
                <li>Influence product requirements & operational plans while working with product manager to estimate and plan projects in agile development framework</li>
                <li>Instil best practices for development and champion their adoption, Mentor junior engineers on software design, coding practices and TDD strategies</li>
                <li>API Definitions and end-to-end service design and implementations</li>
                <li>Design applications in true service oriented architecture</li>
                <li>Develop object-oriented models and design data structure for new software projects taking systems aspects into account</li>
                <li>Participate and contribute in discussions and decisions for creating and improving architecture across applications.</li>
                <li>Make correct design choices in the context of problem for datastore, caching, search, scaling etc.</li>
                <li>Write good quality, modular, reusable, performant, well documented, unit-tested code, Identify the areas and approach to refactor and simplify the modules; refactor code to improve code quality and bring modularity and simplicity.</li>
                <li>Translate high level business problems into scalable design and code</li>
                <li>Create common libraries & Utilities to be used by multiple engineering teams</li>
              </ul>
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>BE or higher in Computer Science or related technical discipline (or equivalent)</li>
                <li>Minimum 5 years of experience in product based company</li>
                <li>Strong expertise in at least one programming language & tech stack for web development to write maintainable, scalable, unit-tested code</li>
                <li>Strong object oriented design skills, knowledge of design patterns, data structures and algorithms</li>
                <li>Strong expertise of working with relational and nosql databases</li>
                <li>Experience in building large complex business applications with only high level tech guidance</li>
                <li>Experience leading multi-engineer projects and mentoring junior engineers</li>
                <li>Experience with full life cycle development on a Linux/ubuntu platform</li>
                <li>Prior experience in working with Agile software methodologies (XP, Scrum)</li>
                <li>Knowledge of Test Driven Development</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-technology pos-all">
            <div class="head">
              <h4>PRINCIPAL ENGINEER </h4>
              <div class="overview">Bangalore | Full-time | 2 positions </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>High level of ownership and drive Technology and good software development practices in the team</li>
                <li>Fully own the systems/modules in your team and ensure their impact on other systems</li>
                <li>Developing modules and systems in team which reflect the best coding practices to showcase to and motivate other developers in team</li>
                <li>Continuously participate in coding, code reviews, design reviews, architecture discussions with other team members and ensure quality of team deliverables</li>
                <li>Drive and contribute in discussions and decisions for creating and improving architecture across applications and across teams</li>
                <li>Creating architecture of new products as well as improvement in the existing products. Should be able to propose/ evaluate multiple solutions for architectural problems and explain merits/demerits of each approach</li>
                <li>Own the choices of technologies, tools, libraries and ensure adaption of them</li>
              </ul>
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>BE/ B.Tech or higher in Computer Science (preferably)  or related technical discipline (or equivalent)</li>
                <li>Minimum of 8 years of experience in product based companies</li>
                <li>Strong expertise in more than one programming language & tech stack for web development</li>
                <li>Strong object oriented design skills, knowledge of design and architectural patterns, data structures and algorithms</li>
                <li>Strong expertise of working with large scale relational and nosql databases</li>
                <li>Experience in building solutions for various large scale and complex problems starting from inception to building complete production system, scaling the system and re-architecting the system as the requirement evolves further</li>
                <li>Experience leading multi-engineer projects and mentoring senior engineers</li>
                <li>Major part of experience should be working in start-ups or products evolving at a very fast pace and working with Agile software methodologies (XP, Scrum)</li>
                <li>Experienced in Test Driven Development for large size projects to be able to support continuous deployment</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-technology pos-all">
            <div class="head">
              <h4>DATA SCIENTIST </h4>
              <div class="overview">Bangalore | Full-time | 1 position </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Work with large, complex data sets. Solve difficult, non-routine analysis problems, applying advanced analytical methods as needed. Conduct end-to-end analysis that includes data gathering and requirements specification, processing, analysis, ongoing deliverables, and presentations</li>
                <li>Build and prototype analysis pipelines iteratively to provide insights at scale. Develop comprehensive understanding of metrics, advocating for changes where needed for products development</li>
                <li>Interact cross-functionally with a wide variety of people and teams. Work closely with data engineers, product engineers, business owners to understand and influence their function</li>
                <li>Make business recommendations (e.g. cost-benefit, forecasting, experiment analysis) with effective presentations of findings at multiple levels of stakeholders through visual displays of quantitative information</li>
              </ul>
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>PhD degree in a quantitative discipline (e.g., statistics, operations research, bioinformatics, economics, computational biology, computer science, mathematics, physics, electrical engineering, industrial engineering)</li>
                <li>Experience with statistical software (e.g., R, Julia, MATLAB, pandas) and database languages (e.g., SQL)</li>
                <li>3 years of relevant work experience (e.g., as a statistician / computational biologist / bioinformatician / data scientist), including deep expertise and experience with statistical data analysis such as linear models, multivariate analysis, stochastic models, sampling methods. Analytical engagements outside class work while at school can be included.</li>
                <li>Applied experience with machine learning on large datasets</li>
                <li>Experience articulating business questions and using mathematical techniques to arrive at an answer using available data. Experience translating analysis results into business recommendations</li>
                <li>Demonstrated skills in selecting the right statistical tools given a data analysis problem. Demonstrated effective written and verbal communication skills</li>
                <li>Demonstrated leadership and self-direction. Demonstrated willingness to both teach others and learn new techniques</li>
                <li>Strong communication skills </li>
                <li>Domain expertise in logistics is a value addition</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-technology pos-all">
            <div class="head">
              <h4>DATA ENGINEER </h4>
              <div class="overview">Bangalore | Full-time | 3 positions </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Machine learning pipelines and ETL processes that operate at arbitrary scale</li>
                <li>Reliable, stateless services that can be dynamically scaled and continuously deployed</li>
                <li>Analytical jobs and services to measure model performance offline and in production</li>
                <li>Tooling to help us productionize machine learning models faster</li>
              </ul>
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>Object oriented programming in languages like Python or Java</li>
                <li>Data modeling and schema evolution tools</li>
                <li>Parallelism, concurrency, and distributed system concepts (knowledge of CQRS, Event Sourcing, CAP Theorem)</li>
                <li>Understand what "turning the database inside out" means and its relevance to distributed commit logs and stream processing frameworks.</li>
                <li>Expert knowledge of SQL and data querying tools & libraries</li>
                <li>Micro service architecture design. Prior experience with A/B testing machine learning services before deployment is a plus</li>
                <li>API design and evolution</li>
                <li>Experience with functional programming in Spark is a plus</li>
                <li>Machine learning fundamentals is a plus</li>
                <li>Big data frameworks like Spark and Hadoo</li>
                <li>Schema evolution tools such as Thrift, Avro or Protocol Buffers</li>
                <li>Modern distributed databases like MongoDB, Cassandra, and Riak</li>
                <li>Stream processing frameworks such as Kafka, Flink, Storm, and Samza</li>
                <li>Infrastructural tools like Docker, Zookeeper, Mesos, and Marathon and the ability to deploy machine learning services reliably with these tools</li>
                <li>AWS systems like EC2, SQS, EMR and Redshift</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-technology pos-all">
            <div class="head">
              <h4>PRODUCT MANAGER </h4>
              <div class="overview">Bangalore | Full-time | 2 positions </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Defining, communicating, and owning the product plan from conception to launch </li>
                <li>Analysing the results of a launch and creating the plan to iterate and build new features </li>
                <li>Ruthlessly prioritizing features based on business impact and available resources </li>
                <li>Proactively filling communication gaps amongst all team members – Good communication solves half the problem </li>
                <li>Growing and inspiring top performing team members even without direct authority </li>
                <li>Contributing to technical conversations around deadlines and engineering solutions </li>
                <li>Drive product research priorities for strategically important projects </li>
                <li>Make magic out of the complicated and antiquated freight industry through intense focus on simplification and shipping minimal viable products quickly</li>
              </ul>
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>Bachelor’s degree (preferably in either computer science or a quantitative domain (math/stats)) </li>
                <li>3+ years of relevant Product Management experience for B2C or B2B </li>
                <li>5+ years of overall experience – software engineering experience before Product Management</li>
                <li>Experience communicating technical concepts to a non-technical audience </li>
                <li>Technical expertise and the ability to question, understand, and challenge software implementation decisions and priorities </li>
                <li>Passionately curious to learn and adapt to dynamic research, development and industry knowledge </li>
                <li>A bold, optimistic, result-oriented personality</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-operations pos-all">
            <div class="head">
              <h4>Associate Manager - Operations </h4>
              <div class="overview">Multiple Locations | Full-time | 1 position </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Ensuring delivery of superior customer service in allocated region, thereby establishing</li>
                <li>Blackbuck as the partner of choice for customers</li>
                <li>Responsible for the entire P&amp;L of the states allocated by:
                  <p>- Ensuring order fulfilment within the target prices set by pricing team</p>
                  <p>- Operational efficiency leading to minimal losses at customer/order level</p>
                </li>
                <li>Ensuring synergy of work and purpose between various sub-teams in line with the mandate of the Operations team</li>
                <li>Undertake key initiatives towards betterment of operations processes in the region, which can be a model for other regions as well</li>
                <li>Building an energized &amp; productive team in the region by appropriate work allocation, training and Reward &amp; Recognition</li>
              </ul>
              
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>Any Graduation or Post Graduation from Tier 2 / 3 College</li>
                <li>Min 4 years of experience in operations delivery role, vendor development or Logistics</li>
                <li>Min 1 year of people management role is must</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-sales pos-all">
            <div class="head">
              <h4>BUSINESS DEVELOPMENT MANAGER </h4>
              <div class="overview">Bangalore | Full-time | 1 position </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Working with Product and Engineering team to develop the products which can fulfil the client needs</li>
                <li>Work with Pricing/ Operations/ Finance team to ensure service delivery to customers</li>
                <li>Proactively building trusted client relationships – maintain a portfolio of active and growing customers</li>
                <li>Generate creative ideas on customer acquisition and products/services</li>
                <li>Maintain a high level of professionalism in client engagement and internal stakeholder management and other business conduct</li>
                <li>Drive continuous improvement of the operational efficiency and effectiveness of processes to increase the consistency of systems and processes</li>
                <li>Partner effectively with internal stakeholders to deliver effective client solutions</li>
                <li>Abide by appropriate frameworks to guarantee that business is carried out within the company’s risk appetite and relevant risks are appropriately managed in conjunction with line managers and other stakeholders</li>
              </ul>
              
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>MBA from tier 1 college</li>
                <li>1-4 years of experience in Business Development in any industry (B2B preferred)</li>
                <li>Good analytical skills and ability to assess client needs</li>
                <li>Fast learner and ability to adapt quickly to new environment</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>
          <li class="pos-sales pos-all">
            <div class="head">
              <h4>REGIONAL ASSISTANT MANAGER - COMMERCE </h4>
              <div class="overview">New Delhi, Kolkata | Full-time | 1 position </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              <ul class="job-details">
                <li>Responsible for effectively managing their sales force in achieving revenue targets, market share growth, and customer satisfaction for all trucking commerce products</li>
                <li>Own the complete revenue stream from potential customers, lead sales planning and execution for the region</li>
                <li>Actively seek out new sales opportunities and client acquisition through networking primarily focusing upon positive relationship at all level targeting the decision makers</li>
                <li>Building and maintain a high performing sales team</li>
              </ul>
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>

          <li class="pos-supply pos-all">
            <div class="head">
              <h4>ASSOCIATE MANAEGR - SUPPLY</h4>
              <div class="overview">Bangalore | Full-time | 3 positions </div>
            </div>
            <div class="details">
              <h5>Roles & Responsibilities:</h5>
              
              <ul class="job-details">
                <li>Identification of Supply Clusters for Target lanes</li>
                <li> Building FO Pipeline in identified Supply Clusters</li>
                <li>Taking multiple FO quotes from FO Pipeline</li>
                <li> Techno-commercial negotiations & closure of FO contracts</li>
                <li> Managing relationships with on boarded Fleet owners</li>
                <li> Monitoring of contracts performance</li>
                <li> Identification of replacements for poor performing Fleet owners</li>
                
              </ul>
              <h5>Requisites / Prerequisites: </h5>
              <ul class="job-details">
                <li>Undergraduate / Postgraduate from any good Tier 2 / Tier 3 Engineering / MBA School</li>
                <li>3-5 Years in Supply side of internet start-ups in Hospitality, Transportation, Hyperlocal, Food Tech, etc.</li>
              </ul>
              
              <p class="send-enquiry">Interested in this position? Send your C.V to <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a></p>
            </div>
          </li>


        </ul>
      </div>
    </section>
    <section class="photogallery">
      <div class="container">
                  <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank" ><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" target="_blank" ><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube-square" aria-hidden="true"></i></a></li>
            </ul>
        <div class="row">
          <div class="col-sm-6">
            <div class="row">
              <div class="col-sm-8"> <figure class="sep"> <img src="images/gallery/one.jpg" alt=""></figure></div>
              <div class="col-sm-4"> <figure class="two"> <img src="images/gallery/two.jpg" alt=""></figure></div>
            </div>
            <div class="row">
              <div class="col-sm-4"> <figure class='five'> <img src="images/gallery/five.jpg" alt=""></figure></div>
              <div class="col-sm-8"> <figure> <img src="images/gallery/six.jpg" alt=""></figure></div>
            </div>
          </div>
          <div class="col-sm-2">
            <figure class="three">
              <img src="images/gallery/three.jpg" alt="">
            </figure>
          </div>
          <div class="col-sm-4">
            <div class="row">
              <div class="col-sm-12"> 
               <figure class="video-play"><button class="btn-play hackathon"></button> <img src="images/gallery/seven.jpg" alt=""></figure>
              
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12">
             <figure><img src="images/gallery/four.jpg" alt=""></figure>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="section5">
    <div class="container">
      <div class="col-sm-4">
        <div class="thumbnail">
          <figure class="one">
            <img src="images/careers/icons-career1.svg" alt="">
          </figure>
          <p>The exceptional leaps
          taken till now! </p>
          <a href="about-blackbuck.php#animation">Know more</a>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="thumbnail">
          <figure>
            <img src="images/careers/icons-career2.svg" alt="">
          </figure>
          <p>It takes an incredible team to
          build something exciting! </p>
          <a href="team.php">Know more</a>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="thumbnail">
          <figure>
            <img src="images/careers/icons-career3.svg" alt="">
          </figure>
          <p>On every road, we are creating
          buzz in the media</p>
          <a href="about-blackbuck.php#news">Know more</a>
        </div>
      </div>
    </div>
  </section>
  <!-- connect -->
  <?php include "partials/connect.php" ?>
  <?php include "partials/footer.php" ?>
  <div class="video">
    <span class="video-close"></span>
    <div class="play-video">
    </div>
  </div>
</body>
</html>