<?php $thisPage="products"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
        <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
            <div class="container">
        <div class="products-banner">
          <p class="title">Products fuelled by Data Science</p>
        </div>
      </div>

    <section class="section2">
      <div class="container">
        <div class="content">
          <p>Data Science is at the core of what we do at BlackBuck. The comprehensive data which we have gathered over time drives us to build ‘must have’ and ‘future ready’ products to match the demand to supply. We are as much about driving consumer behaviour changes, as we are about analytics and advanced machine learning.</p>
          <p>Our products create infinite value and deliver measureable results for shippers and fleet operators through</p>

          <ul class='prod-desc'>
            <li>Instant Availability</li>
            <li>Fair and Transparent Pricing </li>
            <li>Seamless experience</li>
          </ul>
        </div>
      </div>
    </section>

    <section class="shippers">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-sm-push-6 ">
            <div class="content">
            <h3>Our products and services for <strong>Shippers</strong></h3>
            <p>Manage all your shipments on one smart and convenient platform. Locate the available trucks across India without any requirement to make multiple phone calls and monitor your shipment at every mile. Our machine learning algorithms connect you with the most suitable fleet operator at any given point of time depending on your source, destination, material to be shipped and other details.
</p>
            <a class="btn  know-more-sm" href="products-shippers.php">Know more</a>

            </div>
          </div>
          <div class=" col-xs-12 col-sm-6 col-sm-pull-6">
            <figure>
              <img src="images/products/blackbuck_shippers_01.png" alt="">
              <a class="btn  know-more-xs" href="products-shippers.php">Know more</a>

            </figure>

          </div>
        </div>
      </div>
    </section>


        <section class="fleet">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-6">
            <div class="content">
            <h3>Our products and services for <strong>Fleet Operators</strong></h3>
            <p>Find and book daily loads for your fleet with ease, along with fair and transparent pricing. Attach your trucks with BlackBuck and ensure higher truck utilization that helps you to earn more. An efficient route planning helps optimise time and reduce fuel expenses of your fleet.</p>
                      <a class="btn  know-more-sm"  href="products-fleet_operators.php">Know more</a>
            </div>
          </div>
          <div class=" col-xs-12 col-sm-6 ">
            <figure>
              <img src="images/products/blackbuck_shippers_02.gif" alt="">
                         <a class="btn  know-more-xs "  href="products-fleet_operators.php">Know more</a>
            </figure>
          </div>
        </div>
      </div>
    </section>
    
    <!-- connect -->
<section class="section7 connect">
  <div class="container">
    <div class="content">
      <span class="blackbuck-logo"><img src="images/blackbuck-icon.svg" alt=""></span>
      <div class="connect-options">
        <a class="btn btn-connect" href="contact.php">Let's Connect</a>
        <a class="googleplay" href="https://play.google.com/store/apps/dev?id=5958305770425470634" target="_blank">download from playstore</a>
      </div>
      <nav>
        <ul class="foolinks">
          <li><a href="about.php">About</a></li>
          <li><a href="career.php">Career</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="signin.php">Sign in</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
            <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" taret="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
    </div>
  </div>
</section>
    <?php include "partials/footer.php" ?>
  </body>
</html>