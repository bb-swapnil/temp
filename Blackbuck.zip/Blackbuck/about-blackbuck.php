<?php $thisPage="about"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
    <script src="https://code.createjs.com/createjs-2015.11.26.min.js"></script>
    <script src="scripts/jquery-3.2.1.min.js"></script>
    <script src="scripts/adobeAnim.js"></script>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="banner-content">
          <p>Making freight a seamless experience</p>
        </div>
        
      </div>
      <div id="myvideo">
        <div class="video-wrap hidden-xs">
          <video autoplay="" loop="" id="usbvideo" tabindex="0" class="al-img100">
            <source src="images/about/aboutus_video.mp4" type="video/mp4">
          </video>
        </div>
      </div>
      <div class="video-overlay"></div>
    </section>
    <!-- section 2 -->
    <section class="section2">
      <div class="container">
        <div class="content">
          <p class="main-txt"> BlackBuck is building an online marketplace platform for freight where our shippers and fleet operators can engage seamlessly. We are solving some of the core problems in the areas such as price discovery, route optimization, in-transit tracking and timely delivery assurance. With our unmatched technology integrated platform, we are committed to ensure that the right shipper gets matched with the right fleet operator and at the right price.
          </p>
          <p>Ever since the inception in 2015, BlackBuck has been empowering numerous shippers and fleet operators to optimally utilize their potential to achieve maximum results. We are focused towards bringing a positive impact across the freight ecosystem that encompasses and stitches together countless livelihoods.</p>
          <div class="row">
            <div class="col-sm-6">
              <h3>For Shippers</h3>
              <ul class="nostyle">
                <li>Instant availability of trucks</li>
                <li>Advanced shipment tracking</li>
                <li>Hassle-free end-to-end freight management</li>
              </ul>
            </div>
            <div class="col-sm-6">
              <h3>For Fleet Operators </h3>
              <ul class="nostyle">
                <li>Daily loads across India at right prices</li>
                <li>Fast payment settlements</li>
                <li>Attractive range of services and benefits</li>
              </ul>
            </div>
          </div>
          <a class="btn btn-primary discover" href="products.php">
            Discover our products
          </a>
        </div>
      </div>
    </section>
    <!-- section 3 -->
    <section class="section3">
      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <div class="thumbnail first">
              <figure>
                <img src="images/about/icons-about1.svg" alt="">
              </figure>
              <p> <span class="highlight">400+</span> delighted clients
            and attracting more</p>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="thumbnail second">
            <figure>
              <img src="images/about/icons-about2.svg" alt="">
            </figure>
            <p>Pan India presence in <span class="highlight">300+ </span> locations and touching more</p>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="thumbnail third">
            <figure>
              <img src="images/about/icons-about3.svg" alt="">
            </figure>
            <p><span class="highlight">1,00,000+ </span>partner trucks and networking with more </p>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="animation" id="animation">
  <div class="container">
    <div class="heading">
      <p>The freight sector is poised for a revolutionary growth. <strong>BLACKBUCK MARKS THE BEGINNING</strong></p>
    </div>
    <div class="mobile-animation">
      <div class="inner">
        <img src="images/about/mobile-timeline.svg" alt="">
      </div>
    </div>
    <div class="milestone-box">
      <div class="rightarrow bounce ccc"></div>
      <span class="truck"></span>
      <ul class="milestone">
        <li><span rel="one">Aug 2014</span></li>
        <li><span rel="two">Apr 2015</span></li>
        <li><span rel="three">Jun 2015</span></li>
        <li><span rel="four">Jul 2015</span></li>
        <li><span rel="five">Aug 2015</span></li>
        <li><span rel="six">Dec 2015</span></li>
        <li><span rel="seven">Feb 2016</span></li>
        <li><span rel="eight">Jun 2016</span></li>
        <li><span rel="nine">Mar 2017</span></li>
        <li><span rel="ten">Jul 2017</span></li>
      </ul>
      <div class="timeline">
        <div id="animation_container" class="animation_container">
          <canvas id="canvas" class="canvas"></canvas>
          <div id="dom_overlay_container" style="pointer-events:none; overflow:hidden; width:100%; height:400px; display: block;">
          </div>
        </div>
      </div>
    </div>
    <div class="anim-content">
      <p id="one"><strong>Aug 2014: </strong> Three friends came together with an idea to build an online marketplace platform for freight      </p>
      <p id="two"><strong>Apr 2015: </strong>Company was founded</p>
      <p id="three"><strong>Jun 2015: </strong>Received ‘Series A’ funding from Accel Partners &amp; Flipkart</p>
      <p id="four"><strong>Jul 2015: </strong>Started Inter-city operations</p>
      <p id="five"><strong>Aug 2015: </strong>Launched mobile app for Fleet Operators</p>
      <p id="six"><strong>Dec 2015: </strong>Received ‘Series B’ funding from Tiger Global, Apoletto Asia, Accel Partners and Flipkart</p>
      <p id="seven"><strong>Feb 2016: </strong>Launched mobile app for SME Shippers</p>
      <p id="eight"><strong>Jun 2016: </strong>Expanded presence in 300+ cities across India</p>
      <p id="nine"><strong>Mar 2017: </strong>Received ‘Series C’ funding from Sands Capital, IFC, Accel Partners and Flipkart</p>
      <p id="ten"><strong>Jul 2017: </strong>400+ clients, 1,00,000+ partner trucks, 800+ strong team</p>
    </div>
  </div>
</div>
</section>
<!-- section 4 -->
<section class="section4 investors">
<div class="container">
  <h2>Investors</h2>
  <ul class="investor-list">
    <?php
    $dirname = "images/about/investors/";
    $images = glob($dirname."*.jpg");
    foreach($images as $image) {
    echo '<li><img src="'.$image.'" /></li>';
    }
    ?>
  </ul>
</div>
</section>
<section class="section5 inthenews" id="news">
<h2>In the news</h2>
<div class="container">
  <ul class="bxslider news">
    <li>
      <a href="http://www.livemint.com/Companies/bQMEeLQ7nd27vd5sveLpkO/BlackBuck-the-online-freight-aggregator-on-a-roll.html" class="title" target="_blank">
      BlackBuck: The online freight aggregator on a roll </a>
      <p>
        BlackBuck, one of the best funded online freight start-ups in India, has everything that takes to win the race. But will it be a smooth ride to the top?
        read more
      </p>
      <p>
        <strong>LIVEMINT</strong>
        <span class="date">July 2017</span>
      </p>
    </li>
    <li>
      <a href="https://www.youtube.com/watch?v=AeW6CgZa7_Q" class="title"  target="_blank" >Exclusive feature on BlackBuck in CNBC TV18-Young Turks</a>
      <p>Catch this feature on BlackBuck in CNBC TV18-Young Turks. BlackBuck is building the online marketplace platform for freight where shippers and the fleet operators can engage seamlessly.</p>
      <p>
        <strong>CNBC-TV18</strong>
        <span class="date">May 2017</span>
      </p>
    </li>
    <li>
      <a href="https://techcrunch.com/2017/03/21/blackbuck-70-million-series-c/" class="title"  target="_blank"> BlackBuck closes $70M to digitize freight and logistics across India </a>
      <p>BlackBuck, a start-up that is digitizing logistics and cross-country freighting in India, has closed out a $70 million Series C round.
        
      </p>
      <p>
        <strong>TECHCRUNCH</strong>
        <span class="date">March 2017</span>
      </p>
    </li>
    <li>
      <a href="http://www.forbesindia.com/article/30-under-30-2017/freight-logistics-is-a-brave-new-world-thanks-to-blackbucks-chanakya-hridaya-and-rajesh-yabaji/45785/1" class="title"   target="_blank">BlackBuck's Chanakya Hridaya and Rajesh Yabaji in Forbes India 30 under 30 list</a>
      <p>Forbes India has unveiled its annual list of the country’s most promising talent across diverse categories. BlackBuck’s Chanakya and Rajesh feature in the category of ecommerce
        
      </p>
      <p>
        <strong>FORBES INDIA</strong>
        <span class="date">February 2017</span>
      </p>
    </li>
    <li>
      <a href="http://www.financialexpress.com/industry/bengaluru-based-startup-blackbuck-looks-to-disrupt-b2b-logistics-market/334439/" class="title"  target="_blank">Bengaluru-based start-up BlackBuck looks to disrupt B2B logistics market</a>
      <p>With disruptive technology, BlackBuck is trying to redefine the business-to-business logistics landscape in India.</p>
      <p>
        <strong>FINANCIAL EXPRESS</strong>
        <span class="date">August 2016</span>
      </p>
    </li>
    <li>
      <a href="http://bwdisrupt.businessworld.in/article/BlackBuck-An-Online-Marketplace-for-Logistics-Transactions-Helping-Customers-Move-Full-Truck-Loads-Between-Cities/03-07-2016-99946/" class="title"  target="_blank">BlackBuck - An Online Marketplace for Logistics Transactions, Helping Customers Move Full Truck Loads Between Cities</a>
      <p>BlackBuck is an online B2B marketplace for inter-city Full Truck Load (FTL) transportation. Keeping technology at the core, BlackBuck is redefining the logistics landscape of India, making it reliable and efficient. </p>
      <p>
        <strong>BUSINESSWORLD</strong>
        <span class="date">July 2016</span>
      </p>
    </li>
    <li>
      <a href="https://www.entrepreneur.com/article/279632"  class="title"  target="_blank">How this start-up is encouraging disruption in truck logistics business</a>
      <p>BlackBuck is re-creating logistics commerce using technology, building a platform where buyers and sellers of freight can engage seamlessly. </p>
      <p>
        <strong>ENTREPRENEUR INDIA</strong>
        <span class="date">July 2016</span>
      </p>
    </li>
  </ul>
</div>
</section>
<!-- clientele -->
<section class="section6 clientele">
<div class="container">
  <h2>Clientele</h2>
  <ul class="clientele-list">
    <?php
    $dirname = "images/about/clientele/";
    $images = glob($dirname."*.jpg");
    foreach($images as $image) {
    echo '<li><img src="'.$image.'" /></li>';
    }
    ?>
  </ul>
</div>
</section>
<!-- connect -->
<?php include "partials/connect.php" ?>
<?php include "partials/footer.php" ?>
<div class="video">
<span class="video-close"></span>
<div class="play-video">
</div>
</div>
</body>
</html>