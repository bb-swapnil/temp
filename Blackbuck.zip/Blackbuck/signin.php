<?php $thisPage="signin"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="signinform">
        
        <input type="text" placeholder="username">
        <input type="text" placeholder="password">
        <input type="submit" class="btn" value="Sign In">
        <p class='connect-options'>
          <a href="tel:+ 917676955555"><i class="fa fa-phone" aria-hidden="true"></i>  + 91 7676955555</a>
          <a href="mailto:sales@blackbuck.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> sales@blackbuck.com</a>
        </p>
      </div>
    </section>
    
    <?php include "partials/footer-includes.php" ?>
  </body>
</html>