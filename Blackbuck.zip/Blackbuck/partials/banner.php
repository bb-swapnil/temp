    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="banner-content">
          <p>Making freight simple and effective,using technology</p>
        </div>
      </div>
    </section>