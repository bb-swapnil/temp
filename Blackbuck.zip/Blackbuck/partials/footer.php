  <footer>
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-md-3"> <span class="copyright">@blackbuck</span></div>
        <div class="col-sm-6 col-md-6 col-lg-7">
          <nav>
            <ul class="foolinks">
              <li><a href="about-blackbuck.php">About</a></li>
              <li><a href="products.php">Products</a></li>
              <li><a href="careers.php">Careers</a></li>
              <li><a href="team.php">Team</a></li>

              <li><a href="contact.php">Contact</a></li>

            </ul>
          </nav>
        </div>
         <div class="col-sm-3 col-md-3 col-lg-2">
            <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" target="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
         </div>
      </div>
    </div>
  </footer>
		<?php @include "partials/footer-includes.php" ?>