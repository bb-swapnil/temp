<header class="top-header">
  <div class="container">
    <div class="row">
      <div class="col-sm-3">
        <a href="index.php" class="logo"> <img src="images/blackbuck-logo.svg" alt="Blackbuck"></a>
      </div>
      <div class="col-sm-9">
        <nav class="main-nav">
          <ul class="main-links">
            <li>
              <?php
              if ($thisPage=='about')
              {echo '<span class="static">About</span>';}
              else
              {echo '<a href="about-blackbuck.php">About</a>';}?>
            </li>
            <li>
              <?php
              if ($thisPage=='products' || $thisPage=='products-shippers' || $thisPage=='products-fleet_operators') {
                echo '<span class="static">Products</span>';
                echo "<ul>";
                echo '<li><a href="products-shippers.php"> Shippers</a></li>';
                echo '<li><a href="products-fleet_operators.php"> Fleet Operators</a></li>';
              echo "</ul>";
          }
              else
              {echo '<a href="products.php">Products</a>';}?>
            </li>
            <li>
              <?php
              if ($thisPage=='careers')
              {echo '<span class="static">Careers</span>';}
              else
              {echo '<a href="careers.php">Careers</a>';}?>
            </li>
        <li>
          <?php
          if ($thisPage=='team')
          {echo '<span class="static">Team</span>';}
          else
          {echo '<a href="team.php">Team</a>';}?>
        </li>
            <li>
              <?php
              if ($thisPage=='contact')
              {echo '<span class="static">contact</span>';}
              else
              {echo '<a href="contact.php">Contact</a>';}?>
            <li>
              <?php
              if ($thisPage=='signin')
              {echo '';}
              else
              {echo '<a href="signin.php">Sign In</a>';}?>
            </li>
          </ul>
        </nav>
        <div class="navbtn">
          <div class="bar"></div>
        </div>
      </div>
    </div>
  </div>
  <div class="nav-slider">
    <button class="close"></button>
    <img src="images/blackbuck-icon.svg" alt="Blackbuck" class="logo">
    <nav class="sidebar-nav">
      <ul class="main-links">
        <li>
          <?php
          if ($thisPage=='homepage')
          {echo '<span class="static">Home</span>';}
          else
          {echo '<a href="index.php">Home</a>';}?>
        </li>
        <li>
          <?php
          if ($thisPage=='about')
          {echo '<span class="static">About </span>';}
          else
          {echo '<a href="about-blackbuck.php">About</a>';}?>
        </li>
        <li>
          <?php
          if ($thisPage=='products')
          {echo '<span class="static">Products</span>';}
          else
          {echo '<a href="products.php">Products</a>';}?>
        </li>
        <li>
          <?php
          if ($thisPage=='careers')
          {echo '<span class="static">Careers</span>';}
          else
          {echo '<a href="careers.php">Careers</a>';}?>
        </li>
        <li>
          <?php
          if ($thisPage=='team')
          {echo '<span class="static">Team</span>';}
          else
          {echo '<a href="team.php">Team</a>';}?>
        </li>
            <li>
              <?php
              if ($thisPage=='contact')
              {echo '<span class="static">contact</span>';}
              else
              {echo '<a href="contact.php">Contact</a>';}?>
            </li>        
                    <li>
              <?php
              if ($thisPage=='signin')
              {echo '';}
              else
              {echo '<a href="signin.php">Sign In</a>';}?>
            </li>

      </ul>
            <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" taret="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
    </nav>
  </header>