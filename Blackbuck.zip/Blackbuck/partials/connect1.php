<section class="section7 connect">
  <div class="container">
    <div class="content">
      <span class="blackbuck-logo"><img src="images/blackbuck-icon.svg" alt=""></span>
      <div class="connect-options">
      <p>Attach your truck with BlackBuck today!</p>
      <div class="buttons">
        <a class="btn btn-connect" href="tel:+917676955555">Call us</a>
        <a class="btn btn-connect" href="mailto:sales@blackbuck.com">Email Us</a>
        </div>
<a class="googleplay" href="https://play.google.com/store/apps/dev?id=5958305770425470634" target="_blank">download from playstore</a>
      </div>
      <nav>
        <ul class="foolinks">
          <li><a href="about.php">About</a></li>
          <li><a href="career.php">Career</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="signin.php">Sign in</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
            <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" taret="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
    </div>
  </div>
</section>