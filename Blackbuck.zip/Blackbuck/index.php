<?php $thisPage="homepage"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="banner-content">
          <p>Building The Marketplace Platform  For Freight</p>
          
        </div>
        <div class="arrow homebounce">
        </div>
      </div>
    </section>
    <section class="section2">
      <div class="container">
        <div class="content-box box1">
          <div class="left"> </div>
          <div class="right">
            <h3 class="title">Making freight a <br/>seamless experience</h3>
            <p>BlackBuck is revolutionizing freight by making it a seamless experience for shippers and fleet operators. We make the process of getting trucks at the best price and tracking of the shipments easy for shippers; and help fleet operators in ensuring optimal utilization and effective management of their fleet.</p>
            <a class="btn btn-white" href="about-blackbuck.php"> Discover BlackBuck</a>
          </div>
        </div>
      </div>
    </section>
    <section class="section3">
      <div class="container">
        <div class="content-box box2">
          <div class="left"></div>
          <div class="right">
            <h3 class="title">Products fuelled by <br/>data science</h3>
            <p>Driving consumer behaviour changes is crucial, and data science is at the core of how we achieve that. We are at the cutting edge of research and development. Our future ready products ensure that the right shipper gets matched with the right fleet operator and at the right price.
            </p>
            <a class="btn btn-white" href="products.php">More on our products</a>
          </div>
        </div>
      </div>
    </section>
    <section class="section4">
      <div class="container">
        <div class="content-box box3">
          <div class="left"> </div>
          <div class="right">
            <h3 class="title">Be a part <br/>of our journey</h3>
            <p>At BlackBuck, we have genuine passion for the work we do and we are all here to shape the future of freight. Be a part of an exciting, fulfilling and rewarding journey - Be a part of the BlackBuck journey!
            </p>
            <a class="btn btn-white" href="careers.php"> Explore BlackBuck journey</a>
          </div>
        </div>
      </div>
    </section>
    <?php include "partials/connect.php" ?>
    <?php include "partials/footer.php" ?>
  </body>
</html>