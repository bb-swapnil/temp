<?php $thisPage="contact"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="products-banner">
          <p class="title">Get in touch with BlackBuck</p>
        </div>
        <section class="contact-details">

    <ul>
      <li>
           <h3>Calls Us </h3>
              <a href="tel:+917676955555">+91 76769 55555</a>
      </li>
      <li>
          <h3>For Careers</h3>
                <a href="mailto:careers@blackbuck.com">careers@blackbuck.com</a>

      </li>
      <li>
            <h3>For Business</h3>
                <a href="mailto:sales@blackbuck.com">sales@blackbuck.com</a>
      </li>
    </ul>


        </section>
      </div>
    </section>
    <section class="address">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <h3>Corporate Office</h3>
            <address>
              <p>Zinka Logistics Solutions Pvt. Ltd. <br/>
                "The Address" by Feather-light Developers ,<br/>
                6th Floor, No 17/1, Opp, Cessna Business Park, <br/>
                Kaverappa Layout,  Kadubeesanahalli, Bellandur,<br/>
                Bengaluru, Karnataka - 560103 <br/>

              </p>
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i> Get directions</a>
            </address>
          </div>
          <div class="col-sm-6">
            <h3>Branch Office</h3>
            <address>
              <p>
                Zinka Logistics Solutions Pvt. Ltd. <br/>
                "Vaswani Presidio", 5th Floor<br/>
                No. 84/2, Panathur Main Road, Off Outer Ring Road,<br/>
                Bengaluru, Karnataka – 560103<br/>
              </p>
               <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i> Get directions</a>
            </address>
          </div>
        </div>
      </div>
    </section>
    <div class="gmap">
      
      <div class="container">

<!--       <div class="direction tooltip corporate">
      <i class="fa fa-map-marker" aria-hidden="true"></i>
        <h6>Corporate Office</h6>
        <a href="#" class="btn">Get Directions</a>
        <div class="corner"></div>
      </div>

            <div class="direction tooltip branch">
      <i class="fa fa-map-marker" aria-hidden="true"></i>
        <h6>Branch Office</h6>
        <a href="#" class="btn">Get Directions</a>
        <div class="corner"></div>
      </div> -->

      </div>
    </div>
    <section class="contactform">
      <div class="container">
        <p class="txt">We are happy to answer any questions that you may have.
        Just send us a message in the form below.</p>
        <ul class="form">
          <li><input type="text" placeholder="Name"></li>
          <li><input type="text" placeholder="Phone"></li>
          <li><input type="email" placeholder="Email ID"></li>
          <li>
            <textarea name="" id="" cols="30" rows="5" placeholder="Message"></textarea>
          </li>
          <li>
            <button class="btn btn-message">Send</button>
          </li>
        </ul>
        
      </div>
    </section>
    <!-- connect -->
<section class="section7 connect">
  <div class="container">
    <div class="content">
      <span class="blackbuck-logo"><img src="images/blackbuck-icon.svg" alt=""></span>

      <nav>
        <ul class="foolinks">
          <li><a href="about.php">About</a></li>
          <li><a href="career.php">Career</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="signin.php">Sign in</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
            <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" taret="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
    </div>
  </div>
</section>
    <?php include "partials/footer.php" ?>
  </body>
</html>