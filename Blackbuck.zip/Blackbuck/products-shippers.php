<?php $thisPage="products-shippers"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="products-banner">
          <figure class="shadow">
            <img src="images/products/blackbuck_shippers_mobile_animation.gif" alt="">
          </figure>
          <div class="txt">
            <p class="title">Availability of truck at the right price for <strong>Shippers</strong></p>
            <p class="downloadapp"> Download the BlackBuck – Trucker App </p>
            <a href="https://play.google.com/store/apps/details?id=com.blackbuck.sme.demand" target="_blank" class="googleplay ">download google app</a>
          </div>
        </div>
      </div>
    </section>
    <!-- section 2 -->
    <section class="pro-two-col">
      <div class="container">
        <ul class="pro-two-col-list">
          <li>
            <div class="thumbnail">
            <figure><img src="images/products/icons-shipper1.svg" alt=""></figure>
            <span class="caption">Competitive Pricing </span>
            <span class="desc">Find trucks at a competitive price for your shipments, so that your business can save cost and time</span>
          </div>
        </li>
        <li>
          <div class="thumbnail">
          <figure><img src="images/products/icons-shipper2.svg" alt=""></figure>
          <span class="caption">Exceptional Pan India Service</span>
          <span class="desc">We operate out of 300+ locations with 100,000+ trucks on the platform to ensure instant availability of trucks and timely placement of your shipment </span>
        </div>
      </li>
      <li>
        <div class="thumbnail">
        <figure><img src="images/products/icons-shipper4.svg" alt=""></figure>
        <span class="caption">Unique Tracking Solutions</span>
        <span class="desc">Have real-time visibility on the progress of your shipment till the last mile with our advanced truck monitoring systems </span>
      </div>
    </li>
    <li>
      <div class="thumbnail">
      <figure><img src="images/products/icons-shipper3.svg" alt=""></figure>
      <span class="caption">Hassle-Free End-to-End Freight Management</span>
      <span class="desc">Manage your entire freight requirement optimally with our comprehensive range of services and, fast and reliable support at every step</span>
    </div>
  </li>
</ul>
</div>
</section>
<section class="testimony-container">
<section class="section5 testimonials">
<h2>Testimonials</h2>
<div class="container">
  <ul class="bxslider testimony">
    <li>
      
   <p>I have been placing trucks through the BlackBuck app since one year. No other freight company is at par in service like BlackBuck is for its clients. They fulfil all the requirements on time and have made the whole process easy and streamlined. </p>
      <p>
        <span class="person">Saurav Goel </span>
        <span class="company">Shree Jagdamba Exports, Karnal </span>
      </p>
    </li>
    <li>
      
     <p>It is a real pleasure dealing with a firm like BlackBuck whose idea of a partnership is done with deeds not only words. Their responsiveness, knowledge of transportation innovation and quest for perfection testifies their leadership.</p>
      <p>
        
        <span class="person">Surinder Bansal</span>
        <span class="company">God Vishnu rice mill, Karnal </span>
      </p>
    </li>
    <li>
      
     <p>In such an unorganized industry, BlackBuck brings professionalism. They ensure the vehicle availability as per our needs and at competitive rates. BlackBuck representatives are always responsive. </p>
      <p>
        <span class="person">Sumit Zalariya</span>
        <span class="company">Midas Touch Microns, Udaipur</span>
      </p>
    </li>
  </ul>
</div>
</section>
</section>
<!-- connect -->
<section class="section7 connect">
<div class="container">
<div class="content">
  <span class="blackbuck-logo"><img src="images/blackbuck-icon.svg" alt=""></span>
  <div class="connect-options">
    <p>Attach your truck with BlackBuck today!</p>
    <div class="buttons">
      <a href="tel:+ 917676955555" class="btn"><i class="fa fa-phone" aria-hidden="true"></i>  + 91 76769 55555</a>
      <a href="mailto:sales@blackbuck.com" class="btn"><i class="fa fa-envelope-o" aria-hidden="true"></i> sales@blackbuck.com</a>
    </div>
    <a href="https://play.google.com/store/apps/details?id=com.blackbuck.sme.demand" target="_blank" class="googleplay ">download google app</a>
  </div>
  <nav>
    <ul class="foolinks">
      <li><a href="about.php">About</a></li>
      <li><a href="career.php">Career</a></li>
      <li><a href="products.php">Products</a></li>
      <li><a href="signin.php">Sign in</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
  </nav>
  <ul class="social">
    <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
    <li><a href="https://www.linkedin.com/company-beta/10152397/" taret="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
    <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
  </ul>
</div>
</div>
</section>
<?php include "partials/footer.php" ?>
</body>
</html>