(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween146 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("ACXiYIAAh5AiXkWIAAgoACXE/IAAl8AgOCUIAAlVAiXESIAAnT");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.6,-33.4,33.3,66.9);


(lib.Tween145 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("ACXiYIAAh5ACXE/IAAl9AiWkWIAAgpAgOCTIAAlUAiWESIAAnT");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.6,-33.4,33.3,66.9);


(lib.Tween144 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(-15.1,4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(-15.1,-29.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("AAACrIAAlV");
	this.shape_2.setTransform(-1.5,-2.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("AAAC/IAAl9");
	this.shape_3.setTransform(15.2,12.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AAAA8IAAh4");
	this.shape_4.setTransform(15.2,-21.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.6,-33.4,33.3,66.9);


(lib.Tween134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape.setTransform(0,-9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape_1.setTransform(0,8.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgnAnQAAARAMALQALAMAQAAQAQAAAMgMQALgLAAgRQAAgRgLgLQgLgLgRAAQgQAAgLgKQgMgLAAgSQAAgQAMgMQALgLAQAAQAQAAAMALQALAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8QgzgzAAhJQAAhIAzgzQAzg0BIABQBJgBAzA0QA0AzAABIQAABJg0AzQgzAzhJABQhIgBgzgzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween133 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape.setTransform(0.1,8.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAgOIAAAd");
	this.shape_1.setTransform(0.1,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgmAnQAAAQALANQAMALAPAAQARAAALgLQAMgNAAgQQAAgRgMgLQgLgLgRAAQgQAAgLgKQgLgLAAgSQAAgQALgMQAMgLAPAAQARAAALALQAMAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0gzAAhJQAAhIA0gzQAzg0BIAAQBJAAAzA0QA0AzAABIQAABJg0AzQgzA0hJAAQhIAAgzg0g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.2,35.2);


(lib.Tween132 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape.setTransform(0.1,-10);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape_1.setTransform(0.1,8.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgnAnQAAARAMAMQALALAQAAQAQAAAMgLQALgMAAgRQAAgRgLgLQgMgLgQAAQgQAAgLgKQgMgLAAgSQAAgQAMgMQALgLAQAAQAQAAAMALQALAMAAAQ");
	this.shape_2.setTransform(0.1,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0g0AAhIQAAhIA0gzQAzg0BIAAQBJAAAzA0QA0AzAABIQAABJg0AzQgzAzhJAAQhIAAgzgzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.2,35.1);


(lib.Tween125 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjqBcQArgZAwgVQCahDCeABIgPgTQAYgHAXgFQAmAcAdAlQgRgEgbABQgzAAgsAVIBQAfIg0AaIAXgWQg1gFhTADQilAGiSAqQAMgIAVgNgABUhaIAdgGQAcAJAZAOIgmALQgVgSgXgKgAgahuIAbgCQAogBAnAIIgXAFQgngMgsACg");
	this.shape.setTransform(-1.6,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D71E48").s().p("AkNEOQhwhvAAifQAAidBwhwQBvhwCeAAQCeAABwBwQBwBwAACdQAACfhwBvQhwBwieAAQidAAhwhwg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.2,-38.2,76.5,76.5);


(lib.Tween124 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjqBcQArgZAwgVQCahDCeABIgPgTQAYgHAXgFQAmAcAdAlQgRgEgbABQgzAAgsAVIBQAfIg0AaIAXgWQg1gFhTADQilAGiSAqQAMgIAVgNgABUhaIAdgGQAcAJAZAOIgmALQgVgSgXgKgAgahuIAbgCQAogBAnAIIgXAFQgngMgsACg");
	this.shape.setTransform(-1.6,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D71E48").s().p("AkNEOQhwhvAAifQAAidBwhwQBvhwCeAAQCeAABwBwQBwBwAACdQAACfhwBvQhwBwieAAQidAAhwhwg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.2,-38.2,76.5,76.5);


(lib.Tween121 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AA8g7Ih/AAIAoB4IBfAA");
	this.shape.setTransform(159.8,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("ABRAAQAAAigXAXQgYAYgiAAQggAAgZgYQgXgXAAgiQAAghAXgXQAZgYAgAAQAiAAAYAYQAXAXAAAhg");
	this.shape_1.setTransform(130.9,53.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("ADLAAQAABUg7A8Qg8A7hUAAQhTAAg7g7Qg8g8AAhUQAAhTA8g7QA7g8BTAAQBUAAA8A8QA7A7AABTg");
	this.shape_2.setTransform(130.9,53.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("ACmCGIhBAAQhtAAhPhOQhOhOAAhvIFLAAg");
	this.shape_3.setTransform(101.2,-5.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AhUGZImGAAIgBsxIILAAQAMAAAJAJQAJAJAAAMIAAF1ID3AAQA/AAAsAsQAsAsAAA+IAAEIIibAA");
	this.shape_4.setTransform(119,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,1,1).p("ASIJ5MgkQAAAQgMAAgJgIQgJgJAAgNIAAy1QAAgNAJgIQAJgJAMAAMAkQAAAQANAAAJAJQAIAIAAANIAAS1QAAANgIAJQgJAIgNAAg");
	this.shape_5.setTransform(-47.5,-10.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_6.setTransform(-127.5,57.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg7A7Qg8A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_7.setTransform(-127.4,63.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgXAXQgYAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_8.setTransform(31.7,57.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_9.setTransform(31.7,63.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_10.setTransform(-81.8,57.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhUAAg7g7Qg7g7AAhU");
	this.shape_11.setTransform(-81.8,63.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168,-75.4,336.2,150.8);


(lib.Tween120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AA8g7Ih/AAIAoB4IBfAA");
	this.shape.setTransform(159.8,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("ABRAAQAAAigXAXQgYAYgiAAQggAAgZgYQgXgXAAgiQAAghAXgXQAZgYAgAAQAiAAAYAYQAXAXAAAhg");
	this.shape_1.setTransform(130.9,53.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("ADLAAQAABUg7A8Qg8A7hUAAQhTAAg7g7Qg8g8AAhUQAAhTA8g7QA7g8BTAAQBUAAA8A8QA7A7AABTg");
	this.shape_2.setTransform(130.9,53.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("ACmCGIhBAAQhtAAhPhOQhOhOAAhvIFLAAg");
	this.shape_3.setTransform(101.2,-5.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AhUGZImGAAIgBsxIILAAQAMAAAJAJQAJAJAAAMIAAF1ID3AAQA/AAAsAsQAsAsAAA+IAAEIIibAA");
	this.shape_4.setTransform(119,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,1,1).p("ASIJ5MgkQAAAQgMAAgJgIQgJgJAAgNIAAy1QAAgNAJgIQAJgJAMAAMAkQAAAQANAAAJAJQAIAIAAANIAAS1QAAANgIAJQgJAIgNAAg");
	this.shape_5.setTransform(-47.5,-10.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_6.setTransform(-127.5,57.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg7A7Qg8A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_7.setTransform(-127.4,63.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgXAXQgYAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_8.setTransform(31.7,57.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_9.setTransform(31.7,63.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_10.setTransform(-81.8,57.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhUAAg7g7Qg7g7AAhU");
	this.shape_11.setTransform(-81.8,63.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168,-75.4,336.2,150.8);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.DEC2015 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("EAdkAj4IAA4cIc0AAIAAYcg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:373.6,y:229.6}).wait(1073));

	// Layer 6
	this.instance = new lib.Tween124("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(652.5,694.1);
	this.instance._off = true;

	this.instance_1 = new lib.Tween125("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(652.5,352.1);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},21).to({state:[{t:this.instance_1}]},42).to({state:[]},998).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({_off:false},0).to({_off:true,y:352.1},42,cjs.Ease.elasticInOut).wait(1031));

	// Layer 5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A9EMcIAA43MA6JAAAIAAY3g");
	mask_1.setTransform(715.2,362.6);

	// Layer 4
	this.instance_2 = new lib.Tween120("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(164,362.7);

	this.instance_3 = new lib.Tween121("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(700,362.7);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},51).wait(1043));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true,x:700},51,cjs.Ease.elasticInOut).wait(1043));

	// Layer 25
	this.instance_4 = new lib.Tween132("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(592.4,-66);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(58).to({_off:false},0).to({y:224},30,cjs.Ease.elasticInOut).to({_off:true},975).wait(31));

	// Layer 14
	this.instance_5 = new lib.Tween144("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(591.9,-120.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(60).to({_off:false},0).to({y:195.4},30,cjs.Ease.elasticInOut).to({_off:true},972).wait(32));

	// Layer 24
	this.instance_6 = new lib.Tween133("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(648.9,-114.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(63).to({_off:false},0).to({y:265.5},31,cjs.Ease.elasticInOut).to({_off:true},969).wait(31));

	// Layer 12
	this.instance_7 = new lib.Tween145("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(648.4,-163.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(66).to({_off:false},0).to({y:236.9},31,cjs.Ease.elasticInOut).to({_off:true},966).wait(31));

	// Layer 23
	this.instance_8 = new lib.Tween134("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(705.5,-168.4);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(69).to({_off:false},0).to({y:239.6},30,cjs.Ease.elasticInOut).to({_off:true},964).wait(31));

	// Layer 16
	this.instance_9 = new lib.Tween146("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(705,-225);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(72).to({_off:false},0).to({y:211},30,cjs.Ease.elasticInOut).to({_off:true},961).wait(31));

	// Layer 1 copy 2
	this.instance_10 = new lib.cloud3();
	this.instance_10.parent = this;
	this.instance_10.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(315));

	// Layer 1
	this.instance_11 = new lib.cloud3();
	this.instance_11.parent = this;
	this.instance_11.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(315));

	// Layer 1 copy
	this.instance_12 = new lib.cloud1("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).wait(91));

	// Layer 1 copy 3
	this.instance_13 = new lib.cloud1("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(300));

	// Layer 1
	this.instance_14 = new lib.cloud1("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(300));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,182.3);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 38,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;