(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween95 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("Ag+g+IB9B9");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.7,-7.7,15.5,15.6);


(lib.Tween94 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("Ag+g+IB9B9");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.7,-7.7,15.5,15.6);


(lib.Tween93 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("Ag6g6IB1B1");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.4,-7.4,14.8,14.8);


(lib.Tween92 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("Ag6g6IB1B1");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.4,-7.4,14.8,14.8);


(lib.Tween91 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AA/g+Ih9B9");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.7,-7.7,15.6,15.6);


(lib.Tween90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AA/g+Ih9B9");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.7,-7.7,15.6,15.6);


(lib.Tween89 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AA7g6Ih1B1");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.4,-7.4,14.8,14.8);


(lib.Tween88 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AA7g6Ih1B1");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.4,-7.4,14.8,14.8);


(lib.Tween87 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AhYAAICwAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.3,-1.5,20.7,3);


(lib.Tween86 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AhYAAICwAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.3,-1.5,20.7,3);


(lib.Tween84 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AhTAAICnAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.8,-1.5,19.7,3);


(lib.Tween83 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAhYIAACx");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-10.3,3,20.8);


(lib.Tween82 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAhYIAACx");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-10.3,3,20.8);


(lib.Tween81 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AAMBEIgXAAQg5AAgogoQgognAAg5IEpAAQAAA5goAnQgoAog5AAg");
	this.shape.setTransform(0,43.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#DA1E48").ss(3,1,1).p("ACVAVIkpAAIAAgoIEpAAg");
	this.shape_1.setTransform(0,30.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#DA1E48").ss(3,1,1).p("AhgAXIA8gnIASA+IAkhbIAUBJIA7gW");
	this.shape_2.setTransform(0.2,-4.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#DA1E48").ss(3,1,1).p("AghChIBDlB");
	this.shape_3.setTransform(7.4,7.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#DA1E48").ss(3,1,1).p("AAiChIhDlB");
	this.shape_4.setTransform(-7.4,7.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#DA1E48").ss(3,1,1).p("ACQELQAAgTAsg/QAWgfAWgcQBGhUAAhsQAAh9hZhYQhYhZh9AAQh8AAhYBZQhZBYAAB9QAABsBGBUIAsA6QAsA9AAAWIAABmIEfAAg");
	this.shape_5.setTransform(0,-13);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiPFxIAAhmQAAgWgsg+Igsg5QhGhUAAhsQAAh9BZhYQBYhYB8gBQB9ABBYBYQBZBYAAB9QAABshGBUQgWAcgWAfQgsA/AAATIAABmg");
	this.shape_6.setTransform(0,-13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.6,-51.3,63.4,102.8);


(lib.Tween80 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AAMBEIgXAAQg5AAgogoQgognAAg5IEpAAQAAA5goAnQgoAog5AAg");
	this.shape.setTransform(0,43.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#DA1E48").ss(3,1,1).p("ACVAVIkpAAIAAgoIEpAAg");
	this.shape_1.setTransform(0,30.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#DA1E48").ss(3,1,1).p("AhgAXIA8gnIASA+IAkhbIAUBJIA7gW");
	this.shape_2.setTransform(0.2,-4.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#DA1E48").ss(3,1,1).p("AghChIBDlB");
	this.shape_3.setTransform(7.4,7.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#DA1E48").ss(3,1,1).p("AAiChIhDlB");
	this.shape_4.setTransform(-7.4,7.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#DA1E48").ss(3,1,1).p("AEuhCQAAh9hZhYQhYhYh9AAQh8AAhYBYQhZBYAAB9QAABsBGBUIAsA6QAsA9AAAWIAABmIEfAAIAAhmQAAgTAsg/QAWgfAWgcQBGhUAAhsg");
	this.shape_5.setTransform(0,-13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.6,-51.3,63.4,102.8);


(lib.Tween79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AjvAAIHfAA");
	this.shape.setTransform(3.2,24.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ADwD3InfAAIAAntIHfAAg");
	this.shape_1.setTransform(3.2,32.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjvD3IAAntIHfAAIAAHtg");
	this.shape_2.setTransform(3.2,32.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AA8jXIAAgUQAAgYgRgQQgRgRgXAAQgXAAgRARQgPAQgBAWIAAgeQAAgXgRgRQgRgRgXAAQgYAAgRARQgQARAAAXIAAB7Qg7gRghAYQgQANgFAPIgHAgQgFAvAHA/QAHBBA9BDQAeAhAdAVIgBBqIF6AAIAAiEQA3g3ANhjQAEgegBgfIgCinQAAgYgQgQQgRgRgYAAQgXAAgRARQgQAQgBAXIAAgYQAAgXgQgRQgRgQgYAAQgYAAgRAQQgQARAAAWIAABNAinhDIAAhNAg1jtIAABjACui+IAABE");
	this.shape_3.setTransform(0,-24.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AifFFIABhrQgdgUgeghQg9hDgHhBQgHhAAFguIAHggQAFgQAQgMQAhgYA7ASIAAh8QAAgXAQgRQARgQAYAAQAXAAARAQQARARAAAXIAAAeQABgWAPgRQARgQAXAAQAXAAARAQQARARAAAYIAAAUQAAgWAQgRQARgQAYAAQAYAAARAQQAQARAAAYIAAAXQABgXAQgQQARgRAXAAQAYAAARARQAQAQAAAZIACCmQABAegEAfQgNBjg3A2IAACFg");
	this.shape_4.setTransform(0,-24.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-58.6,61,117.3);


(lib.Tween78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AjvAAIHfAA");
	this.shape.setTransform(3.2,24.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ADwD3InfAAIAAntIHfAAg");
	this.shape_1.setTransform(3.2,32.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjvD3IAAntIHfAAIAAHtg");
	this.shape_2.setTransform(3.2,32.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AA8jXIAAgUQAAgYgRgQQgRgRgXAAQgXAAgRARQgPAQgBAWIAAgeQAAgXgRgRQgRgRgXAAQgYAAgRARQgQARAAAXIAAB7Qg7gRghAYQgQANgFAPIgHAgQgFAvAHA/QAHBBA9BDQAeAhAdAVIgBBqIF6AAIAAiEQA3g3ANhjQAEgegBgfIgCinQAAgYgQgQQgRgRgYAAQgXAAgRARQgQAQgBAXIAAgYQAAgXgQgRQgRgQgYAAQgYAAgRAQQgQARAAAWIAABNAinhDIAAhNACui+IAABEAg1jtIAABj");
	this.shape_3.setTransform(0,-24.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AifFFIABhrQgdgUgeghQg9hDgHhBQgHhAAFguIAHggQAFgQAQgMQAhgYA7ASIAAh8QAAgXAQgRQARgQAYAAQAXAAARAQQARARAAAXIAAAeQABgWAPgRQARgQAXAAQAXAAARAQQARARAAAYIAAAUQAAgWAQgRQARgQAYAAQAYAAARAQQAQARAAAYIAAAXQABgXAQgQQARgRAXAAQAYAAARARQAQAQAAAZIACCmQABAegEAfQgNBjg3A2IAACFg");
	this.shape_4.setTransform(0,-24.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-58.6,61,117.3);


(lib.Tween77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AjvAAIHfAA");
	this.shape.setTransform(3.2,-9.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ADwJLInfAAIAAyVIHfAAg");
	this.shape_1.setTransform(3.2,32.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjvJLIAAyVIHfAAIAASVg");
	this.shape_2.setTransform(3.2,32.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AA8jWIAAgVQAAgXgRgRQgRgRgXAAQgXAAgRARQgPAQgBAWIAAgeQAAgXgRgRQgRgQgXAAQgYAAgRAQQgQARAAAXIAAB8Qg7gSghAYQgKAIgHALIgEAJIgHAgQgFAvAHA/QAHBBA9BDQAeAhAdAVIgBBqIF6AAIAAiEQA3g3ANhjQAEgegBgfIgCimQAAgYgQgRQgRgRgYAAQgXAAgRARQgQAQgBAXIAAgXQAAgYgQgQQgRgRgYAAQgYAAgRARQgQAQAAAXIAABMAinhDIAAhMAg1jtIAABjACui+IAABE");
	this.shape_3.setTransform(0,-58.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AifFEIABhqQgdgUgeghQg9hDgHhBQgHg/AFguIAHghIAEgJQAHgLAKgHQAhgZA7ARIAAh7QAAgXAQgRQARgRAYAAQAXAAARARQARARAAAXIAAAeQABgWAPgRQARgQAXAAQAXAAARAQQARASAAAXIAAAVQAAgXAQgQQARgRAYAAQAYAAARARQAQAQAAAYIAAAXQABgXAQgQQARgRAXAAQAYAAARARQAQARAAAXIACCoQABAegEAfQgNBig3A3IAACDg");
	this.shape_4.setTransform(0,-58.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-92.6,61,185.3);


(lib.Tween76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AjvAAIHfAA");
	this.shape.setTransform(3.2,-9.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ADwJLInfAAIAAyVIHfAAg");
	this.shape_1.setTransform(3.2,32.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjvJLIAAyVIHfAAIAASVg");
	this.shape_2.setTransform(3.2,32.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AA8jWIAAgVQAAgXgRgRQgRgRgXAAQgXAAgRARQgPAQgBAWIAAgeQAAgXgRgRQgRgQgXAAQgYAAgRAQQgQARAAAXIAAB8AinhDIAAhMQg7gSghAYQgKAIgHALIgEAJIgHAgQgFAvAHA/QAHBBA9BDQAeAhAdAVIgBBqIF6AAIAAiEQA3g3ANhjQAEgegBgfIgCimQAAgYgQgRQgRgRgYAAQgXAAgRARQgQAQgBAXIAAgXQAAgYgQgQQgRgRgYAAQgYAAgRARQgQAQAAAXIAABMAg1jtIAABjACui+IAABE");
	this.shape_3.setTransform(0,-58.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AifFEIABhqQgdgUgeghQg9hDgHhBQgHg/AFguIAHghIAEgJQAHgLAKgHQAhgZA7ARIAAh7QAAgXAQgRQARgRAYAAQAXAAARARQARARAAAXIAAAeQABgWAPgRQARgQAXAAQAXAAARAQQARASAAAXIAAAVQAAgXAQgQQARgRAYAAQAYAAARARQAQAQAAAYIAAAXQABgXAQgQQARgRAXAAQAYAAARARQAQARAAAXIACCoQABAegEAfQgNBig3A3IAACDg");
	this.shape_4.setTransform(0,-58.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-92.6,61,185.3);


(lib.Tween75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AjvAAIHfAA");
	this.shape.setTransform(3.2,15.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AiniQQg6gRgiAYQgKAIgHAKIgEAKIgHAgQgFAvAHA/QAHBBA9BDQAeAhAdAVIgBBqIF6AAIAAiEQA3g3ANhjQAEgegBgfIgBinQAAgYgRgQQgRgRgYAAQgXAAgRARQgQAQgBAXIAAgYQAAgXgQgRQgRgQgYAAQgXAAgRAQQgRARAAAWIAAgUQAAgYgRgQQgRgRgXAAQgXAAgRARQgQAQAAAWIAAgeQAAgXgRgRQgRgQgXAAQgYAAgQAQQgRARAAAXgACui+IAABEAinhDIAAhNAA8jXIAABNAg1jtIAABj");
	this.shape_1.setTransform(0,-33.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AifFFIABhrQgdgUgeghQg9hDgHhBQgHhAAFguIAHggIAEgKQAHgKAKgIQAigYA6ASIAAh8QAAgXARgRQAQgQAYAAQAXAAARAQQARARAAAXIAAAeQAAgWAQgRQARgQAXAAQAXAAARAQQARARAAAYIAAAUQAAgWARgRQARgQAXAAQAYAAARAQQAQARAAAYIAAAXQABgXAQgQQARgRAXAAQAYAAARARQARAQAAAZIABCmQABAegEAfQgNBjg3A2IAACFg");
	this.shape_2.setTransform(0,-33.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("ADwFRInfAAIAAqhIHfAAg");
	this.shape_3.setTransform(3.2,32.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjvFRIAAqhIHfAAIAAKhg");
	this.shape_4.setTransform(3.2,32.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-67.6,61.1,135.3);


(lib.Tween74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AjvAAIHfAA");
	this.shape.setTransform(3.2,15.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ACui+IAABEACui+IAAgYQAAgXgQgRQgRgQgYAAQgXAAgRAQQgRARAAAWIAAgUQAAgYgRgQQgRgRgXAAQgXAAgRARQgQAQAAAWIAAgeQAAgXgRgRQgRgQgXAAQgYAAgQAQQgRARAAAXIAAB7Qg6gRgiAYQgKAIgHAKIgEAKIgHAgQgFAvAHA/QAHBBA9BDQAeAhAdAVIgBBqIF6AAIAAiEQA3g3ANhjQAEgegBgfIgBinQAAgYgRgQQgRgRgYAAQgXAAgRARQgQAQgBAXgAinhDIAAhNAA8jXIAABNAg1jtIAABj");
	this.shape_1.setTransform(0,-33.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AifFFIABhrQgdgUgeghQg9hDgHhBQgHhAAFguIAHggIAEgKQAHgKAKgIQAigYA6ASIAAh8QAAgXARgRQAQgQAYAAQAXAAARAQQARARAAAXIAAAeQAAgWAQgRQARgQAXAAQAXAAARAQQARARAAAYIAAAUQAAgWARgRQARgQAXAAQAYAAARAQQAQARAAAYIAAAXQABgXAQgQQARgRAXAAQAYAAARARQARAQAAAZIABCmQABAegEAfQgNBjg3A2IAACFg");
	this.shape_2.setTransform(0,-33.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("ADwFRInfAAIAAqhIHfAAg");
	this.shape_3.setTransform(3.2,32.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjvFRIAAqhIHfAAIAAKhg");
	this.shape_4.setTransform(3.2,32.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.5,-67.6,61.1,135.3);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.handandlighttruck1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 17 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAzRAkEIAA53INIAAIAAZ3g");
	mask.setTransform(412.1,230.8);

	// Layer 15
	this.instance = new lib.Tween74("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(771.2,558.7);

	this.instance_1 = new lib.Tween75("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(771.2,402.7);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},40).wait(1055));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,y:402.7},40,cjs.Ease.elasticInOut).wait(1055));

	// Layer 19 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AlHPrIAA/VIKPAAIAAfVg");
	mask_1.setTransform(699.6,364.5);

	// Layer 4
	this.instance_2 = new lib.Tween76("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(698.8,557.7);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween77("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(698.8,377.7);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},14).to({state:[{t:this.instance_3}]},40).to({state:[]},1032).wait(9));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({_off:true,y:377.7},40,cjs.Ease.elasticInOut).wait(1041));

	// Layer 20 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Ak1KUIAA0nIJrAAIAAUng");
	mask_2.setTransform(628.9,401.5);

	// Layer 6
	this.instance_4 = new lib.Tween78("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(628.9,541.2);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween79("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(628.9,411.7);

	var maskedShapeInstanceList = [this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},29).to({state:[{t:this.instance_5}]},40).wait(1026));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({_off:true,y:411.7},40,cjs.Ease.elasticInOut).wait(1026));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AMhY3QhBgHhMAIIjcAAIovAAQhuAAhtAFIgLgFIn0AAMAAAgwSQCpA+DJgWIAKAAIBkh4QAkAAAggIQAYgHAcgFIAoAeIAoAKQCeBLDEAKQCoAzDEgVQCWARCXAFMAAAAvMQgXgGgagCg");
	this.shape.setTransform(719.2,439.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1095));

	// Layer 7
	this.instance_6 = new lib.Tween80("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(699.8,670.8);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween81("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(699.8,208.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},29).to({state:[{t:this.instance_7}]},51).wait(1015));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(29).to({_off:false},0).to({_off:true,y:208.8},51,cjs.Ease.elasticInOut).wait(1015));

	// Layer 47
	this.instance_8 = new lib.Tween94("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(665.2,154.4);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween95("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(665.2,154.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},88).to({state:[{t:this.instance_9}]},10).to({state:[]},946).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(88).to({_off:false},0).to({_off:true},10).wait(997));

	// Layer 48
	this.instance_10 = new lib.Tween92("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(734.8,224.2);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween93("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(734.8,224.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},91).to({state:[{t:this.instance_11}]},7).to({state:[]},946).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(91).to({_off:false},0).to({_off:true},7,cjs.Ease.elasticInOut).wait(997));

	// Layer 49
	this.instance_12 = new lib.Tween90("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(734.5,154.5);
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween91("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(734.5,154.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},93).to({state:[{t:this.instance_13}]},5).to({state:[]},946).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(93).to({_off:false},0).to({_off:true},5,cjs.Ease.elasticInOut).wait(997));

	// Layer 50
	this.instance_14 = new lib.Tween88("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(664.7,224.1);
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween89("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(664.7,224.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},84).to({state:[{t:this.instance_15}]},14).to({state:[]},946).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(84).to({_off:false},0).to({_off:true},14,cjs.Ease.elasticInOut).wait(997));

	// Layer 52
	this.instance_16 = new lib.Tween84("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(749.3,189.2);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(94).to({_off:false},0).to({startPosition:0},4,cjs.Ease.elasticInOut).to({_off:true},946).wait(51));

	// Layer 53
	this.instance_17 = new lib.Tween82("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(699.8,140.1);
	this.instance_17._off = true;

	this.instance_18 = new lib.Tween83("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(699.8,140.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},91).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[]},946).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(91).to({_off:false},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).to({_off:true},1).wait(997));

	// Layer 51
	this.instance_19 = new lib.Tween86("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(650.8,189.1);
	this.instance_19._off = true;

	this.instance_20 = new lib.Tween87("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(650.8,189.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19}]},88).to({state:[{t:this.instance_20}]},10).to({state:[]},946).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(88).to({_off:false},0).to({_off:true},10,cjs.Ease.elasticInOut).wait(997));

	// Layer 1 copy 2
	this.instance_21 = new lib.cloud3();
	this.instance_21.parent = this;
	this.instance_21.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(316));

	// Layer 1
	this.instance_22 = new lib.cloud3();
	this.instance_22.parent = this;
	this.instance_22.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(316));

	// Layer 1 copy
	this.instance_23 = new lib.cloud1("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).to({_off:true},91).wait(1));

	// Layer 1 copy 3
	this.instance_24 = new lib.cloud1("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(301));

	// Layer 1
	this.instance_25 = new lib.cloud1("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(301));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,521.4);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 38,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;