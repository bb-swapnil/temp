$( document ).ready(function() {



	$('.navbtn, .close').on('click', function() {
		$('.bar ').toggleClass('animate');
		$('.nav-slider').toggleClass('active');
	});


	$('.bxslider.left').bxSlider({
		mode: 'vertical',
		pager:false,
		controls:false,
		infiniteLoop:true,
		auto:true,
		speed:300,
		pause:2000,
		autoDirection: 'previous',
	});

	$('.bxslider.right').bxSlider({
		mode: 'vertical',
		pager:false,
		controls:false,
		infiniteLoop:true,
		auto:true,
		speed:300,
		pause:2000

	});	



$(window).scroll(function() {
if ($(this).scrollTop() > 1){  
    $('.top-header').addClass("sticky");
  }
  else{
    $('.top-header').removeClass("sticky");
  }
});




	$('.bxslider.gif-slider').bxSlider({
		mode: 'fade',
		// pager:true,
		// controls:true,
		infiniteLoop:true,
		// auto:true,
		speed:3000,
		pause:2000,


	});




});
