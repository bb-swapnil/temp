(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween158 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAANIAAgZ");
	this.shape.setTransform(0,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgnAnQAAARAMAMQAMALAPAAQAQAAAMgLQAMgMAAgRQAAgRgMgLQgLgLgRAAQgQAAgLgKQgMgLAAgSQAAgQAMgMQAMgLAPAAQAQAAAMALQAMAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8QgzgzAAhJQAAhIAzgzQAzgzBIAAQBJAAAzAzQA0AzAABIQAABJg0AzQgzA0hJAAQhIAAgzg0g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween157 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,9.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA8IAAh4");
	this.shape_1.setTransform(0,-22.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-30.1,3,60.3);


(lib.Tween156 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACrIAAlV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.2);


(lib.Tween155 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-26.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-30.1,3,60.3);


(lib.Tween154 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAANIAAgZ");
	this.shape.setTransform(0,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgmAnQAAAQALANQAMALAPAAQARAAALgLQAMgNAAgQQAAgRgMgLQgLgLgRAAQgQAAgLgKQgLgLAAgSQAAgQALgMQAMgLAPAAQARAAALALQAMAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0gzAAhJQAAhHA0g0QA0g0BHAAQBJAAAzA0QA0A0gBBHQABBJg0AzQgzA0hJgBQhHABg0g0g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween153 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA9IAAh5");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.4);


(lib.Tween152 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACqIAAlU");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.1);


(lib.Tween151 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.4);


(lib.Tween150 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAANIAAgZ");
	this.shape.setTransform(0,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgnAnQAAARAMALQAMAMAPAAQAQAAAMgMQAMgLAAgRQAAgRgMgLQgLgLgRAAQgQAAgLgKQgMgLAAgSQAAgQAMgMQAMgLAPAAQAQAAAMALQAMAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8QgzgzgBhJQABhIAzgzQA0gzBHAAQBJAAAzAzQA0AzgBBIQABBJg0AzQgzA0hJAAQhHAAg0g0g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween149 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA9IAAh5");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween148 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACrIAAlV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.2);


(lib.Tween147 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween146 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAANIAAgZ");
	this.shape.setTransform(0,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgmAnQAAAQALANQAMALAPAAQARAAALgLQAMgNAAgQQAAgRgMgLQgLgLgRAAQgQAAgLgKQgLgLAAgSQAAgQALgMQAMgLAPAAQARAAALALQAMAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8QgzgzAAhJQAAhIAzgzQAzg0BIABQBJgBAzA0QA0AzAABIQAABJg0AzQgzAzhJABQhIgBgzgzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween145 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA9IAAh5");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.4);


(lib.Tween144 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACqIAAlU");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.1);


(lib.Tween143 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.4);


(lib.Tween142 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAANIAAgZ");
	this.shape.setTransform(0,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgmAnQAAARALAMQAMALAPAAQARAAALgLQALgMAAgRQAAgRgLgLQgLgLgRAAQgQAAgLgKQgLgLAAgSQAAgQALgMQAMgLAPAAQARAAALALQALAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0gzAAhJQAAhIA0gzQA0g0BHAAQBIAAA0A0QA0AzAABIQAABJg0AzQgzA0hJAAQhHAAg0g0g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.2);


(lib.Tween141 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA8IAAh4");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween140 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACrIAAlV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.2);


(lib.Tween139 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween138 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA9IAAh5");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween137 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACrIAAlV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.2);


(lib.Tween136 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween135 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAANIAAgZ");
	this.shape.setTransform(0,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgnAnQAAARAMALQALAMAQAAQAQAAAMgMQALgLAAgRQAAgRgLgLQgLgLgRAAQgQAAgLgKQgMgLAAgSQAAgQAMgMQALgLAQAAQAQAAAMALQALAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0gzAAhJQAAhIA0gzQA0g0BHABQBJgBAzA0QA0A0gBBHQABBJg0AzQgzAzhJABQhHgBg0gzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA9IAAh5");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween133 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAAC/IAAl9");
	this.shape.setTransform(0,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAA9IAAh5");
	this.shape_1.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween132 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACrIAAlV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.2);


(lib.Tween131 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAACrIAAlV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-18.5,3,37.2);


(lib.Tween130 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween129 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,1,1).p("AAADqIAAnT");
	this.shape.setTransform(0,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,1,1).p("AAAAUIAAgn");
	this.shape_1.setTransform(0,-27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween128 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape.setTransform(0,8.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgmAnQAAARALALQAMAMAPAAQARAAALgMQALgLAAgRQAAgRgLgLQgLgLgRAAQgQAAgLgKQgLgLAAgSQAAgQALgMQAMgLAPAAQARAAALALQALAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0gzAAhJQAAhIA0gzQAzg0BIABQBJgBAzA0QAzAzAABIQAABJgzAzQgzAzhJABQhIgBgzgzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween127 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAQIAAgf");
	this.shape.setTransform(0,8.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,1,1).p("AAAAPIAAgd");
	this.shape_1.setTransform(0,-9.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,1,1).p("AgmAnQAAARALALQAMAMAPAAQARAAALgMQALgLAAgRQAAgRgLgLQgLgLgRAAQgQAAgLgKQgLgLAAgSQAAgQALgMQAMgLAPAAQARAAALALQALAMAAAQ");
	this.shape_2.setTransform(0,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("Ah7B8Qg0gzAAhJQAAhIA0gzQAzg0BIABQBJgBAzA0QAzAzAABIQAABJgzAzQgzAzhJABQhIgBgzgzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35.1,35.1);


(lib.Tween124 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjqBcQArgZAwgVQCahDCeABIgPgTQAYgHAXgFQAmAcAdAlQgRgEgbABQgzAAgsAVIBQAfIg0AaIAXgWQg1gFhTADQilAGiSAqQAMgIAVgNgABUhaIAdgGQAcAJAZAOIgmALQgVgSgXgKgAgahuIAbgCQAogBAnAIIgXAFQgngMgsACg");
	this.shape.setTransform(-1.6,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D71E48").s().p("AkNEOQhwhvAAifQAAidBwhwQBvhwCeAAQCeAABwBwQBwBwAACdQAACfhwBvQhwBwieAAQidAAhwhwg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.2,-38.2,76.5,76.5);


(lib.Tween123 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AA8g7Ih/AAIAoB4IBfAA");
	this.shape.setTransform(239.8,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("ABRAAQAAAigXAXQgYAYgiAAQggAAgZgYQgXgXAAgiQAAghAXgXQAZgYAgAAQAiAAAYAYQAXAXAAAhg");
	this.shape_1.setTransform(210.9,53.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("ADLAAQAABUg7A8Qg8A7hUAAQhTAAg7g7Qg8g8AAhUQAAhTA8g7QA7g8BTAAQBUAAA8A8QA7A7AABTg");
	this.shape_2.setTransform(210.9,53.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("ACmCGIhBAAQhtAAhPhOQhOhOAAhvIFLAAg");
	this.shape_3.setTransform(181.2,-5.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AhUGZImGAAIgBsxIILAAQAMAAAJAJQAJAJAAAMIAAF1ID3AAQA/AAAsAsQAsAsAAA+IAAEIIibAA");
	this.shape_4.setTransform(199,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,1,1).p("AeoJ5Mg9QAAAQgMAAgJgIQgJgJAAgNIAAy1QAAgNAJgIQAJgJAMAAMA9QAAAQANAAAJAJQAIAIAAANIAAS1QAAANgIAJQgJAIgNAAg");
	this.shape_5.setTransform(-47.5,-10.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_6.setTransform(-207.5,57.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg7A7Qg8A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_7.setTransform(-207.4,63.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_8.setTransform(-161.9,57.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhUAAg7g7Qg7g7AAhU");
	this.shape_9.setTransform(-161.8,63.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_10.setTransform(65.7,57.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_11.setTransform(65.8,63.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgXAXQgYAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_12.setTransform(111.7,57.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_13.setTransform(111.7,63.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-248,-75.4,496.2,150.8);


(lib.Tween122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AA8g7Ih/AAIAoB4IBfAA");
	this.shape.setTransform(239.8,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("ABRAAQAAAigXAXQgYAYgiAAQggAAgZgYQgXgXAAgiQAAghAXgXQAZgYAgAAQAiAAAYAYQAXAXAAAhg");
	this.shape_1.setTransform(210.9,53.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("ADLAAQAABUg7A8Qg8A7hUAAQhTAAg7g7Qg8g8AAhUQAAhTA8g7QA7g8BTAAQBUAAA8A8QA7A7AABTg");
	this.shape_2.setTransform(210.9,53.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("ACmCGIhBAAQhtAAhPhOQhOhOAAhvIFLAAg");
	this.shape_3.setTransform(181.2,-5.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AhUGZImGAAIgBsxIILAAQAMAAAJAJQAJAJAAAMIAAF1ID3AAQA/AAAsAsQAsAsAAA+IAAEIIibAA");
	this.shape_4.setTransform(199,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,1,1).p("AeoJ5Mg9QAAAQgMAAgJgIQgJgJAAgNIAAy1QAAgNAJgIQAJgJAMAAMA9QAAAQANAAAJAJQAIAIAAANIAAS1QAAANgIAJQgJAIgNAAg");
	this.shape_5.setTransform(-47.5,-10.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_6.setTransform(-207.5,57.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg7A7Qg8A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_7.setTransform(-207.4,63.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_8.setTransform(-161.9,57.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhUAAg7g7Qg7g7AAhU");
	this.shape_9.setTransform(-161.8,63.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgYAXQgXAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_10.setTransform(65.7,57.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_11.setTransform(65.8,63.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#BABABA").ss(3,1,1).p("ABRgnQAAAhgXAXQgYAYgiAAQggAAgYgYQgYgXAAgh");
	this.shape_12.setTransform(111.7,57.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#BABABA").ss(3,1,1).p("ADLhlQAABUg8A7Qg7A7hUAAQhTAAg8g7Qg7g7AAhU");
	this.shape_13.setTransform(111.7,63.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-248,-75.4,496.2,150.8);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.MAR2017 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Tween124("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(652.5,644.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(38).to({_off:false},0).to({y:362.1},46,cjs.Ease.elasticInOut).to({_off:true},1010).wait(28));

	// Layer 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg0TARIMAAAgiPMBonAAAMAAAAiPg");
	mask.setTransform(734.8,402.6);

	// Layer 5
	this.instance_1 = new lib.Tween122("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(128,372.7);

	this.instance_2 = new lib.Tween123("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(700,372.7);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},59).to({state:[]},1035).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true,x:700},59,cjs.Ease.elasticInOut).wait(1063));

	// Layer 36
	this.instance_3 = new lib.Tween158("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(830.6,-46);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(148).to({_off:false},0).to({y:254},15,cjs.Ease.elasticInOut).wait(959));

	// Layer 37
	this.instance_4 = new lib.Tween157("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(845.2,-67.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(155).to({_off:false},0).to({y:228.7},13,cjs.Ease.elasticInOut).to({_off:true},926).wait(28));

	// Layer 38
	this.instance_5 = new lib.Tween156("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(828.6,-76.9);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(159).to({_off:false},0).to({y:223.1},13,cjs.Ease.elasticInOut).to({_off:true},922).wait(28));

	// Layer 39
	this.instance_6 = new lib.Tween155("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(814.9,-55.9);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(164).to({_off:false},0).to({y:224.1},12,cjs.Ease.elasticInOut).to({_off:true},918).wait(28));

	// Layer 33
	this.instance_7 = new lib.Tween154("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(770.7,-44.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(141).to({_off:false},0).to({y:275.5},14,cjs.Ease.elasticInOut).to({_off:true},963).wait(4));

	// Layer 34
	this.instance_8 = new lib.Tween153("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(785.3,-54.9);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(151).to({_off:false},0).to({y:249.1},10,cjs.Ease.elasticInOut).to({_off:true},933).wait(28));

	// Layer 35
	this.instance_9 = new lib.Tween152("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(768.7,-75.4);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(154).to({_off:false},0).to({y:244.6},10,cjs.Ease.elasticInOut).to({_off:true},930).wait(28));

	// Layer 8
	this.instance_10 = new lib.Tween151("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(755.1,-57.4);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(156).to({_off:false},0).to({y:244.6},11,cjs.Ease.elasticInOut).to({_off:true},927).wait(28));

	// Layer 30
	this.instance_11 = new lib.Tween150("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(710.8,-40.4);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(137).to({_off:false},0).to({y:239.6},12,cjs.Ease.elasticInOut).to({_off:true},964).wait(9));

	// Layer 31
	this.instance_12 = new lib.Tween149("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(725.5,-66.7);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(145).to({_off:false},0).to({y:213.3},12,cjs.Ease.elasticInOut).to({_off:true},937).wait(28));

	// Layer 32
	this.instance_13 = new lib.Tween148("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(708.8,-91.3);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(149).to({_off:false},0).to({y:208.7},12,cjs.Ease.elasticInOut).to({_off:true},933).wait(28));

	// Layer 12
	this.instance_14 = new lib.Tween147("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(695.2,-71.3);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(152).to({_off:false},0).to({y:208.7},12,cjs.Ease.elasticInOut).to({_off:true},930).wait(28));

	// Layer 27
	this.instance_15 = new lib.Tween146("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(650.9,-24.5);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(132).to({_off:false},0).to({y:255.5},13,cjs.Ease.elasticInOut).to({_off:true},962).wait(15));

	// Layer 28
	this.instance_16 = new lib.Tween145("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(665.6,-70.9);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(139).to({_off:false},0).to({y:229.1},14,cjs.Ease.elasticInOut).to({_off:true},941).wait(28));

	// Layer 29
	this.instance_17 = new lib.Tween144("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(648.9,-55.4);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(143).to({_off:false},0).to({y:224.6},14,cjs.Ease.elasticInOut).to({_off:true},937).wait(28));

	// Layer 9
	this.instance_18 = new lib.Tween143("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(635.3,-75.4);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(146).to({_off:false},0).to({y:224.6},15,cjs.Ease.elasticInOut).to({_off:true},933).wait(28));

	// Layer 24
	this.instance_19 = new lib.Tween142("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(591,-26);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(127).to({_off:false},0).to({y:214},15,cjs.Ease.elasticInOut).to({_off:true},966).wait(14));

	// Layer 25
	this.instance_20 = new lib.Tween141("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(605.7,-72.3);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(138).to({_off:false},0).to({y:187.7},13,cjs.Ease.elasticInOut).to({_off:true},943).wait(28));

	// Layer 26
	this.instance_21 = new lib.Tween140("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(589,-116.9);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(141).to({_off:false},0).to({y:183.1},14,cjs.Ease.elasticInOut).to({_off:true},939).wait(28));

	// Layer 7
	this.instance_22 = new lib.Tween139("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(575.4,-136.9);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(144).to({_off:false},0).to({y:183.1},14,cjs.Ease.elasticInOut).to({_off:true},936).wait(28));

	// Layer 21
	this.instance_23 = new lib.Tween135("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(531.2,-40.4);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(118).to({_off:false},0).to({y:259.6},17,cjs.Ease.elasticInOut).to({_off:true},964).wait(23));

	// Layer 22
	this.instance_24 = new lib.Tween136("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(515.5,-83.3);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(130).to({_off:false},0).to({y:228.7},15,cjs.Ease.elasticInOut).to({_off:true},949).wait(28));

	// Layer 23
	this.instance_25 = new lib.Tween137("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(529.1,-111.3);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(137).to({_off:false},0).to({y:228.7},14,cjs.Ease.elasticInOut).to({_off:true},943).wait(28));

	// Layer 10
	this.instance_26 = new lib.Tween138("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(545.8,-126.7);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(140).to({_off:false},0).to({y:233.3},14,cjs.Ease.elasticInOut).to({_off:true},940).wait(28));

	// Layer 13
	this.instance_27 = new lib.Tween127("synched",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(471.3,-32.4);
	this.instance_27._off = true;

	this.instance_28 = new lib.Tween128("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(471.3,249.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_27}]},113).to({state:[{t:this.instance_28}]},14).to({state:[]},967).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(113).to({_off:false},0).to({_off:true,y:249.6},14,cjs.Ease.elasticInOut).wait(995));

	// Layer 19
	this.instance_29 = new lib.Tween129("synched",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(455.6,-41.3);
	this.instance_29._off = true;

	this.instance_30 = new lib.Tween130("synched",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(455.6,218.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_29}]},123).to({state:[{t:this.instance_30}]},12).to({state:[]},959).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(123).to({_off:false},0).to({_off:true,y:218.7},12,cjs.Ease.elasticInOut).wait(987));

	// Layer 20
	this.instance_31 = new lib.Tween131("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(469.3,-101.3);
	this.instance_31._off = true;

	this.instance_32 = new lib.Tween132("synched",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(469.3,218.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_31}]},127).to({state:[{t:this.instance_32}]},11).to({state:[]},956).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(127).to({_off:false},0).to({_off:true,y:218.7},11,cjs.Ease.elasticInOut).wait(984));

	// Layer 11
	this.instance_33 = new lib.Tween133("synched",0);
	this.instance_33.parent = this;
	this.instance_33.setTransform(485.9,-56.7);
	this.instance_33._off = true;

	this.instance_34 = new lib.Tween134("synched",0);
	this.instance_34.parent = this;
	this.instance_34.setTransform(485.9,223.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_33}]},132).to({state:[{t:this.instance_34}]},10).to({state:[]},952).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(132).to({_off:false},0).to({_off:true,y:223.3},10,cjs.Ease.elasticInOut).wait(980));

	// Layer 1 copy 2
	this.instance_35 = new lib.cloud3();
	this.instance_35.parent = this;
	this.instance_35.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_35).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(343));

	// Layer 1
	this.instance_36 = new lib.cloud3();
	this.instance_36.parent = this;
	this.instance_36.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_36).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(343));

	// Layer 1 copy
	this.instance_37 = new lib.cloud1("synched",0);
	this.instance_37.parent = this;
	this.instance_37.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_37._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).to({_off:true},91).wait(28));

	// Layer 1 copy 3
	this.instance_38 = new lib.cloud1("synched",0);
	this.instance_38.parent = this;
	this.instance_38.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_38).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(328));

	// Layer 1
	this.instance_39 = new lib.cloud1("synched",0);
	this.instance_39.parent = this;
	this.instance_39.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_39).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(328));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,182.3);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 36,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;