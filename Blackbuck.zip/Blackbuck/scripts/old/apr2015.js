(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween119 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AAdAAQAAANgIAIQgIAJgNAAQgLAAgJgJQgJgIAAgNQAAgLAJgIQAJgJALAAQANAAAIAJQAIAIAAALg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-4.4,8.9,8.9);


(lib.Tween118 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AAdAAQAAANgIAIQgIAJgNAAQgLAAgJgJQgJgIAAgNQAAgLAJgIQAJgJALAAQANAAAIAJQAIAIAAALg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-4.4,8.9,8.9);


(lib.Tween117 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AAdAAQAAAMgIAJQgJAIgMAAQgMAAgIgIQgIgJAAgMQAAgMAIgIQAIgJAMAAQAMAAAJAJQAIAIAAAMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-4.4,8.9,8.9);


(lib.Tween116 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AAdAAQAAAMgIAJQgJAIgMAAQgMAAgIgIQgIgJAAgMQAAgMAIgIQAIgJAMAAQAMAAAJAJQAIAIAAAMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-4.4,8.9,8.9);


(lib.Tween115 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AASAAQAAAHgFAGQgGAFgHAAQgGAAgFgFQgGgGAAgHQAAgGAGgFQAFgGAGAAQAHAAAGAGQAFAFAAAGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.6,6.6);


(lib.Tween114 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AASAAQAAAHgFAGQgGAFgHAAQgGAAgFgFQgGgGAAgHQAAgGAGgFQAFgGAGAAQAHAAAGAGQAFAFAAAGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.6,6.6);


(lib.Tween113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AASAAQAAAIgFAFQgGAFgHAAQgHAAgFgFQgFgFAAgIQAAgGAFgGQAFgFAHAAQAHAAAGAFQAFAGAAAGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.5,6.5);


(lib.Tween112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AASAAQAAAIgFAFQgGAFgHAAQgHAAgFgFQgFgFAAgIQAAgGAFgGQAFgFAHAAQAHAAAGAFQAFAGAAAGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.5,6.5);


(lib.Tween111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AASAAQAAAHgFAGQgGAFgHAAQgGAAgGgFQgFgGAAgHQAAgGAFgFQAGgGAGAAQAHAAAGAGQAFAFAAAGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.6,6.6);


(lib.Tween110 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AASAAQAAAHgFAGQgGAFgHAAQgGAAgGgFQgFgGAAgHQAAgGAFgFQAGgGAGAAQAHAAAGAGQAFAFAAAGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.2,-3.2,6.6,6.6);


(lib.Tween109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("Ag5AAQAAgEAEgDQADgEAFAAIBcAAQAEAAADAEQAEADAAAEQAAAFgEADQgDAEgEAAIhcAAQgFAAgDgEQgEgDAAgFg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AAAA6QgEAAgDgEQgEgDAAgFIAAhbQAAgFAEgEQADgDAEAAQAFAAADADQADAEAAAFIAABbQAAAFgDADQgDAEgFAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,-7.3,14.6,14.6);


(lib.Tween108 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("Ag5AAQAAgEAEgDQADgEAFAAIBcAAQAEAAADAEQAEADAAAEQAAAFgEADQgDAEgEAAIhcAAQgFAAgDgEQgEgDAAgFg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AAAA6QgEAAgDgEQgEgDAAgFIAAhbQAAgFAEgEQADgDAEAAQAFAAADADQADAEAAAFIAABbQAAAFgDADQgDAEgFAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,-7.3,14.6,14.6);


(lib.Tween107 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AgiAAQAAgCACgCQADgCACAAIA3AAQAHAAAAAGQAAAHgHAAIg3AAQgCAAgDgCQgCgCAAgDg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AAAAiQgCAAgCgCQgCgCAAgDIAAg2QAAgHAGAAQAHAAAAAHIAAA2QAAAHgHAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,-4.9,9.9,9.9);


(lib.Tween106 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AgiAAQAAgCACgCQADgCACAAIA3AAQAHAAAAAGQAAAHgHAAIg3AAQgCAAgDgCQgCgCAAgDg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AAAAiQgCAAgCgCQgCgCAAgDIAAg2QAAgHAGAAQAHAAAAAHIAAA2QAAAHgHAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,-4.9,9.9,9.9);


(lib.Tween105 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AghAAQAAgGAGAAIA3AAQAGAAAAAGQAAAHgGAAIg3AAQgGAAAAgHg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AAAAiQgGAAAAgHIAAg2QAAgGAGAAQAHAAAAAGIAAA2QAAAHgHAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,-4.9,9.9,9.9);


(lib.Tween104 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AghAAQAAgGAGAAIA3AAQAGAAAAAGQAAAHgGAAIg3AAQgGAAAAgHg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AAAAiQgGAAAAgHIAAg2QAAgGAGAAQAHAAAAAGIAAA2QAAAHgHAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,-4.9,9.9,9.9);


(lib.Tween103 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AgWgFIAMAFQANAEALAA");
	this.shape.setTransform(0.5,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.3,-2,6.7,4);


(lib.Tween102 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AgWgFIAMAFQANAEALAA");
	this.shape.setTransform(0.5,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.3,-2,6.7,4);


(lib.Tween101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AAdAAQAAANgIAIQgIAJgNAAQgLAAgJgJQgJgIAAgNQAAgLAJgIQAJgKALAAQANAAAIAKQAIAIAAALg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-4.4,8.9,8.9);


(lib.Tween100 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AAdAAQAAANgIAIQgIAJgNAAQgLAAgJgJQgJgIAAgNQAAgLAJgIQAJgKALAAQANAAAIAKQAIAIAAALg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-4.4,8.9,8.9);


(lib.Tween99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D71E48").ss(2.5).p("AijgoIAuBLID2AAIAihL");
	this.shape.setTransform(-0.1,66.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkAKQAngRApAAIgEgEQAFgCAHgBQAIAFAJALQgSgDgSAHIAVAIIgNAHIAGgGQgOgBgWABQgqABglALgAAWgZIAHgBIAOAGIgKADg");
	this.shape_1.setTransform(0.1,-45.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D71E48").s().p("AhVBWQgkgjAAgzQAAgxAkgkQAkgkAxAAQAzAAAjAkQAkAkAAAxQAAAzgkAjQgjAkgzAAQgxAAgkgkg");
	this.shape_2.setTransform(0.1,-45.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D71E48").ss(2.5).p("AAAB5QgxAAgjgkQgjgjAAgyQAAgxAjgjQAjgkAxAAQAyAAAjAkQAkAjAAAxQAAAygkAjQgjAkgyAAg");
	this.shape_3.setTransform(0.3,-10.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D71E48").ss(2.5).p("AElEgQBDitAAi2QAAkgiCkCQhkjHhuhOQgHgFgJgBQgIAAgIAFQgYARghAfQhBA9g2BUQhIBvgrCJQg5C1AADSQgCAtAHA/QAOB7ArB2QgtA1gcBAQgnBaAABkIAAABQAAADAIBWQALBbAOAjQAEALALAFQAKAFALgEIAggKIAQA4QAEAOAOAFQAPAFAMgJICohxICbAAICuBzQAHAEAIAAIAKgBQAMgFAFgNQAIgPAPgxIAlAMQALAFAMgGQALgGAEgMQAYhYgChoQgCjOh0h5g");
	this.shape_4.setTransform(0,-20.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(2.5,0,1).p("AhijNIAFAyQAIA+AQA4QA2CxB5A4");
	this.shape_5.setTransform(22.7,90.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(2.5,0,1).p("ABhjAIgFAtQgIA2gRAzQg1Chh1BA");
	this.shape_6.setTransform(-21.6,89.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.5,-117.9,85.9,229.6);


(lib.Tween98 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D71E48").ss(2.5).p("AijgoIAuBLID2AAIAihL");
	this.shape.setTransform(-0.1,66.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkAKQAngRApAAIgEgEQAFgCAHgBQAIAFAJALQgSgDgSAHIAVAIIgNAHIAGgGQgOgBgWABQgqABglALgAAWgZIAHgBIAOAGIgKADg");
	this.shape_1.setTransform(0.1,-45.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D71E48").s().p("AhVBWQgkgjAAgzQAAgxAkgkQAkgkAxAAQAzAAAjAkQAkAkAAAxQAAAzgkAjQgjAkgzAAQgxAAgkgkg");
	this.shape_2.setTransform(0.1,-45.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D71E48").ss(2.5).p("AAAB5QgxAAgjgkQgjgjAAgyQAAgxAjgjQAjgkAxAAQAyAAAjAkQAkAjAAAxQAAAygkAjQgjAkgyAAg");
	this.shape_3.setTransform(0.3,-10.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D71E48").ss(2.5).p("AElEgQBDitAAi2QAAkgiCkCQhkjHhuhOQgHgFgJgBQgIAAgIAFQgYARghAfQhBA9g2BUQhIBvgrCJQg5C1AADSQgCAtAHA/QAOB7ArB2QgtA1gcBAQgnBaAABkIAAABQAAADAIBWQALBbAOAjQAEALALAFQAKAFALgEIAggKIAQA4QAEAOAOAFQAPAFAMgJICohxICbAAICuBzQAHAEAIAAIAKgBQAMgFAFgNQAIgPAPgxIAlAMQALAFAMgGQALgGAEgMQAYhYgChoQgCjOh0h5g");
	this.shape_4.setTransform(0,-20.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(2.5,0,1).p("AhijNIAFAyQAIA+AQA4QA2CxB5A4");
	this.shape_5.setTransform(22.7,90.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(2.5,0,1).p("ABhjAIgFAtQgIA2gRAzQg1Chh1BA");
	this.shape_6.setTransform(-21.6,89.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.5,-117.9,85.9,229.6);


(lib.Tween97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("ADJgyQhDg9hcAAQhiAAhGBGQhGBFAABj");
	this.shape.setTransform(-6.2,24.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ACyhjQAAgOACgOQgpgMgoAAQhyAAhSBRQhSBRAABzIABAR");
	this.shape_1.setTransform(31.9,4.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,0,1).p("AjPhsQAfgIAfAAQBhAABEBEQBFBEAABhIB7AA");
	this.shape_2.setTransform(129.7,21.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AERD0QAthLAAhYQAAiDhehdQhdhdiDAAQh8AAhbBUQhbBUgLB5");
	this.shape_3.setTransform(81.6,-13.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,0,1).p("ADnh1QgNgBgHAAQhiAAhFBGQhFBEAABjIjOAA");
	this.shape_4.setTransform(-127.7,24.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,0,1).p("ADvCMQAAhuhOhNQhNhNhtAAQhAAAg5AdQg3AcglAxQADAXAAAY");
	this.shape_5.setTransform(-9,3.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,0,1).p("AFpBtQgRiGhmhaQhnhbiJAAQiWAAhqBqQhqBpAACXQAAAfAFAg");
	this.shape_6.setTransform(-69,-9.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.4,-39,304.8,78.1);


(lib.Tween96 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("ADJgyQhDg9hcAAQhiAAhGBGQhGBFAABj");
	this.shape.setTransform(-6.2,24.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("ACyhjQAAgOACgOQgpgMgoAAQhyAAhSBRQhSBRAABzIABAR");
	this.shape_1.setTransform(31.9,4.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,0,1).p("AjPhsQAfgIAfAAQBhAABEBEQBFBEAABhIB7AA");
	this.shape_2.setTransform(129.7,21.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AERD0QAthLAAhYQAAiDhehdQhdhdiDAAQh8AAhbBUQhbBUgLB5");
	this.shape_3.setTransform(81.6,-13.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,0,1).p("ADnh1QgNgBgHAAQhiAAhFBGQhFBEAABjIjOAA");
	this.shape_4.setTransform(-127.7,24.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,0,1).p("ADvCMQAAhuhOhNQhNhNhtAAQhAAAg5AdQg3AcglAxQADAXAAAY");
	this.shape_5.setTransform(-9,3.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,0,1).p("AFpBtQgRiGhmhaQhnhbiJAAQiWAAhqBqQhqBpAACXQAAAfAFAg");
	this.shape_6.setTransform(-69,-9.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.4,-39,304.8,78.1);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.APR2015 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 91 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_44 = new cjs.Graphics().p("EgIvAnvIAUoXIBG0eIgyloICCiMIhuAAIAek1IAAiWIgyjnIBakEIgemQIAyl8QABqWF7lcIF7FAICqDmIAAI6IAeB4IAKCCIgKCMIgyCqIhQB4IA8C0IBGEOIgUCWIhkB4IAAENIAoH1IAUcDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_graphics_44,x:676.1,y:345.3}).wait(1207));

	// Layer 90
	this.instance = new lib.Tween98("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(676.4,711.4,0.756,0.756,0,0,0,0.1,0.1);
	this.instance._off = true;

	this.instance_1 = new lib.Tween99("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(676.3,263.3);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},45).to({state:[{t:this.instance_1}]},51).to({state:[]},1050).wait(105));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45).to({_off:false},0).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:676.3,y:263.3},51,cjs.Ease.elasticInOut).wait(1155));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AgPAAIAfAA");
	this.shape.setTransform(842.7,442.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("Ag/gyQASArAAAxIB7AA");
	this.shape_1.setTransform(836.5,438.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,0,1).p("Ai0h0QAFAAAFAAQBgAABFBEQBEBEAABhIB7AA");
	this.shape_2.setTransform(825.7,431);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,0,1).p("AjPhsQAfgIAfAAQBhAABEBEQBFBEAABhIB7AA");
	this.shape_3.setTransform(823.1,431);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,0,1).p("AgUAzQAdgzAKg3");
	this.shape_4.setTransform(804.4,415);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,0,1).p("AgXCEQAshLAAhXQAAg3gQgx");
	this.shape_5.setTransform(804.6,406.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,0,1).p("AACDGQAthLAAhYQAAiDhchdQgDgCgCgD");
	this.shape_6.setTransform(802.1,400.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#BABABA").ss(3,0,1).p("ACZD0QAthLAAhYQAAiDhdhdQhdhdiDAAQgvAAgqAM");
	this.shape_7.setTransform(786.9,395.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#BABABA").ss(3,0,1).p("ADhD0QAthLAAhYQAAiDhdhdQhdhdiDAAQh8AAhbBUQgEAEgDAD");
	this.shape_8.setTransform(779.7,395.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#BABABA").ss(3,0,1).p("AEMD0QAthLAAhYQAAiDhdhdQhehdiCAAQh9AAhbBUQhGBBgWBX");
	this.shape_9.setTransform(775.5,395.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#BABABA").ss(3,0,1).p("AAyAUQAAgOABgNQgpgMgnAAQgLAAgKAB");
	this.shape_10.setTransform(738.1,401.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#BABABA").ss(3,0,1).p("AERD0QAthLAAhYQAAiDhehdQhdhdiDAAQh8AAhbBUQhbBUgLB5");
	this.shape_11.setTransform(775,395.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#BABABA").ss(3,0,1).p("AByASQAAgOACgNQgpgMgoAAQhXAAhFAu");
	this.shape_12.setTransform(731.7,402.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#BABABA").ss(3,0,1).p("ACVgKQAAgNACgPQgpgMgoAAQhyAAhSBRQgNAMgLAO");
	this.shape_13.setTransform(728.2,404.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#BABABA").ss(3,0,1).p("ACngmQAAgOABgOQgpgMgoAAQhyAAhSBQQgnAngUAv");
	this.shape_14.setTransform(726.4,407.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#BABABA").ss(3,0,1).p("ABDAgQg9g2hRgF");
	this.shape_15.setTransform(700.7,426.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#BABABA").ss(3,0,1).p("ACyhjQAAgOACgOQgpgMgoAAQhyAAhSBRQhSBRAABzIABAR");
	this.shape_16.setTransform(725.3,413.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#BABABA").ss(3,0,1).p("AByAgQhEg8hbAAQgnAAgiAL");
	this.shape_17.setTransform(696,426.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#BABABA").ss(3,0,1).p("ACbAgQhEg8hbAAQhWAAhAA1");
	this.shape_18.setTransform(691.9,426.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#BABABA").ss(3,0,1).p("AC4AIQhEg8hcAAQhhAAhGBFQgUAUgPAX");
	this.shape_19.setTransform(689,428.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#BABABA").ss(3,0,1).p("ADFgTQhEg9hcAAQhhAAhGBGQguAsgQA6");
	this.shape_20.setTransform(687.7,431.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#BABABA").ss(3,0,1).p("ADJgyQhDg9hcAAQhiAAhGBGQhGBFAABj");
	this.shape_21.setTransform(687.2,434.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_5},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape_3}]},1).to({state:[{t:this.shape_7},{t:this.shape_3}]},1).to({state:[{t:this.shape_8},{t:this.shape_3}]},1).to({state:[{t:this.shape_9},{t:this.shape_3}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_10}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_12}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_13}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_14}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_17}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_18}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_19}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_20}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_21}]},1).to({state:[{t:this.shape_11},{t:this.shape_3},{t:this.shape_16},{t:this.shape_21}]},1).to({state:[]},1127).wait(105));

	// Layer 4
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#BABABA").ss(3,0,1).p("ACfhnQgaAPgXAXQhGBFAABiIjNAA");
	this.shape_22.setTransform(559.1,435.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#BABABA").ss(3,0,1).p("ADah2QhdADhDBDQhEBEAABjIjPAA");
	this.shape_23.setTransform(564.3,433.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#BABABA").ss(3,0,1).p("ADfi5QgEAdAAAeQAAAfAFAgQgNgBgGAAQhjAAhFBFQhFBFAABjIjOAA");
	this.shape_24.setTransform(566.4,428.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#BABABA").ss(3,0,1).p("ADljQQgPAyAAA6QAAAfAFAgQgNgBgGAAQhiAAhGBFQhEBFAABjIjPAA");
	this.shape_25.setTransform(566.9,425.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#BABABA").ss(3,0,1).p("AD5j4Qg1BUAABrQAAAfAFAfQgNgBgGAAQhiAAhGBGQhEBFAABjIjPAA");
	this.shape_26.setTransform(568.7,421.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#BABABA").ss(3,0,1).p("AEjkiQgOAMgOAOQhqBqAACWQAAAfAFAgQgNgBgGAAQhiAAhFBFQhFBGAABiIjPAA");
	this.shape_27.setTransform(572.6,416.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#BABABA").ss(3,0,1).p("AFVk/QhEAag4A5QhqBqAACVQAAAgAFAgQgNgBgGAAQhhAAhGBFQhFBGAABiIjPAA");
	this.shape_28.setTransform(577.2,413.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#BABABA").ss(3,0,1).p("AF4lIQhtAThSBSQhqBqAACWQAAAfAFAgQgNgBgGAAQhhAAhGBGQhFBFAABjIjPAA");
	this.shape_29.setTransform(580.4,412.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#BABABA").ss(3,0,1).p("AGflKQgMgBgNAAQiWAAhqBrQhqBqAACVQAAAgAFAgQgNgBgGAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_30.setTransform(585.5,412.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#BABABA").ss(3,0,1).p("AHKk9QgvgOg1AAQiWAAhqBrQhqBqAACVQAAAgAFAgQgMgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_31.setTransform(588.7,412.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#BABABA").ss(3,0,1).p("AIBkEQhehHh5AAQiWAAhqBrQhqBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_32.setTransform(594.7,412.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#BABABA").ss(3,0,1).p("AIli6QgVgdgdgZQhmhbiKAAQiWAAhqBrQhqBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_33.setTransform(598.6,412.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#BABABA").ss(3,0,1).p("AJFgPQgCgQgDgPAJFgPQADAXAAAXAJKgVQgDADgCADAI7g/QgbhnhThKQhmhbiKAAQiWAAhpBrQhqBqAACVQAAAgAFAgQgNgBgGAAQhjAAhFBFQhGBGAABiIjOAA");
	this.shape_34.setTransform(602.4,412.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#BABABA").ss(3,0,1).p("AIYgPQADAXAAAXAJ+hhQgFACgFADQg3AcglAxQgSiGhmhbQhmhbiKAAQiWAAhpBrQhrBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_35.setTransform(606.9,412.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#BABABA").ss(3,0,1).p("AHzgPQADAXAAAXAKnh3QguAGgqAVQg3AcglAxQgRiGhmhbQhnhbiJAAQiWAAhqBrQhqBqAACVQAAAgAFAgQgNgBgGAAQhiAAhGBFQhFBGAABiIjPAA");
	this.shape_36.setTransform(610.6,412.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#BABABA").ss(3,0,1).p("AHPgPQADAXAAAXALLh2QgTgDgVAAQhAAAg4AdQg3AcglAxQgSiGhmhbQhmhbiKAAQiVAAhqBrQhrBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_37.setTransform(614.2,412.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#BABABA").ss(3,0,1).p("AGrgPQADAXAAAXALrhjQgxgWg7AAQhAAAg4AdQg3AcglAxQgSiGhmhbQhmhbiKAAQiVAAhqBrQhrBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_38.setTransform(617.8,412.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#BABABA").ss(3,0,1).p("AGLgPQADAXAAAXAMHg9QhHg8hhAAQhAAAg4AdQg3AcglAxQgSiGhmhbQhmhbiKAAQiVAAhqBrQhrBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_39.setTransform(621,412.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#BABABA").ss(3,0,1).p("AMlAKQgRgcgagaQhNhNhuAAQhAAAg5AdQg3AcglAxQADAXAAAXAFqgPQgRiGhmhbQhnhbiJAAQiWAAhqBrQhqBqAACVQAAAgAFAgQgNgBgGAAQhiAAhGBFQhFBGAABiIjPAA");
	this.shape_40.setTransform(624.3,412.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#BABABA").ss(3,0,1).p("AM1CPQAAhuhNhNQhOhNhuAAQhAAAg4AdQg3AcglAxQADAXAAAXAFYgPQgSiGhmhbQhmhbiJAAQiWAAhqBrQhrBqAACVQAAAgAGAgQgNgBgHAAQhiAAhFBFQhGBGAABiIjOAA");
	this.shape_41.setTransform(626.1,412.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22}]}).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[]},1127).wait(105));

	// Layer 87
	this.instance_2 = new lib.Tween96("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(693.4,642.6);

	this.instance_3 = new lib.Tween97("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(693.4,409.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},45).to({state:[]},1049).wait(157));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true,y:409.6},45,cjs.Ease.elasticInOut).wait(1206));

	// Layer 1
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#BABABA").ss(3,0,1).p("AgeAAIA9AA");
	this.shape_42.setTransform(854.5,442.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_42).to({_off:true},1094).wait(157));

	// Layer 96
	this.instance_4 = new lib.Tween102("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(724,388.9,0.865,0.865);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween103("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(724,388.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},136).to({state:[{t:this.instance_5}]},20).to({state:[]},1080).to({state:[]},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(136).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},20,cjs.Ease.elasticInOut).wait(1095));

	// Layer 97
	this.instance_6 = new lib.Tween104("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(626.7,353.3,0.706,0.706);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween105("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(626.7,353.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},130).to({state:[{t:this.instance_7}]},22).to({state:[]},1085).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(130).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},22,cjs.Ease.elasticInOut).wait(1099));

	// Layer 98
	this.instance_8 = new lib.Tween106("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(749.8,349.8,0.899,0.899);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween107("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(749.8,349.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},124).to({state:[{t:this.instance_9}]},23).to({state:[]},1090).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(124).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},23,cjs.Ease.elasticInOut).wait(1104));

	// Layer 99
	this.instance_10 = new lib.Tween108("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(579.3,337.1,0.69,0.69);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween109("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(579.3,337.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},119).to({state:[{t:this.instance_11}]},24).to({state:[]},1094).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(119).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},24,cjs.Ease.elasticInOut).wait(1108));

	// Layer 100
	this.instance_12 = new lib.Tween110("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(736.4,303.2,0.667,0.667);
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween111("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(736.4,303.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},115).to({state:[{t:this.instance_13}]},21).to({state:[]},1101).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(115).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},21,cjs.Ease.elasticInOut).wait(1115));

	// Layer 101
	this.instance_14 = new lib.Tween112("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(595.5,305,0.743,0.743);
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween113("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(595.5,305);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},110).to({state:[{t:this.instance_15}]},19).to({state:[]},1108).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(110).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},19,cjs.Ease.elasticInOut).wait(1122));

	// Layer 102
	this.instance_16 = new lib.Tween114("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(789.9,341.5,0.6,0.6);
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween115("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(789.9,341.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},105).to({state:[{t:this.instance_17}]},20).wait(1126));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(105).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},20,cjs.Ease.bounceInOut).wait(1126));

	// Layer 103
	this.instance_18 = new lib.Tween116("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(563.1,379.9,0.661,0.661);
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween117("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(563.1,379.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},100).to({state:[{t:this.instance_19}]},20).to({state:[]},1117).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(100).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},20,cjs.Ease.bounceInOut).wait(1131));

	// Layer 104
	this.instance_20 = new lib.Tween118("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(769.3,321.5,0.746,0.746);
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween119("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(769.3,321.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},95).to({state:[{t:this.instance_21}]},22).to({state:[]},1120).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(95).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},22,cjs.Ease.elasticInOut).wait(1134));

	// Layer 105
	this.instance_22 = new lib.Tween100("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(600.2,353.9,0.542,0.542);
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween101("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(600.2,353.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},88).to({state:[{t:this.instance_23}]},19).to({state:[]},1130).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(88).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1},19,cjs.Ease.elasticInOut).wait(1144));

	// Layer 1 copy 2
	this.instance_24 = new lib.cloud3();
	this.instance_24.parent = this;
	this.instance_24.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(472));

	// Layer 1
	this.instance_25 = new lib.cloud3();
	this.instance_25.parent = this;
	this.instance_25.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(472));

	// Layer 1 copy
	this.instance_26 = new lib.cloud1("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).to({_off:true},91).wait(157));

	// Layer 1 copy 3
	this.instance_27 = new lib.cloud1("synched",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(457));

	// Layer 1
	this.instance_28 = new lib.cloud1("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(457));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,603.2);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 36,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;