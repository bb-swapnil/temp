(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.JUN2017 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAYAAASARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAIAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgIQgIgHgLAAQgKAAgHAHg");
	this.shape.setTransform(662.7,409.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAIAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgIQgHgHgLAAQgKAAgIAHg");
	this.shape_1.setTransform(619.6,359.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAASARQARASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAHAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgHQgHgIgLAAQgKAAgIAIg");
	this.shape_2.setTransform(641.9,429.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQARASABAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAIAAALQAAALAIAHQAHAIAKAAQALAAAIgIQAHgIAAgKQAAgLgHgIQgIgHgLAAQgKAAgHAHg");
	this.shape_3.setTransform(584.9,303.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARASQASARAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAIAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAJgIgBgLQAAgLgIgIQgHgHgLAAQgKAAgIAHg");
	this.shape_4.setTransform(744.7,300.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZARgSQATgRAXAAQAZAAASARQARASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgyQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgHAIg");
	this.shape_5.setTransform(798.4,266.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZARgSQASgRAYAAQAZAAASARQARASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgHAIg");
	this.shape_6.setTransform(643.5,388.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgVQAAgYARgSQATgRAXAAQAYAAASARQASASAAAYQAAAVgeA9QgPAggPAbQgOgbgPgggAgSgzQgHAHAAALQAAAMAHAHQAIAHAKABQALgBAHgHQAIgHAAgMQAAgLgIgHQgHgHgLgBQgKABgIAHg");
	this.shape_7.setTransform(709.4,271.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgSAYAAQAZABARARQASASAAAZQAAAUgeA9QgPAfgPAcQgOgcgPgfgAgSgyQgHAHAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgHQgHgIgLAAQgKAAgIAIg");
	this.shape_8.setTransform(670,290.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQARASABAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAIAAALQAAALAIAHQAHAIAKAAQALAAAIgIQAHgHAAgLQAAgLgHgIQgIgHgLAAQgKAAgHAHg");
	this.shape_9.setTransform(637.6,294.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAHAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgHQgHgIgLAAQgKAAgIAIg");
	this.shape_10.setTransform(626,170.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAIAAALQAAALAHAHQAIAIAKAAQALAAAHgIQAIgHAAgLQAAgLgIgIQgHgIgLAAQgKAAgIAIg");
	this.shape_11.setTransform(684,335.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D71D49").s().p("AgcAqQgfg9AAgUQAAgaASgSQARgRAZAAQAYAAASARQARASAAAaQAAAUgeA9QgPAggOAbQgOgbgPgggAgRgzQgIAIAAALQAAALAIAIQAHAHALAAQALAAAHgIQAIgIAAgKQAAgLgIgIQgHgIgLABQgLgBgHAIg");
	this.shape_12.setTransform(606.2,259.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgHAIg");
	this.shape_13.setTransform(643.3,212);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BABABA").s().p("AAAAqQgdgBgWgMQgVgNAAgQQAAgSAWgLQAVgMAdAAQAeAAAWANQAVAMgBARQABASgWAMQgVALgcAAIgCAAg");
	this.shape_14.setTransform(641.9,439.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BABABA").s().p("AAAAqQgeAAgUgNQgWgMAAgRQABgSAVgMQAWgMAcABQAfAAAVANQAVANgBAQQAAARgVAMQgUAMgdAAIgCAAg");
	this.shape_15.setTransform(662.5,420);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BABABA").s().p("AAAAqQgdAAgWgNQgVgMABgRQgBgSAWgLQAVgMAeAAQAdAAAWANQAVAMAAARQAAARgWAMQgVAMgcAAIgCAAg");
	this.shape_16.setTransform(643.5,398.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BABABA").s().p("AAAAqQgdAAgWgNQgVgMAAgRQABgSAVgLQAWgMAcAAQAfAAAVANQAVANgBAQQAAARgVAMQgVAMgcAAIgCAAg");
	this.shape_17.setTransform(619.6,369.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BABABA").s().p("AAAAqQgegBgVgMQgVgNAAgQQAAgSAWgMQAVgMAeABQAeAAAVAMQAVAOAAAQQgBARgVANQgVALgcAAIgCAAg");
	this.shape_18.setTransform(584.9,313.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BABABA").s().p("AAAAqQgdAAgWgNQgVgMAAgRQAAgRAWgMQAVgNAdABQAeAAAWANQAVANgBAQQAAASgVAMQgVALgcAAIgCAAg");
	this.shape_19.setTransform(606,269);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BABABA").s().p("AAAAqQgdAAgWgNQgVgMAAgRQAAgRAWgNQAVgMAdABQAeAAAWANQAVANgBAQQABARgWAMQgUAMgdAAIgCAAg");
	this.shape_20.setTransform(626.2,180.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BABABA").s().p("AAAAqQgeAAgVgNQgVgNAAgQQABgRAVgMQAVgNAeABQAeAAAVANQAVAMAAARQAAASgWAMQgVALgcAAIgCAAg");
	this.shape_21.setTransform(643.4,221.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BABABA").s().p("AAAAqQgeAAgVgNQgVgNAAgQQAAgRAWgMQAVgNAeABQAeAAAVANQAVANAAAQQgBASgVAMQgVALgcAAIgCAAg");
	this.shape_22.setTransform(798.6,276.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BABABA").s().p("AAAAqQgeAAgUgNQgWgNAAgQQAAgRAWgNQAWgMAcABQAfAAAVANQAVANgBAQQAAARgVANQgVALgcAAIgCAAg");
	this.shape_23.setTransform(744.7,310.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BABABA").s().p("AAAAqQgeAAgVgNQgVgMAAgRQAAgRAWgNQAWgMAcABQAfAAAVANQAVAMgBARQAAARgVAMQgVAMgdAAIgBAAg");
	this.shape_24.setTransform(683.9,344.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BABABA").s().p("AAAAqQgegBgVgMQgVgMAAgRQAAgRAWgNQAWgLAdAAQAeABAVAMQAVANAAAQQgBASgVALQgVAMgcAAIgCAAg");
	this.shape_25.setTransform(637.7,303.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BABABA").s().p("AAAAqQgdAAgWgNQgVgNAAgQQABgRAVgNQAWgMAcABQAfAAAVAMQAVANgBARQAAASgVAMQgVALgcAAIgCAAg");
	this.shape_26.setTransform(670,300.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BABABA").s().p("AAAAqQgegBgVgMQgVgMAAgRQABgRAVgNQAWgMAdABQAeABAVAMQAVANAAAQQAAASgWALQgVAMgcAAIgCAAg");
	this.shape_27.setTransform(709.4,280.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#D71D49").p("ABilDQgRAKgYAXQgwAugiA/QhvDLA9Ey");
	this.shape_28.setTransform(627.8,335.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#D71D49").p("AiXiuIArAPQA0AXAtAhQCNBqASCx");
	this.shape_29.setTransform(622.8,285.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#D71D49").p("AigAoIAbgTQAjgWAmgPQB3guBnAz");
	this.shape_30.setTransform(653.8,299.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D71D49").p("AhfjLIAkAVQArAdAgAoQBpB/gkDB");
	this.shape_31.setTransform(635.6,201.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D71D49").p("AsHkBIAmgIQAwgJA5gGQC1gRC7AZQJWBRG3Hh");
	this.shape_32.setTransform(721.1,247.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D71D49").p("ABzFlQhIhPg+iBQh+kBArj7");
	this.shape_33.setTransform(630.4,403.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#D71D49").p("An+gFIBZgrQBxgtB4gPQGAgxE6ET");
	this.shape_34.setTransform(658.4,269.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D71D49").p("AnwiMIBvgTQCJgRCCAMQGgAjDEEt");
	this.shape_35.setTransform(634.6,327.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#D71D49").p("AiOmFIA6A9QBEBOAyBYQChEZhPER");
	this.shape_36.setTransform(657.8,260.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#D71D49").p("Al7gDIBEgeQBXgfBagLQEhghDfC+");
	this.shape_37.setTransform(707.3,300);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#D71D49").p("AkGCvQAIgbASgoQAkhQA0g7QCjjCD8BF");
	this.shape_38.setTransform(771.7,291.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#D71D49").p("Am8BhIBAg4QBTg+BhgjQE2hwFPDU");
	this.shape_39.setTransform(753.9,271.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#D71D49").p("AlMkhIBPALQBgAWBZAvQEeCWBvFg");
	this.shape_40.setTransform(676.6,251);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#D71D49").p("AiwDtQgEhxArhzQBVjmDrgL");
	this.shape_41.setTransform(625,245.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#D71D49").p("Ak+iLIBKgQQBagNBUANQEOAoBzEZ");
	this.shape_42.setTransform(637.9,283);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#D71D49").p("AhkDiQgNhZAThlQAojJCkg4");
	this.shape_43.setTransform(595,291.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#D71D49").p("Ai1iHIAygDQA9ABA1ASQCoA6AaDM");
	this.shape_44.setTransform(727.6,295);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#D71D49").p("AkwC9QAbh0BahmQC0jOE8BD");
	this.shape_45.setTransform(714.5,326.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#D71D49").p("AjJBqIAWgpQAfgwApgjQCBh1C3At");
	this.shape_46.setTransform(688.9,290.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#D71D49").p("AhIjbIAbAeQAgAmAXAvQBPCWgWCw");
	this.shape_47.setTransform(677.3,322.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#D71D49").p("Aj6FXQAmh9BSiUQCjkmDchz");
	this.shape_48.setTransform(644.7,334.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#D71D49").p("AiwkSIA8AUQBIAdA4AyQC4CdgaEp");
	this.shape_49.setTransform(602.6,341.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#D71D49").p("AhoF4QgLh+AWicQArk3Cgib");
	this.shape_50.setTransform(673,382.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#D71D49").p("Ak/CJQA6heBuhMQDaibEABV");
	this.shape_51.setTransform(651.6,355.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#D71D49").p("AjHEOQgEiLAwiHQBgkREIAO");
	this.shape_52.setTransform(663.5,371.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#D71D49").p("Ah5iPIAhAGQAnAMAjAYQBuBMAVCt");
	this.shape_53.setTransform(631.8,383.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#D71D49").p("AAbjMIgQAZQgQAigJArQgfCHA4Ct");
	this.shape_54.setTransform(640.8,419);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#D71D49").p("ABdBuQAFg8gVg3QgrhxiDAQ");
	this.shape_55.setTransform(653.3,408.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#D71D49").p("AhlBmQAIg2AegzQA7hoBuAM");
	this.shape_56.setTransform(652.1,429.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#D6D4D5").s().p("AgaACQgBgJAJgJQAJgJAJgBQAKAAAJAIQAIAIAAAKQAAALgHAIQgIAIgMAAQgXAAgDgZg");
	this.shape_57.setTransform(651.9,447.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#D6D4D5").s().p("AgaACQgBgJAJgJQAJgJAJgBQALAAAIAIQAIAIAAAKQAAALgHAIQgIAIgMAAQgWAAgEgZg");
	this.shape_58.setTransform(643.3,447.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#D6D4D5").s().p("AAAAaQgKAAgJgKQgIgKABgKQACgVAXAAQAMAAAIAHQAIAHAAALQAAAKgIAIQgJAIgKAAIAAAAg");
	this.shape_59.setTransform(730.8,297.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#D6D4D5").s().p("AAAAbQgJAAgJgKQgJgKACgIQAEgXAVgCQAaABABAZQAAAKgJAIQgIAJgJAAIgBAAg");
	this.shape_60.setTransform(718,303.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgJQgIgJAAgMQADgVAYgBQAKAAAIAJQAIAIAAAJQgBALgIAIQgIAIgIAAIgCAAg");
	this.shape_61.setTransform(722.1,296.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#D6D4D5").s().p("AgSATQgIgIABgLQAAgXAXgDQAMAAAJAIQAIAIgBALQgBAagYAAIgBAAQgKAAgIgIg");
	this.shape_62.setTransform(722,321.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#D6D4D5").s().p("AgaAAQAAgYAZgBQALgBAIAIQAJAIgBAKQgCAYgYADQgagEAAgXg");
	this.shape_63.setTransform(744.1,303.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#D6D4D5").s().p("AgSASQgJgKABgJQACgLAGgHQAGgHAJAAQAOAAAJAIQAIAHgBALQgCAZgZABIAAABQgKAAgIgJg");
	this.shape_64.setTransform(726.7,303.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAHgIQAHgHALgBQALAAAIAHQAJAIgBALQAAAXgZADIgCABQgJAAgHgIg");
	this.shape_65.setTransform(795.9,303.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgIQAIgJAKAAQALABAIAIQAJAIgBAKQgCAXgZADQgYgDgCgXg");
	this.shape_66.setTransform(700.2,328.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQABgLAJgIQAIgHAKAAQAYACABAZQgDAZgXABIgBAAQgKAAgIgIg");
	this.shape_67.setTransform(709.3,340.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQgBgLAIgIQAIgIALAAQAJAAAJAIQAKAJgBAJQgCAYgYADIgBAAQgKAAgHgHg");
	this.shape_68.setTransform(730.7,322);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQACgYAYgBQALgBAIAIQAIAIgBALQgCAXgWADQgMAAgIgIg");
	this.shape_69.setTransform(735.3,315.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#D6D4D5").s().p("AgZgCQACgZAZACQAMABAHAIQAHAJgCALQgDAWgZAAQgagFADgXg");
	this.shape_70.setTransform(709.3,315.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#D6D4D5").s().p("AgTASQgIgJABgNQACgWAYAAQALAAAIAJQAJAJgBAKQgCAWgZADIgCAAQgJAAgIgJg");
	this.shape_71.setTransform(739.5,309.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgLAKgHQAJgHANAAQAUAEAAAWQAAAKgIAJQgIAIgLAAQgKAAgIgJg");
	this.shape_72.setTransform(704.7,309.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#D6D4D5").s().p("AgTASQgIgIABgLQACgZAYAAQALAAAIAIQAJAJgBAKQgBALgIAHQgIAIgKAAQgLgBgIgIg");
	this.shape_73.setTransform(752.8,303.2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#D6D4D5").s().p("AgBAbQgZgEAAgXQAAgKAIgJQAIgIAKABQALAAAIAJQAIAIAAAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_74.setTransform(704.7,347.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgYAZgCQAKAAAJAIQAJAIgBAKQgDAZgYACIgBAAQgKAAgHgIg");
	this.shape_75.setTransform(700.1,353.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQAAgLAIgIQAJgIAKAAQALAAAIAJQAIAJgBAKQgCAYgZACIgBABQgJAAgIgJg");
	this.shape_76.setTransform(718,340.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgZAYgBQALgBAJAJQAJAIgBALQAAAKgIAIQgJAIgKAAQgKAAgIgIg");
	this.shape_77.setTransform(782.6,297);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#D6D4D5").s().p("AAAAbQgXgCgDgVQgBgLAIgJQAIgJALAAQALgBAIAHQAIAIAAAKQAAALgIAJQgHAIgLAAIgBAAg");
	this.shape_78.setTransform(791.2,296.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQADgYAXgCQALgBAIAJQAIAIAAAMQAAAWgaADIgBAAQgKAAgIgIg");
	this.shape_79.setTransform(752.5,315.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgLQADgXAWgCQAMAAAIAIQAIAIAAANQgBAXgYABIgCAAQgKAAgIgIg");
	this.shape_80.setTransform(704.8,296.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgYAYgCQAKgBAJAIQAJAHAAAMQAAALgHAIQgIAIgLAAIgBAAQgKAAgIgIg");
	this.shape_81.setTransform(799.8,296.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#D6D4D5").s().p("AgRAUQgJgIgBgLQAAgJAJgJQAIgJAKAAQAMgBAHAIQAJAIgBALQgBAZgYACIgCAAQgIAAgJgHg");
	this.shape_82.setTransform(709.4,328.2);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQADgYAXgCQAMAAAHAIQAIAJAAAMQgBAWgZACIgBAAQgKAAgIgIg");
	this.shape_83.setTransform(718,328.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#D6D4D5").s().p("AgBAbQgYgCgBgZQgBgKAJgIQAIgIAKAAQAMAAAHAIQAJAJgBAKQgBAMgIAIQgHAGgJAAIgDAAg");
	this.shape_84.setTransform(726.6,315.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgJQgJgKABgJQAEgYAYAAQAZACAAAYQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_85.setTransform(756.6,309.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgKQgBgLAIgIQAIgJALABQAYABADAXQAAALgHAJQgIAIgLABIgBAAQgJAAgIgHg");
	this.shape_86.setTransform(739.4,297);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgXAWgDQAOAAAJAIQAIAHAAALQgBAXgaAEIgBAAQgJAAgIgIg");
	this.shape_87.setTransform(791.3,309.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#D6D4D5").s().p("AAAAbQgKAAgIgJQgIgIAAgKQABgKAJgJQAJgIAJABQAZADAAAVQAAANgIAJQgHAHgLAAIgBAAg");
	this.shape_88.setTransform(739.2,322);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#D6D4D5").s().p("AAAAbQgagEAAgXQAAgLAJgHQAJgIANAAQAWACAAAYQAAALgJAJQgHAHgJAAIgCAAg");
	this.shape_89.setTransform(730.8,309.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#D6D4D5").s().p("AgRAVQgIgHgBgMQgBgKAIgJQAIgIALgBQALAAAIAIQAJAIgBAKQAAAMgIAIQgHAGgLABIgBAAQgLAAgGgGg");
	this.shape_90.setTransform(722.1,309.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#D6D4D5").s().p("AABAbQgYgBgDgYQgBgKAIgJQAIgJALAAQALgBAIAIQAIAIAAALQABAMgIAIQgHAHgLAAIgBAAg");
	this.shape_91.setTransform(743.9,315.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQAAgMAIgHQAIgIALABQAYACACAYQABALgJAIQgIAJgLAAQgLgBgIgIg");
	this.shape_92.setTransform(700.1,315.9);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#D6D4D5").s().p("AAAAbQgMgBgHgGQgHgHAAgMQAAgYAZgCQAKgBAJAIQAIAIABAKQAAALgIAIQgIAIgKAAIgBAAg");
	this.shape_93.setTransform(726.8,328.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#D6D4D5").s().p("AgBAbQgLAAgIgJQgHgJAAgKQABgLAJgIQAIgHALABQAKABAIAJQAIAJgBAJQgBALgJAIQgHAGgKAAIgBAAg");
	this.shape_94.setTransform(700.1,341);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#D6D4D5").s().p("AgSASQgJgIABgKQADgZAXgBQALAAAIAHQAIAIAAALQAAALgHAIQgIAIgMAAQgKAAgIgJg");
	this.shape_95.setTransform(748,296.9);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAHAIQAIAJAAAKQAAALgJAIQgHAHgJAAIgCAAg");
	this.shape_96.setTransform(713.5,297);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgLAIgHQAIgIALAAQAXABADAWQAAANgJAJQgHAIgKAAIgBAAg");
	this.shape_97.setTransform(713.5,309.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#D6D4D5").s().p("AAAAbQgKAAgJgJQgIgJABgKQACgYAYgBQALgBAJAIQAIAIgBALQAAALgIAIQgIAIgLAAIAAAAg");
	this.shape_98.setTransform(735.4,303.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgYQAAgLAIgIQAJgIAMAAQAWAEACAWQABALgJAIQgHAIgKAAIgCAAg");
	this.shape_99.setTransform(700.2,303.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgJgJQgIgJABgJQADgZAXAAQAMAAAIAHQAHAIAAALQAAALgJAIQgHAIgJAAIgCAAg");
	this.shape_100.setTransform(748,309.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#D6D4D5").s().p("AAAAcQgLgBgIgJQgHgJAAgKQABgMAIgHQAIgHALABQAWACADAXQAAAMgIAJQgJAIgKAAIAAAAg");
	this.shape_101.setTransform(787.2,303.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#D6D4D5").s().p("AgEAbQgUgDgCgYQgBgKAJgIQAIgIAKAAQAMAAAHAIQAJAJgBAKQAAALgJAHQgJAIgLAAIgCAAg");
	this.shape_102.setTransform(730.8,334.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgZQAAgKAJgJQAJgIAKABQALAAAHAIQAHAIAAAKQAAAMgJAIQgHAHgKAAIgBAAg");
	this.shape_103.setTransform(704.8,334.5);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgJABgKQAAgMAJgHQAJgIAKABQAYADABAXQABALgJAJQgIAHgKAAIgBAAg");
	this.shape_104.setTransform(735.4,328.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgKAIgJQAIgIAKAAQALAAAIAJQAIAJAAAJQAAAMgIAHQgIAHgKAAIgBAAg");
	this.shape_105.setTransform(704.7,321.9);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgYQgBgKAIgJQAJgJAKAAQALgBAIAIQAIAIAAALQABALgIAJQgIAHgLAAIgBAAg");
	this.shape_106.setTransform(718,315.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgMQgBgLAHgHQAIgIAMAAQAMAAAIAIQAIAHgBALQgCAYgYADIgCAAQgJAAgHgHg");
	this.shape_107.setTransform(713.4,347.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgIgIQgIgIABgLQACgYAYgBQALgBAJAJQAIAIgBAKQAAAMgIAIQgIAHgLAAIAAAAg");
	this.shape_108.setTransform(722.1,334.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgKAIgIQAIgJAKABQAXACAEAWQAAAMgIAIQgIAJgLAAQgLAAgHgHg");
	this.shape_109.setTransform(713.4,322);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgHgJQgJgIABgKQABgLAJgIQAJgJAJACQAZADAAAXQAAAMgIAIQgHAHgLAAIgBAAg");
	this.shape_110.setTransform(795.7,315.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgIQAIgJAKAAQALAAAIAJQAIAIAAAKQAAALgIAHQgJAIgMAAQgWgCgCgYg");
	this.shape_111.setTransform(713.4,334.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#D6D4D5").s().p("AAAAbQgKAAgIgJQgJgJABgJQAAgLAIgIQAJgIAKAAQAMABAHAHQAIAIgBALQAAALgIAIQgIAJgKAAIgBgBg");
	this.shape_112.setTransform(709.4,303.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#D6D4D5").s().p("AgSATQgIgJABgKQACgXAYgCQAaADAAAWQAAAagZABQgLgBgJgHg");
	this.shape_113.setTransform(752.5,277.8);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQABgWAZgFQAKgBAIAJQAIAIABALQgCAYgXACIgCAAQgKAAgHgHg");
	this.shape_114.setTransform(795.7,277.7);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQADgZAXgBQALAAAIAJQAJAJgBAKQgDAYgWABQgMAAgJgIg");
	this.shape_115.setTransform(834.4,258.9);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAIgHALAAQAKAAAIAHQAIAJgBAKQgBAZgZAAQgXAAgDgZg");
	this.shape_116.setTransform(735.3,265.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#D6D4D5").s().p("AAAAaQgZgCgBgZQAEgYAWgBQALAAAIAIQAIAHAAALQAAALgJAIQgHAIgJAAIgCgBg");
	this.shape_117.setTransform(709.2,290.4);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#D6D4D5").s().p("AgQAUQgJgIgBgLQAAgIAIgJQAJgJAKgBQAKAAAIAHQAIAIAAALQgBAZgXABIgDABQgJAAgHgHg");
	this.shape_118.setTransform(743.8,277.7);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#D6D4D5").s().p("AgRAUQgIgHgBgMQAAgJAJgKQAIgJAKABQAYADACAYQgCAZgXAAIgCABQgKAAgHgHg");
	this.shape_119.setTransform(769.8,277.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#D6D4D5").s().p("AgGAaQgJAAgFgHQgFgHgBgMQgBgKAJgIQAIgIAKAAQALABAJAJQAIAIgBAKQgBAMgJAGQgIAHgNAAIgCgBg");
	this.shape_120.setTransform(718,277.8);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgZQAAgKAJgJQAJgJAJACQAYADACAWQAAALgIAIQgHAIgLAAIgBAAg");
	this.shape_121.setTransform(726.6,277.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#D6D4D5").s().p("AgRAUQgIgHAAgMQgBgXAagDQAIgCAKAJQAJAJAAALQgDAXgXACIgCAAQgJAAgHgHg");
	this.shape_122.setTransform(713.3,284);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgIAJAAQAZADABAXQABALgJAIQgIAIgMAAQgXgDgBgXg");
	this.shape_123.setTransform(808.3,284);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgZQAAgKAJgIQAJgJAJAAQAKAAAIAJQAIAIAAAJQAAAMgHAHQgIAIgLAAIgBAAg");
	this.shape_124.setTransform(739.2,284);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#D6D4D5").s().p("AgaACQAAgLAHgIQAIgIALgBQAKAAAJAIQAIAIAAAKQAAALgIAIQgJAIgKAAQgYgDgCgWg");
	this.shape_125.setTransform(773.8,271.5);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#D6D4D5").s().p("AgBAaQgZgCAAgYQAAgLAJgIQAJgIAKACQAXACACAYQgBALgIAIQgIAHgKAAIgBgBg");
	this.shape_126.setTransform(787.1,265.3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#D6D4D5").s().p("AgDAbQgXgEAAgXQAAgLAIgIQAJgHAKAAQAXACACAZQABAKgJAIQgJAIgLAAIgBAAg");
	this.shape_127.setTransform(795.9,252.7);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIAKAAQAXACADAYQgDAZgXABIgBABQgKAAgHgIg");
	this.shape_128.setTransform(761.2,265.3);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgIABgLQABgLAIgIQAIgIALABQAYABABAZQABALgJAJQgHAHgLAAIgBAAg");
	this.shape_129.setTransform(726.6,265.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQABgLAJgIQAIgHAKAAQAYACABAZQgDAZgXABIgBAAQgKAAgIgIg");
	this.shape_130.setTransform(709.3,265.3);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#D6D4D5").s().p("AgRATQgIgHAAgLQgBgLAIgIQAIgIALAAQAXACADAYQgDAZgYACIAAAAQgKAAgHgIg");
	this.shape_131.setTransform(821.7,252.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgMAIgHQAIgIAOAAQAJABAHAHQAGAHABALQABAKgJAJQgIAIgKAAIgBAAg");
	this.shape_132.setTransform(752.8,252.7);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#D6D4D5").s().p("AgRAUQgHgHgBgMQgBgKAIgIQAJgJAKAAQALAAAIAIQAHAIAAALQgCAZgZABQgKAAgHgHg");
	this.shape_133.setTransform(735.1,290.4);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQgBgKAIgIQAIgIALAAQAYABADAZQgBAXgYAEIgCAAQgJAAgIgHg");
	this.shape_134.setTransform(739.2,271.6);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgXAZgDQALgBAIAIQAIAIAAALQAAALgIAIQgHAHgLABQgLAAgIgIg");
	this.shape_135.setTransform(791,271.5);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#D6D4D5").s().p("AgaAAQACgaAYAAQALAAAIAIQAIAIgBALQgBAWgZAEQgagEAAgXg");
	this.shape_136.setTransform(722,271.6);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#D6D4D5").s().p("AgBAbQgZgEAAgXQAAgKAIgJQAIgIAKABQALAAAIAJQAIAIAAAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_137.setTransform(704.7,271.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgLAIgIQAJgIAKABQAXABADAYQAAAMgIAHQgHAIgLAAIgBAAg");
	this.shape_138.setTransform(778.4,265.2);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#D6D4D5").s().p("AAAAbQgZgBgBgaQAAgKAHgIQAJgIALAAQAXABADAZQABAKgJAJQgIAIgLAAIAAAAg");
	this.shape_139.setTransform(765.1,271.6);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAIAIQAIAIAAAKQgBAMgIAIQgIAHgKAAIgBAAg");
	this.shape_140.setTransform(808.3,271.6);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQACgaAYAAQALAAAIAIQAIAIAAAKQgCAagYABIgBAAQgKAAgHgIg");
	this.shape_141.setTransform(825.6,246.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgYAZgCQAKAAAJAIQAJAIgBAKQgDAZgYACIgBAAQgKAAgHgIg");
	this.shape_142.setTransform(700.1,278);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#D6D4D5").s().p("AgaABQgBgJAJgJQAJgJAJAAQALgBAIAIQAIAIAAALQAAALgHAIQgIAIgMAAQgWAAgEgag");
	this.shape_143.setTransform(791.1,284);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#D6D4D5").s().p("AgaACQgBgJAIgKQAJgJAKAAQAJgBAJAJQAJAJAAAJQAAAMgHAIQgIAHgMAAQgXAAgDgZg");
	this.shape_144.setTransform(778.5,277.7);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQAAgLAIgIQAJgIAKABQALgBAIAKQAIAIgBAKQgCAYgZADIAAAAQgKAAgIgJg");
	this.shape_145.setTransform(718,265.3);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#D6D4D5").s().p("AgBAbQgLgBgIgJQgHgJABgKQAEgYAXAAQALAAAIAJQAIAIgBAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_146.setTransform(791.2,259);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgKAJgIQAIgJAKAAQAaACAAAaQgBAXgXABIgDABQgJAAgIgHg");
	this.shape_147.setTransform(804.2,265.3);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgKQACgYAYgCQAKgBAJAJQAIAIAAAKQAAAMgHAIQgIAHgMAAQgLAAgIgIg");
	this.shape_148.setTransform(804.3,277.7);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQACgXAYgDQALAAAIAIQAJAJgBAKQgCAYgZACQgKAAgIgIg");
	this.shape_149.setTransform(730.6,284);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#D6D4D5").s().p("AgBAbQgMAAgHgJQgHgKACgOQADgVAYABQALABAIAJQAHAJgCAKQgEAYgWAAIgBAAg");
	this.shape_150.setTransform(817,246.4);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQADgXAVgDQANAAAIAIQAIAHAAALQgBAYgZADIgBAAQgKAAgIgIg");
	this.shape_151.setTransform(747.9,271.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAMQgBAWgZACIgBAAQgKAAgHgHg");
	this.shape_152.setTransform(799.7,271.5);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgJQAJgJAKABQALABAHAIQAHAIAAAKQAAAMgIAHQgHAHgKAAIgCAAg");
	this.shape_153.setTransform(787,277.7);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQACgYAYgCQAKAAAIAHQAJAJAAAKQABAKgJAJQgIAIgLAAIAAAAQgLAAgHgIg");
	this.shape_154.setTransform(813,252.7);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#D6D4D5").s().p("AgSASQgJgIAAgKQABgLAJgIQAJgIAKABQALAAAIAIQAHAJgBALQgCAYgXABQgLAAgJgJg");
	this.shape_155.setTransform(795.7,265.3);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#D6D4D5").s().p("AgaADQgCgJAKgKQAJgKAKAAQAYADACAXQABALgIAIQgIAIgLAAQgYAAgDgYg");
	this.shape_156.setTransform(735.3,277.7);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAYAAADAaQABAKgIAJQgIAIgMAAQgLAAgHgHg");
	this.shape_157.setTransform(804.5,252.7);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#D6D4D5").s().p("AAAAaQgZgCgBgYQAAgLAJgHQAIgIAPAAQAJABAFAHQAGAHAAALQABALgIAIQgHAIgKAAIgCgBg");
	this.shape_158.setTransform(804.2,290.4);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgKAJgIQAJgJAMAAQAXAEABAVQAAALgHAJQgIAIgKAAIgCAAg");
	this.shape_159.setTransform(786.9,290.4);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgKAIgIQAJgJAMAAQAWABACAYQABAMgIAIQgHAIgLAAIgCAAQgJAAgIgHg");
	this.shape_160.setTransform(726.4,290.3);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQACgZAYgBQALgBAIAJQAIAIAAALQAAAKgIAIQgIAIgLAAQgKAAgIgIg");
	this.shape_161.setTransform(717.9,290.4);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgLAIgIQAIgHAKAAQALABAIAJQAIAJgBAJQgCAYgYABQgLAAgIgIg");
	this.shape_162.setTransform(799.7,246.4);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAJgIAKAAQAZACAAAYQAAAXgYAEQgLAAgJgIg");
	this.shape_163.setTransform(813,240.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#D6D4D5").s().p("AgBAbQgLAAgIgJQgHgJAAgKQABgLAJgIQAIgHALABQAKABAIAJQAIAJgBAJQgBALgJAIQgHAGgKAAIgBAAg");
	this.shape_164.setTransform(700.1,265.5);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQACgXAYgDQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgKAAQgLAAgIgIg");
	this.shape_165.setTransform(812.9,265.2);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQAAgKAJgIQAJgJAJABQAMAAAHAIQAHAJAAANQgCAVgYACIgBAAQgJAAgIgIg");
	this.shape_166.setTransform(752.5,265.3);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgJQgHgJAAgKQABgLAIgIQAJgIAKACQAYADABAYQABALgJAIQgIAHgLAAIAAAAg");
	this.shape_167.setTransform(743.9,265.3);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgIQAIgJAKAAQALAAAIAIQAIAIAAAKQAAAMgJAHQgJAIgNAAQgUgCgCgYg");
	this.shape_168.setTransform(825.7,258.9);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#D6D4D5").s().p("AgSASQgJgIACgKQADgaAXAAQAMAAAHAIQAHAJAAANQgEAXgXAAQgKAAgIgJg");
	this.shape_169.setTransform(808.4,258.9);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgIAKAAQAZACABAYQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_170.setTransform(799.7,259);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#D6D4D5").s().p("AgRATQgJgIABgLQABgZAYgBQAKgBAIAIQAIAIABANQgCAXgXACIgCAAQgJAAgIgIg");
	this.shape_171.setTransform(756.6,259);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgYAZgCQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgMAAQgKAAgIgIg");
	this.shape_172.setTransform(747.9,284.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgZQgBgKAJgIQAIgIAKAAQAMAAAHAIQAIAIAAAKQAAAMgIAIQgIAHgJAAIgCAAg");
	this.shape_173.setTransform(752.4,290.4);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#D6D4D5").s().p("AgBAbQgMgBgHgIQgHgIABgLQADgYAYgBQAKgBAJAKQAIAJgBAJQAAAMgIAHQgHAHgLAAIgCAAg");
	this.shape_174.setTransform(699.9,290.5);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgZQAAgKAJgJQAJgIAKABQALAAAHAIQAHAIAAAKQAAAMgJAIQgHAHgKAAIgBAAg");
	this.shape_175.setTransform(704.8,259);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#D6D4D5").s().p("AgTATQgHgHAAgMQABgXAZgDQAKgBAJAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIg");
	this.shape_176.setTransform(799.6,284);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#D6D4D5").s().p("AgBAbQgYgDgBgYQAAgKAIgIQAIgIAKAAQALAAAIAJQAIAIAAAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_177.setTransform(704.7,284);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgMQgBgLAHgHQAIgIAMAAQAMAAAIAIQAIAHgBALQgCAYgYADIgCAAQgJAAgHgHg");
	this.shape_178.setTransform(713.4,271.7);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#D6D4D5").s().p("AgSATQgJgJAAgKQABgLAIgIQAIgIAKABQAMAAAIAIQAIAIgBAKQAAAMgIAIQgIAHgLAAQgKAAgIgIg");
	this.shape_179.setTransform(795.6,290.3);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQABgXAZgDQAKgBAJAJQAIAIABALQAAAMgIAHQgIAHgMAAQgLAAgIgIg");
	this.shape_180.setTransform(709.3,277.7);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgKAIgJQAIgIAKAAQAMAAAIAIQAIAIgBALQgBAZgZABIgBAAQgKAAgHgHg");
	this.shape_181.setTransform(769.8,265.3);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgMAJgHQAIgHALABQAaADgCAZQgCAZgZAAQgKAAgIgJg");
	this.shape_182.setTransform(730.6,271.6);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgIABgLQAAgLAIgIQAJgIAKABQAZACABAYQABALgJAIQgIAIgLAAIAAAAg");
	this.shape_183.setTransform(830.4,252.7);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgJAIQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_184.setTransform(808.3,246.5);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#D6D4D5").s().p("AABAbQgZgBgCgYQgBgKAIgJQAHgIAMgBQAKgBAIAIQAJAHAAAMQABAKgIAJQgIAIgKAAIgBAAg");
	this.shape_185.setTransform(821.6,240.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#D6D4D5").s().p("AgSAUQgHgHgBgMQAAgJAIgJQAIgJAKAAQALAAAIAJQAIAIAAAKQAAAMgIAGQgJAIgMAAQgKgBgGgGg");
	this.shape_186.setTransform(713.4,259);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgKAIgIQAIgJAKAAQALAAAJAJQAIAJgBAKQgDAagXAAIgBABQgLAAgHgIg");
	this.shape_187.setTransform(787.2,252.7);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#D6D4D5").s().p("AgBAbQgYgDgBgYQAAgKAIgJQAJgIAKABQALAAAIAJQAIAIgBAKQAAAMgJAHQgHAHgKAAIgCAAg");
	this.shape_188.setTransform(817.1,259);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#D6D4D5").s().p("AAAAbQgYAAgCgaQgBgLAJgIQAHgIALAAQALAAAJAIQAHAHAAALQAAAMgHAIQgIAHgKAAIgCAAg");
	this.shape_189.setTransform(743.8,290.3);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQABgXAYgDQAMAAAIAGQAIAHAAAMQABALgIAIQgIAJgLAAIgBAAQgJAAgIgIg");
	this.shape_190.setTransform(782.4,271.6);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#D6D4D5").s().p("AgTATQgHgIgBgLQABgLAIgIQAJgIAKABQAYADADAVQAAALgJAJQgJAJgKAAQgKAAgJgIg");
	this.shape_191.setTransform(722,284);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQABgWAZgFQAKgBAIAJQAIAIABALQgCAZgXABIgCAAQgKAAgHgHg");
	this.shape_192.setTransform(647.9,428.7);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgHgIQgIgJAAgKQADgZAXAAQAZAAABAaQABAKgJAJQgIAIgKAAIAAAAg");
	this.shape_193.setTransform(622.2,378.7);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#D6D4D5").s().p("AgTASQgIgJACgKQACgXAXgCQAMABAIAIQAIAIgBALQgCAXgZACIgBAAQgKAAgIgJg");
	this.shape_194.setTransform(639.3,391.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgIAJAAQAZADABAXQABALgJAIQgIAIgMAAQgXgDgBgXg");
	this.shape_195.setTransform(660.5,435);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#D6D4D5").s().p("AAAAbQgWgCgEgZQgBgJAJgIQAKgJAKAAQAYAEABAWQAAALgIAIQgHAIgLAAIgBAAg");
	this.shape_196.setTransform(656.5,391.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQAAgKAIgIQAJgIAMAAQAXAEABAWQAAAMgIAIQgIAHgKAAIgBAAg");
	this.shape_197.setTransform(630.6,391.2);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgMQAAgLAHgHQAHgIALAAQAMAAAIAHQAIAHAAAMQgBAYgYADIgCAAQgJAAgIgHg");
	this.shape_198.setTransform(677.9,372.5);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAHgIQAHgHALgBQALAAAIAHQAJAIgBALQAAAXgZADIgCABQgJAAgHgIg");
	this.shape_199.setTransform(648.1,378.7);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#D6D4D5").s().p("AgBAaQgZgCAAgYQAAgLAJgIQAJgIAKABQAXAEACAWQgBAMgIAIQgIAHgKAAIgBgBg");
	this.shape_200.setTransform(639.3,416.3);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgWAagEQAJgBAJAIQAIAHABALQABAKgIAJQgIAJgLAAIgBAAQgKAAgIgHg");
	this.shape_201.setTransform(626.2,372.4);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#D6D4D5").s().p("AgDAbQgXgEAAgXQAAgLAIgIQAJgHAKAAQAXACACAZQABAKgJAIQgJAIgLAAIgBAAg");
	this.shape_202.setTransform(648.1,403.7);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#D6D4D5").s().p("AgBAbQgKgBgIgIQgIgJABgJQABgLAIgHQAIgIAKAAQALABAIAIQAIAIgBAKQAAALgJAIQgIAHgKAAIgBAAg");
	this.shape_203.setTransform(608.9,372.5);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#D6D4D5").s().p("AgEAbQgVgCgBgZQAAgLAIgHQAIgJALABQAYACABAZQABAKgJAJQgIAHgMAAIgCAAg");
	this.shape_204.setTransform(634.8,410);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAIgIQAIgIALAAQAXABADAXQAAALgIAJQgHAJgLAAIgBAAQgKAAgHgIg");
	this.shape_205.setTransform(669.3,372.4);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#D6D4D5").s().p("AgRATQgIgHAAgLQgBgLAIgIQAIgIALAAQAXACADAYQgDAZgYACIAAAAQgKAAgHgIg");
	this.shape_206.setTransform(673.9,403.7);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#D6D4D5").s().p("AAAAaQgXAAgDgaQAEgaAWAAQANAAAHAIQAIAIgBALQgBAMgIAHQgHAHgKAAIgBgBg");
	this.shape_207.setTransform(673.9,378.7);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#D6D4D5").s().p("AgRATQgJgIABgLQAAgLAIgIQAIgIAKABQAXACADAYQgCAYgYADIgBAAQgJAAgIgIg");
	this.shape_208.setTransform(669.1,422.6);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgXAZgDQALgBAIAIQAIAIAAALQAAALgIAIQgHAHgLABQgLAAgIgIg");
	this.shape_209.setTransform(643.2,422.5);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#D6D4D5").s().p("AAAAbQgZgBgBgZQAAgLAIgIQAJgIAKABQAXABADAYQAAAMgIAHQgHAIgLAAIgBAAg");
	this.shape_210.setTransform(630.6,416.2);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgMAHgGQAIgHALAAQANABAHAHQAHAHgBAMQgBAYgaACIgBAAQgJAAgIgJg");
	this.shape_211.setTransform(617.5,385);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAIAIQAIAIAAALQgBALgIAIQgIAHgKAAIgBAAg");
	this.shape_212.setTransform(660.5,422.6);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#D6D4D5").s().p("AgSAUQgHgIgBgMQABgXAZgDQALgBAHAIQAIAIAAALQAAAYgYADIgCAAQgKAAgIgHg");
	this.shape_213.setTransform(626,397.4);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#D6D4D5").s().p("AgaABQgBgJAJgJQAJgJAJAAQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgMAAQgWAAgEgag");
	this.shape_214.setTransform(634.7,435);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#D6D4D5").s().p("AgaABQgBgJAJgJQAJgJAJAAQALgBAIAIQAIAIAAALQAAALgHAIQgIAIgMAAQgWAAgEgag");
	this.shape_215.setTransform(643.3,435);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#D6D4D5").s().p("AgBAaQgZgBABgZQAAgLAIgIQAJgIAKABQALABAIAJQAHAJgCAKQgFAYgUAAIgCgBg");
	this.shape_216.setTransform(622.2,403.7);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgZAYgBQALgBAJAJQAJAIgBALQAAAKgIAIQgJAIgKAAQgKAAgIgIg");
	this.shape_217.setTransform(634.8,372.5);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#D6D4D5").s().p("AAAAaQgXAAgDgWQgBgLAIgJQAIgJALAAQALgBAIAHQAIAIAAAKQAAALgIAJQgHAIgLAAIgBgBg");
	this.shape_218.setTransform(643.4,372.4);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#D6D4D5").s().p("AgBAbQgLgBgIgJQgHgJABgKQAEgYAXAAQALAAAIAJQAIAIgBAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_219.setTransform(643.4,410);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgJAJgJQAIgJAKAAQAaACAAAaQgBAXgXABIgDABQgJAAgIgHg");
	this.shape_220.setTransform(656.4,416.3);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAIgIQAJgIAJAAQAZACACAYQABAJgIAJQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_221.setTransform(660.6,372.5);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgYAYgCQAKAAAJAHQAIAHABAMQABALgIAIQgIAIgMAAIAAAAQgKAAgIgIg");
	this.shape_222.setTransform(652,372.4);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgJAKABQAZAEABAWQAAAMgIAIQgIAHgOAAQgWgBgBgZg");
	this.shape_223.setTransform(665.1,428.7);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgKQACgYAYgCQAKgBAJAJQAIAIAAAKQAAAMgHAIQgIAHgMAAQgLAAgIgIg");
	this.shape_224.setTransform(656.5,428.7);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#D6D4D5").s().p("AgBAbQgMgBgHgIQgHgKACgNQABgKAIgGQAHgGALABQALAAAIAKQAHAJgCAKQgEAYgWAAIgBAAg");
	this.shape_225.setTransform(669.2,397.5);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgaQgBgJAJgJQAJgIAKAAQAXAAADAWQABANgJAJQgIAJgLAAIAAAAg");
	this.shape_226.setTransform(617.5,372.5);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgKAIgJQAIgIAKAAQALAAAIAJQAIAIAAAMQgBAWgZACIgBAAQgKAAgHgHg");
	this.shape_227.setTransform(651.9,422.5);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgJQAJgJAKABQALABAHAIQAHAIAAAKQgBAMgHAHQgHAHgKAAIgCAAg");
	this.shape_228.setTransform(630.6,428.7);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgJQAJgJAKABQALABAHAIQAHAIAAAKQAAAMgIAHQgHAHgKAAIgCAAg");
	this.shape_229.setTransform(639.2,428.7);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#D6D4D5").s().p("AgTATQgHgJAAgKQADgZAWgBQAKAAAJAHQAJAJAAAKQABAKgJAIQgIAJgLAAIAAAAQgLAAgIgIg");
	this.shape_230.setTransform(665.2,403.7);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#D6D4D5").s().p("AgSASQgJgIAAgKQABgLAJgIQAJgIAKABQALAAAIAIQAHAJgBALQgCAYgXABQgLAAgJgJg");
	this.shape_231.setTransform(647.9,416.3);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAYAAADAaQABAKgIAJQgIAIgMAAIAAAAQgLAAgHgHg");
	this.shape_232.setTransform(656.7,403.7);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQABgYAZgCQALAAAIAHQAIAIAAAMQgBAXgYADIgCAAQgJAAgIgHg");
	this.shape_233.setTransform(626.1,385);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgIQgJgJABgKQADgZAXAAQAMAAAIAHQAHAIAAALQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_234.setTransform(669.3,385);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQgBgJAJgJQAJgIALAAQAYABABAXQAAALgHAJQgIAIgKABIgCAAQgIAAgJgIg");
	this.shape_235.setTransform(652,385);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgXAWgDQAOAAAJAIQAIAHAAALQgBAXgaAEIgBAAQgJAAgIgIg");
	this.shape_236.setTransform(643.5,385);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgKAJgIQAJgJAMAAQAXAEABAWQAAALgHAIQgIAIgKAAIgCAAg");
	this.shape_237.setTransform(639.1,441.4);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgLAIgHQAIgIAKAAQALABAIAJQAIAJgBAJQgCAYgYABQgLAAgIgIg");
	this.shape_238.setTransform(651.9,397.4);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgZQAAgKAJgIQAJgIAMAAQAWADABAXQAAAMgIAIQgHAHgKAAIgCAAg");
	this.shape_239.setTransform(643.2,397.4);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#D6D4D5").s().p("AgBAbQgZgCAAgYQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAKQgBAMgIAHQgGAHgLAAIgCAAg");
	this.shape_240.setTransform(634.7,397.5);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQAAgLAIgIQAIgIALABQAYABACAUQAAANgIAKQgHAJgLAAIgBAAQgJAAgIgIg");
	this.shape_241.setTransform(660.6,384.9);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIALAAQAZACAAAYQAAAXgYAEQgLAAgJgIg");
	this.shape_242.setTransform(665.2,391.2);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgIAJQgIAIgLAAQgKAAgJgIg");
	this.shape_243.setTransform(622,391.2);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgLAHgIQAHgHAMAAQAZABACAYQAAALgIAJQgIAIgJAAIgCAAg");
	this.shape_244.setTransform(634.8,385);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#D6D4D5").s().p("AgaABQgBgKAIgJQAIgIALgBQALABAIAHQAIAJAAAKQAAAMgIAHQgIAIgLAAQgXAAgDgag");
	this.shape_245.setTransform(630.8,403.7);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgKQgBgKAIgJQAJgJAKABQAZAAACAZQABAJgJAKQgJAJgKAAIAAABQgJAAgIgJg");
	this.shape_246.setTransform(630.8,378.7);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#D6D4D5").s().p("AgTASQgIgJABgKQADgaAXABQAMAAAIAIQAIAJgBAKQgDAYgYACIgCAAQgJAAgIgJg");
	this.shape_247.setTransform(665.3,378.7);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQACgXAYgDQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgKAAQgLAAgIgIg");
	this.shape_248.setTransform(665.1,416.2);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#D6D4D5").s().p("AgSASQgJgIACgKQADgaAXAAQALAAAIAJQAHAIAAANQgEAXgXAAQgKAAgIgJg");
	this.shape_249.setTransform(660.6,409.9);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgIAKAAQAZACABAYQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_250.setTransform(651.9,410);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQAAgMAIgHQAHgIAMABQAXABADAZQABAKgJAJQgJAJgKAAQgLgBgIgIg");
	this.shape_251.setTransform(656.7,378.7);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#D6D4D5").s().p("AgaACQgBgLAHgIQAHgIAMgBQALgBAIAIQAIAHABAMQABAJgJAJQgJAJgMAAQgXgDgBgWg");
	this.shape_252.setTransform(613.6,378.7);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#D6D4D5").s().p("AAAAcQgLgBgIgJQgHgJAAgKQABgLAIgIQAIgHALAAQAWADADAXQAAAMgIAJQgJAIgKAAIAAAAg");
	this.shape_253.setTransform(639.4,378.7);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#D6D4D5").s().p("AgTAUQgHgIAAgMQABgXAZgDQAKgBAJAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgHg");
	this.shape_254.setTransform(651.8,435);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQAAgLAIgHQAIgIALAAQALAAAIAIQAIAIgBAKQAAAMgIAIQgIAHgLAAQgKAAgIgIg");
	this.shape_255.setTransform(656.5,441.3);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQAAgLAIgHQAIgIAKAAQAMAAAIAIQAHAIAAAKQAAAMgIAIQgIAHgLAAQgKAAgIgIg");
	this.shape_256.setTransform(647.8,441.3);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQABgYAZgCQAKAAAIAHQAJAIAAALQABAKgJAJQgIAIgLAAIgBAAQgKAAgIgIg");
	this.shape_257.setTransform(660.5,397.5);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgHgJQgJgIABgKQABgLAJgIQAJgJAJACQAZADAAAXQAAAMgHAIQgIAHgLAAIgBAAg");
	this.shape_258.setTransform(647.9,391.2);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#D6D4D5").s().p("AABAbQgZgBgCgYQgBgKAIgJQAHgIAMgBQAKgBAIAIQAJAHAAAMQABAKgIAJQgIAIgKAAIgBAAg");
	this.shape_259.setTransform(673.8,391.2);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgZQgBgKAIgIQAIgIALAAQALgBAIAJQAJAIgBAKQAAALgIAIQgHAIgKAAIgCAAg");
	this.shape_260.setTransform(626.1,410);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgKAIgIQAIgJAKAAQALABAJAIQAIAJgBAKQgDAagXAAIgCABQgKAAgHgIg");
	this.shape_261.setTransform(639.4,403.7);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#D6D4D5").s().p("AgBAbQgYgDgBgYQAAgKAIgJQAJgIAKABQALAAAIAJQAIAIgBAKQAAAMgJAIQgHAGgJAAIgDAAg");
	this.shape_262.setTransform(669.3,410);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgYAZgCQAMgBAIAHQAIAHAAAMQABALgIAIQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_263.setTransform(626,422.7);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQABgYAYgCQAMgBAIAHQAIAHAAAMQABALgIAIQgIAJgLAAIgBAAQgJAAgIgIg");
	this.shape_264.setTransform(634.6,422.7);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQACgWAYgEQAKgBAIAJQAJAJAAAMQgCAWgYACIgBAAQgKAAgIgIg");
	this.shape_265.setTransform(686.4,359.5);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#D6D4D5").s().p("AAAAbQgZgDAAgYQAAgLAJgIQAIgJAKACQAZAFgBAaQAAAJgIAHQgHAGgLAAIAAAAg");
	this.shape_266.setTransform(634.6,359.5);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#D6D4D5").s().p("AgSATQgIgJABgKQACgXAYgCQAaADAAAWQAAAagZABQgLgBgJgHg");
	this.shape_267.setTransform(604.7,353.3);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#D6D4D5").s().p("AAAAaQgKAAgJgKQgIgKABgKQACgVAXAAQAMAAAIAHQAIAHAAALQAAAKgIAIQgJAIgKAAIAAAAg");
	this.shape_268.setTransform(583,297.1);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#D6D4D5").s().p("AAAAbQgJAAgJgKQgJgKACgIQAEgXAVgCQAaABABAZQAAAKgJAIQgIAJgJAAIgBAAg");
	this.shape_269.setTransform(570.2,303.2);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgJQgIgJAAgMQADgVAYgBQAKAAAIAJQAIAIAAAJQgBALgIAIQgIAIgIAAIgCAAg");
	this.shape_270.setTransform(574.3,296.9);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#D6D4D5").s().p("AgSAUQgHgHgBgMQAAgKAIgJQAJgIAKABQAYABABAZQABALgJAHQgIAIgNAAQgKgBgFgGg");
	this.shape_271.setTransform(682.4,340.7);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQABgWAZgFQAKgBAIAJQAIAIABALQgCAYgXACIgCAAQgKAAgHgHg");
	this.shape_272.setTransform(647.9,353.2);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQADgZAXgBQALAAAIAJQAJAJgBAKQgDAYgWABQgMAAgJgIg");
	this.shape_273.setTransform(686.6,334.4);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#D6D4D5").s().p("AgRAUQgIgHgBgMQAAgKAIgJQAJgIAJAAQAZADACAYQgCAYgXABIgCABQgKAAgHgHg");
	this.shape_274.setTransform(691.1,353.2);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgHgIQgIgJAAgKQADgZAXAAQAZAAABAaQABAKgJAJQgIAIgKAAIAAAAg");
	this.shape_275.setTransform(622.2,303.2);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#D6D4D5").s().p("AgTASQgIgJACgKQACgXAXgCQAMABAIAIQAIAIgBALQgCAXgZACIgBAAQgKAAgIgJg");
	this.shape_276.setTransform(639.3,315.7);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgHgIQgIgIABgLQACgYAXgBQALAAAIAJQAIAJgBAKQAAAKgIAIQgIAHgKAAIAAAAg");
	this.shape_277.setTransform(682.4,315.7);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#D6D4D5").s().p("AgRAUQgIgHgBgMQAAgJAJgKQAIgJAKABQAYADACAYQgCAZgXAAIgCABQgKAAgHgHg");
	this.shape_278.setTransform(622,353.2);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#D6D4D5").s().p("AgBAaQgYgCgBgYQAAgLAJgHQAIgIALAAQAXACACAWQgBAMgIAJQgHAIgKAAIgCgBg");
	this.shape_279.setTransform(630.4,365.8);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgIAJAAQAZADABAXQABALgJAIQgIAIgMAAQgXgDgBgXg");
	this.shape_280.setTransform(660.5,359.5);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#D6D4D5").s().p("AgZABQgBgKAJgJQAJgJAJACQAaADgBAXQgBAagZAAQgYgBgBgZg");
	this.shape_281.setTransform(673.8,353.2);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#D6D4D5").s().p("AAAAbQgWgCgEgZQgBgJAJgIQAKgJAKAAQAYAEABAWQAAALgIAIQgHAIgLAAIgBAAg");
	this.shape_282.setTransform(656.5,315.7);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQAAgKAIgIQAJgIAMAAQAXAEABAWQAAAMgIAIQgIAHgKAAIgBAAg");
	this.shape_283.setTransform(630.6,315.7);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgMQAAgLAHgHQAHgIALAAQAMAAAIAHQAIAHAAAMQgBAYgYADIgCAAQgJAAgIgHg");
	this.shape_284.setTransform(677.9,297);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgLAGgHQAHgIAMgBQAKgBAJAIQAIAIABALQAAAKgIAJQgIAIgJAAIgCAAg");
	this.shape_285.setTransform(677.9,309.4);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#D6D4D5").s().p("AgaAAQAAgYAZgBQALgBAIAIQAJAIgBAKQgCAYgYADQgagEAAgXg");
	this.shape_286.setTransform(596.3,303.2);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#D6D4D5").s().p("AgSASQgJgKABgJQACgLAGgHQAGgHAJAAQAOAAAJAIQAIAHgBALQgCAZgZABIAAABQgKAAgIgJg");
	this.shape_287.setTransform(578.9,303.2);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgIQAIgJAKAAQALABAIAIQAIAIgBALQgCAZgXAAIgCAAg");
	this.shape_288.setTransform(695,347);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#D6D4D5").s().p("AgaACQAAgLAHgIQAIgIALgBQAKAAAJAIQAIAIAAAKQAAALgIAIQgJAIgKAAQgYgDgCgWg");
	this.shape_289.setTransform(626,347);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAHgIQAHgHALgBQALAAAIAHQAJAIgBALQAAAXgZADIgCABQgJAAgHgIg");
	this.shape_290.setTransform(648.1,303.2);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#D6D4D5").s().p("AgBAaQgZgCAAgYQAAgLAJgIQAJgIAKABQAXADACAXQgBAMgIAIQgIAHgKAAIgBgBg");
	this.shape_291.setTransform(639.3,340.8);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgWAagEQAJgBAJAIQAIAHABALQABAKgIAJQgIAJgLAAIgCAAQgJAAgIgHg");
	this.shape_292.setTransform(626.2,296.9);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#D6D4D5").s().p("AgDAbQgXgEAAgXQAAgLAIgIQAJgHAKAAQAXACACAZQABAKgJAIQgJAIgLAAIgBAAg");
	this.shape_293.setTransform(648.1,328.2);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#D6D4D5").s().p("AgBAbQgKgBgIgIQgIgJABgJQABgLAIgHQAIgIAKAAQALABAIAIQAIAIgBAKQAAALgJAHQgJAIgJAAIgBAAg");
	this.shape_294.setTransform(608.9,297);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#D6D4D5").s().p("AgaABQgBgKAIgIQAIgJALAAQAXAAAEAaQABAKgIAIQgIAJgLAAQgZgCgCgYg");
	this.shape_295.setTransform(686.6,297);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#D6D4D5").s().p("AgBAaQgYgDgBgWQAAgMAJgIQAIgIALABQAYADABAXQAAAMgJAIQgIAHgIAAIgDgBg");
	this.shape_296.setTransform(691.3,303.2);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIAKAAQAXACADAYQgCAZgXABIgCABQgKAAgHgIg");
	this.shape_297.setTransform(613.4,340.8);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#D6D4D5").s().p("AgEAbQgVgDgBgYQAAgLAIgHQAIgJALABQAYACABAZQABAKgJAIQgIAIgMAAIgCAAg");
	this.shape_298.setTransform(634.8,334.5);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAIgIQAIgIALAAQAXABADAXQAAALgIAJQgHAJgLAAIgBAAQgKAAgHgIg");
	this.shape_299.setTransform(669.3,296.9);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#D6D4D5").s().p("AgTATQgHgJAAgKQAAgKAIgIQAJgIAKAAQAaAEAAAWQABAMgJAHQgHAIgMAAQgKAAgJgIg");
	this.shape_300.setTransform(695.2,296.8);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#D6D4D5").s().p("AgRATQgIgHAAgLQgBgLAIgIQAIgIALAAQAXACADAYQgDAZgYACIAAAAQgKAAgHgIg");
	this.shape_301.setTransform(673.9,328.2);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgMAIgHQAIgIAOAAQAJABAHAHQAGAHABALQABALgJAIQgIAIgKAAIgBAAg");
	this.shape_302.setTransform(605,328.2);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQAAgKAJgJQAIgHAKAAQAMABAHAHQAIAJgBALQgCAXgZACIAAAAQgKAAgIgIg");
	this.shape_303.setTransform(686.4,322);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQgBgLAIgIQAIgIALAAQAJAAAJAIQAKAJgBAJQgCAYgYADIgBAAQgKAAgHgHg");
	this.shape_304.setTransform(582.9,322);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#D6D4D5").s().p("AgRATQgJgJABgKQACgXAYgDQAaAEAAAWQAAAYgaADIgBAAQgKAAgHgIg");
	this.shape_305.setTransform(613.3,315.7);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQACgYAYgBQALgBAIAIQAIAIgBALQgCAXgWADQgMAAgIgIg");
	this.shape_306.setTransform(587.5,315.7);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#D6D4D5").s().p("AgTASQgIgJABgNQACgWAYAAQALAAAIAJQAJAJgBAKQgCAWgZADIgCAAQgJAAgIgJg");
	this.shape_307.setTransform(591.7,309.4);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#D6D4D5").s().p("AAAAaQgXAAgDgaQAEgaAWAAQANAAAHAIQAIAIgBALQgBAMgIAHQgHAHgKAAIgBgBg");
	this.shape_308.setTransform(673.9,303.2);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#D6D4D5").s().p("AgTASQgIgIABgLQACgZAYAAQALAAAIAIQAJAJgBAKQgBALgIAHQgIAIgKAAQgLgBgIgIg");
	this.shape_309.setTransform(605,303.2);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#D6D4D5").s().p("AgRATQgJgIABgLQAAgLAIgIQAIgIAKABQAXACADAYQgCAYgYADIgBAAQgJAAgIgIg");
	this.shape_310.setTransform(669.1,347.1);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgXAZgDQALgBAIAIQAIAIAAALQAAALgIAIQgHAHgLABQgLAAgIgIg");
	this.shape_311.setTransform(643.2,347);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgLAIgIQAJgIAKABQAXABADAYQAAAMgIAHQgHAIgLAAIgBAAg");
	this.shape_312.setTransform(630.6,340.7);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgMAHgGQAIgHALAAQANABAHAHQAHAHgBAMQgBAYgaACIgBAAQgJAAgIgJg");
	this.shape_313.setTransform(617.5,309.5);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQACgXAWgDQALgBAJAJQAJAIgBAKQgBAZgYACIgBAAQgJAAgIgHg");
	this.shape_314.setTransform(691.2,315.7);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgaQgBgKAIgIQAJgIALAAQAWABAEAZQAAAKgIAJQgIAIgLAAIAAAAg");
	this.shape_315.setTransform(617.3,347.1);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAIAIQAIAIAAAKQgBAMgIAIQgIAHgKAAIgBAAg");
	this.shape_316.setTransform(660.5,347.1);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#D6D4D5").s().p("AgaAAQAAgKAIgIQAJgIAKAAQAMABAHAIQAHAIgBALQgBAZgZAAQgZgBgBgag");
	this.shape_317.setTransform(695.1,321.9);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQACgaAYAAQALAAAIAIQAIAIAAAKQgCAagYABIgBAAQgKAAgHgIg");
	this.shape_318.setTransform(677.8,322);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#D6D4D5").s().p("AAAAbQgZgBgBgaQAAgKAJgJQAIgIAKABQAMACAHAFQAHAGAAAIQgBAggaAAIAAAAg");
	this.shape_319.setTransform(677.7,359.5);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#D6D4D5").s().p("AgSAUQgHgIgBgMQABgXAZgDQALgBAHAIQAIAIAAALQAAAYgYADIgCAAQgKAAgIgHg");
	this.shape_320.setTransform(626,321.9);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#D6D4D5").s().p("AgaABQgBgJAJgJQAJgJAJAAQALgBAIAIQAIAIAAALQAAALgHAIQgIAIgMAAQgWAAgEgag");
	this.shape_321.setTransform(643.3,359.5);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#D6D4D5").s().p("AAAAbQgagBAAgZQAAgXAZgDQAKgCAJAJQAIAIAAAKQABAMgJAIQgHAHgJAAIgCAAg");
	this.shape_322.setTransform(608.8,359.5);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgJgIQgIgJABgKQAEgYAXgBQALAAAIAIQAHAIAAALQgBAMgIAHQgHAHgKAAIgBAAg");
	this.shape_323.setTransform(682.2,365.8);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#D6D4D5").s().p("AAAAaQgYgBgBgYQgBgLAIgHQAIgIANgBQAVAAADAZQABAKgJAJQgIAJgJAAIgCgBg");
	this.shape_324.setTransform(613.2,365.9);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#D6D4D5").s().p("AgaACQgBgJAIgKQAJgJAKAAQAJgBAJAJQAJAJAAAJQAAAMgHAIQgIAHgMAAQgXAAgDgZg");
	this.shape_325.setTransform(630.7,353.2);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#D6D4D5").s().p("AgBAaQgZgBABgZQAAgLAIgIQAJgIAKABQALABAIAJQAHAJgCAKQgFAYgUAAIgCgBg");
	this.shape_326.setTransform(622.2,328.2);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAXABAEAZQABAKgIAJQgJAJgLAAQgKAAgIgIg");
	this.shape_327.setTransform(613.6,328.2);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgZAYgBQALgBAJAJQAJAIgBALQAAAKgIAIQgJAIgKAAQgKAAgIgIg");
	this.shape_328.setTransform(634.8,297);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#D6D4D5").s().p("AAAAbQgXgCgDgVQgBgLAIgJQAIgJALAAQALgBAIAHQAIAIAAAKQAAALgIAJQgHAIgLAAIgBAAg");
	this.shape_329.setTransform(643.4,296.9);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#D6D4D5").s().p("AgBAbQgLgBgIgJQgHgJABgKQAEgYAXAAQALAAAIAJQAIAIgBAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_330.setTransform(643.4,334.5);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgJAJgJQAIgJAKAAQAaACAAAaQgBAXgXABIgDABQgJAAgIgHg");
	this.shape_331.setTransform(656.4,340.8);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQADgYAXgCQALgBAIAJQAIAIAAAMQAAAWgaADIgBAAQgKAAgIgIg");
	this.shape_332.setTransform(604.7,315.7);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#D6D4D5").s().p("AgCAbQgXgDgBgXQAAgMAIgIQAIgIALAAQALABAHAJQAIAIAAAKQgBALgJAIQgIAIgJAAIgCgBg");
	this.shape_333.setTransform(691.2,340.8);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgKQABgXAZgDQAYADADAXQABAKgJAIQgIAJgLAAQgLAAgIgIg");
	this.shape_334.setTransform(691.3,328.2);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAIgIQAJgIAJAAQAZABACAZQABAKgIAIQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_335.setTransform(660.6,297);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgYAYgCQAKgBAJAIQAIAHABAMQABALgIAIQgIAIgMAAIAAAAQgKAAgIgIg");
	this.shape_336.setTransform(652,296.9);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgJAKABQAZAEABAWQAAAMgIAIQgIAHgOAAQgWgBgBgZg");
	this.shape_337.setTransform(665.1,353.2);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgKQACgYAYgCQAKgBAJAJQAIAIAAAKQAAAMgHAIQgIAHgMAAQgLAAgIgIg");
	this.shape_338.setTransform(656.5,353.2);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#D6D4D5").s().p("AgBAbQgMAAgHgJQgHgKACgNQABgKAIgFQAHgHALABQALAAAIAJQAHAKgCAKQgEAYgWAAIgBAAg");
	this.shape_339.setTransform(669.2,322);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgZQgBgJAJgJQAJgIAKAAQAXAAADAWQABANgJAJQgIAJgLAAIAAAAg");
	this.shape_340.setTransform(617.5,297);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#D6D4D5").s().p("AAAAbQgZgEgBgXQgBgKAIgIQAIgIALAAQAMAAAIAHQAIAIgBALQAAALgIAIQgIAIgKAAIgBAAg");
	this.shape_341.setTransform(608.7,347.1);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAMQgBAWgZACIgBAAQgKAAgHgHg");
	this.shape_342.setTransform(651.9,347);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgLQAEgZAWAAQAMAAAHAIQAIAHAAALQgBAYgZADIgBAAQgKAAgIgIg");
	this.shape_343.setTransform(677.8,347.1);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgJQAJgJAKABQALABAHAIQAHAIAAAKQAAAMgIAHQgHAHgKAAIgCAAg");
	this.shape_344.setTransform(639.2,353.2);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#D6D4D5").s().p("AgTATQgHgJAAgKQADgZAWgBQAKAAAJAHQAJAIAAALQABAKgJAIQgIAJgLAAIAAAAQgLAAgIgIg");
	this.shape_345.setTransform(665.2,328.2);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#D6D4D5").s().p("AgSASQgJgIAAgKQABgLAJgIQAJgIAKABQALAAAIAIQAHAJgBALQgCAYgXABQgLAAgJgJg");
	this.shape_346.setTransform(647.9,340.8);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAYAAADAaQABAKgIAJQgIAIgMAAIAAAAQgLAAgHgHg");
	this.shape_347.setTransform(656.7,328.2);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQABgYAZgCQALAAAIAHQAIAIAAAMQgBAXgYADIgCAAQgJAAgIgHg");
	this.shape_348.setTransform(626.1,309.5);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgZQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAJAAAKQgBAMgIAIQgHAGgJAAIgCAAg");
	this.shape_349.setTransform(578.8,315.7);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgJQgJgKABgJQAEgYAYAAQAZACAAAYQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_350.setTransform(608.8,309.5);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgIQgJgJABgKQADgZAXAAQAMAAAIAHQAHAIAAALQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_351.setTransform(669.3,309.5);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgLQABgXAYgCQAZAAADAZQABAIgJAKQgJAJgKABIAAAAQgKAAgIgIg");
	this.shape_352.setTransform(686.6,309.5);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgKQgBgLAIgIQAIgJALABQAYABADAXQAAALgHAJQgIAIgLABIgBAAQgJAAgIgHg");
	this.shape_353.setTransform(591.6,297);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQgBgKAJgIQAJgIALAAQAYABABAXQAAALgHAIQgIAJgKABIgCAAQgIAAgJgIg");
	this.shape_354.setTransform(652,309.5);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgXAWgDQAOAAAJAIQAIAHAAALQgBAXgaAEIgBAAQgJAAgIgIg");
	this.shape_355.setTransform(643.5,309.5);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#D6D4D5").s().p("AAAAbQgKAAgIgJQgIgIAAgKQABgKAJgJQAJgIAJABQAZADAAAVQAAANgIAJQgHAHgLAAIgBAAg");
	this.shape_356.setTransform(591.4,322);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgaQgBgJAJgJQAJgIAKAAQALAAAIAIQAIAIgBALQAAAMgIAHQgHAHgLAAIgBAAg");
	this.shape_357.setTransform(690.9,365.8);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#D6D4D5").s().p("AAAAaQgZgCgBgYQAAgLAJgHQAIgIAPAAQAJABAFAHQAGAHAAALQABALgIAIQgHAIgKAAIgCgBg");
	this.shape_358.setTransform(656.4,365.9);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgKAJgIQAJgJAMAAQAXAEABAWQAAALgHAIQgIAIgKAAIgCAAg");
	this.shape_359.setTransform(639.1,365.9);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgLAIgHQAIgIAKAAQALABAIAJQAIAJgBAJQgCAYgYABQgLAAgIgIg");
	this.shape_360.setTransform(651.9,321.9);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgKAJgIQAJgIAMAAQAWADABAXQAAAMgIAIQgHAHgKAAIgCAAg");
	this.shape_361.setTransform(643.2,321.9);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#D6D4D5").s().p("AgBAbQgZgCAAgYQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAKQgBAMgIAHQgGAHgLAAIgCAAg");
	this.shape_362.setTransform(634.7,322);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQAAgLAIgIQAIgIALABQAYABACAUQAAANgIAKQgHAJgLAAIgBAAQgJAAgIgIg");
	this.shape_363.setTransform(660.6,309.4);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#D6D4D5").s().p("AgaAAQAAgKAIgIQAIgJAKABQAMAAAIAIQAHAIgBALQAAAXgaADQgYgDgCgYg");
	this.shape_364.setTransform(600.1,322);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgLQACgWAYgDQALAAAJAIQAIAJgBAKQAAALgJAIQgIAHgLAAQgLgBgHgHg");
	this.shape_365.setTransform(617.4,322);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgJAKABQAZADABAXQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_366.setTransform(608.7,322);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#D6D4D5").s().p("AAAAbQgMgCgHgHQgHgHAAgLQABgZAZgBQAMgBAHAIQAJAIgBALQAAALgJAIQgIAIgJAAIgBAAg");
	this.shape_367.setTransform(695.2,309.5);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIALAAQAZACAAAYQAAAXgYAEQgLAAgJgIg");
	this.shape_368.setTransform(665.2,315.7);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgIAJQgIAIgLAAQgKAAgJgIg");
	this.shape_369.setTransform(622,315.7);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#D6D4D5").s().p("AAAAbQgagEAAgXQAAgLAJgHQAJgIANAAQAWACAAAYQAAALgJAJQgHAHgJAAIgCAAg");
	this.shape_370.setTransform(583,309.5);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#D6D4D5").s().p("AgRAVQgIgHgBgMQgBgKAIgJQAIgIALgBQALAAAIAIQAJAIgBAKQAAAMgIAIQgHAGgLABIgBAAQgLAAgGgGg");
	this.shape_371.setTransform(574.3,309.5);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#D6D4D5").s().p("AABAbQgYgBgDgYQgBgKAIgJQAIgJALAAQALgBAIAIQAIAIAAALQABAMgIAIQgHAHgLAAIgBAAg");
	this.shape_372.setTransform(596.1,315.7);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgLAHgIQAHgHAMAAQAZABACAYQAAALgIAJQgIAIgJAAIgCAAg");
	this.shape_373.setTransform(634.8,309.5);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#D6D4D5").s().p("AgaABQgBgKAIgJQAIgIALgBQALABAIAHQAIAJAAAKQAAAMgIAIQgIAHgLAAQgXAAgDgag");
	this.shape_374.setTransform(630.8,328.2);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQAAgLAJgHQAIgJAKABQAaABAAAZQABAMgIAHQgIAIgLAAIgBAAQgKAAgIgIg");
	this.shape_375.setTransform(673.6,365.8);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgYAZgCQAYAAADAZQABAKgIAJQgIAIgLABIgBAAQgKAAgIgIg");
	this.shape_376.setTransform(665,365.8);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgKQgBgKAIgJQAJgJAKAAQAZACACAYQABAJgJAJQgJAKgKAAIAAABQgJAAgIgJg");
	this.shape_377.setTransform(630.8,303.2);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#D6D4D5").s().p("AgTASQgIgJABgKQADgaAXABQAMAAAIAIQAIAJgBAKQgDAYgYACIgCAAQgJAAgIgJg");
	this.shape_378.setTransform(665.3,303.2);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQACgXAYgDQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgKAAQgLAAgIgIg");
	this.shape_379.setTransform(665.1,340.7);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQAAgKAJgIQAJgJAJABQAMAAAHAIQAHAJAAANQgCAVgYACIgBAAQgJAAgIgIg");
	this.shape_380.setTransform(604.7,340.8);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#D6D4D5").s().p("AgSASQgJgIABgKQADgZAXgBQALAAAIAHQAIAIAAALQAAALgHAIQgIAIgMAAQgKAAgIgJg");
	this.shape_381.setTransform(600.2,296.9);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgIQAIgJAKAAQALAAAIAIQAIAIAAAKQAAAMgJAHQgJAIgNAAQgUgCgCgYg");
	this.shape_382.setTransform(677.9,334.4);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#D6D4D5").s().p("AgSASQgJgIACgKQADgaAXAAQALAAAIAJQAHAIAAANQgEAXgXAAQgKAAgIgJg");
	this.shape_383.setTransform(660.6,334.4);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgIAKAAQAZACABAYQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_384.setTransform(651.9,334.5);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgMQAEgXAVgCQAKAAAJAHQAIAIABALQABALgIAIQgHAIgMAAQgKAAgIgIg");
	this.shape_385.setTransform(617.5,334.5);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#D6D4D5").s().p("AgRATQgJgIABgLQABgZAYgBQAKgBAIAIQAIAIABANQgCAXgXACIgCAAQgJAAgIgIg");
	this.shape_386.setTransform(608.8,334.5);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAHAIQAIAJAAAKQAAALgJAIQgHAHgJAAIgCAAg");
	this.shape_387.setTransform(565.7,297);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAIgIQAJgIAKAAQALAAAIAIQAIAIgBAKQAAAZgaACIgBAAQgJAAgJgIg");
	this.shape_388.setTransform(695,359.5);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#D6D4D5").s().p("AAAAbQgMgBgHgIQgIgJABgKQACgYAYgBQALgBAIAJQAIAIAAALQAAALgJAIQgHAHgKAAIgBAAg");
	this.shape_389.setTransform(617.4,359.6);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgJAJgJQAJgJAJABQAZACABAYQABALgIAIQgHAIgMAAIgBAAQgKAAgIgHg");
	this.shape_390.setTransform(682.4,353.2);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQAAgMAIgHQAHgIAMABQAXABADAZQABAKgJAJQgJAJgKAAQgLgBgIgIg");
	this.shape_391.setTransform(656.7,303.2);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#D6D4D5").s().p("AgaACQgBgLAHgIQAHgIAMgBQALgBAIAIQAIAHABAMQABAJgJAJQgJAJgMAAQgXgDgBgWg");
	this.shape_392.setTransform(613.6,303.2);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#D6D4D5").s().p("AAAAbQgKAAgJgJQgIgJABgKQACgYAYgBQALgBAJAIQAIAIgBALQAAALgIAIQgIAIgLAAIAAAAg");
	this.shape_393.setTransform(587.6,303.2);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgJgJQgIgJABgJQADgZAXAAQAMAAAIAHQAHAIAAALQAAALgJAIQgHAIgJAAIgCAAg");
	this.shape_394.setTransform(600.2,309.5);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgLAJgIQAIgHANAAQAVABACAZQABAKgJAIQgIAKgLgBQgKAAgIgIg");
	this.shape_395.setTransform(682.6,303.2);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#D6D4D5").s().p("AAAAcQgLgBgIgJQgHgJAAgKQABgMAIgHQAIgHALABQAWACADAXQAAAMgIAJQgJAIgKAAIAAAAg");
	this.shape_396.setTransform(639.4,303.2);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#D6D4D5").s().p("AgTATQgHgIAAgLQAAgMAIgHQAJgIAKABQAZABABAZQABALgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_397.setTransform(621.9,365.9);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgJAIgJQAIgJALAAQALgBAIAJQAJAIAAAKQAAALgJAIQgIAIgJAAIgCAAg");
	this.shape_398.setTransform(695.2,334.5);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgYQgBgKAIgJQAJgJAKAAQALgBAIAIQAIAIAAALQABALgIAJQgIAHgLAAIgBAAg");
	this.shape_399.setTransform(570.2,315.7);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#D6D4D5").s().p("AgTAUQgHgIAAgMQABgXAZgDQAKgBAJAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgHg");
	this.shape_400.setTransform(651.8,359.5);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#D6D4D5").s().p("AgSAUQgJgJABgLQABgYAZgCQAJgBAJAIQAJAIAAALQABALgIAIQgHAIgNAAIAAAAQgLAAgHgHg");
	this.shape_401.setTransform(613.4,353.2);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#D6D4D5").s().p("AAAAbQgXgCgDgYQgBgKAIgIQAIgIALgBQAMAAAIAHQAHAHAAAMQAAALgIAIQgHAIgKAAIgCAAg");
	this.shape_402.setTransform(686.4,347.1);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQAAgLAIgIQAIgIAKABQAMAAAIAIQAHAIAAAKQAAAMgIAIQgIAHgLAAQgKAAgIgIg");
	this.shape_403.setTransform(647.8,365.8);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgKAIgJQAIgIAKAAQAMAAAIAIQAIAJgBAKQgBAZgZABIgBAAQgKAAgHgHg");
	this.shape_404.setTransform(622,340.8);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#D6D4D5").s().p("AgaACQgBgKAIgJQAIgJALAAQAKgBAIAIQAJAIAAALQABALgJAIQgIAIgMABQgWgCgDgYg");
	this.shape_405.setTransform(673.8,340.8);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgIABgLQAAgLAIgIQAJgIAKABQAZACABAYQABALgJAIQgIAIgLAAIAAAAg");
	this.shape_406.setTransform(682.6,328.2);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgJAJQgIAIgLAAIgBAAQgKAAgIgIg");
	this.shape_407.setTransform(660.5,322);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgHgJQgJgIABgKQABgLAJgIQAJgJAJACQAZADAAAXQAAAMgHAIQgIAHgLAAIgBAAg");
	this.shape_408.setTransform(647.9,315.7);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#D6D4D5").s().p("AABAbQgZgBgCgYQgBgKAIgJQAHgIAMgBQAKgBAIAIQAJAHAAAMQABAKgIAJQgIAIgKAAIgBAAg");
	this.shape_409.setTransform(673.8,315.7);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgZQgBgKAIgIQAIgIALAAQALgBAIAJQAJAIgBAKQAAALgIAIQgHAIgKAAIgCAAg");
	this.shape_410.setTransform(626.1,334.5);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgKAIgIQAIgJAKAAQALABAJAIQAIAJgBAKQgDAagXAAIgBABQgLAAgHgIg");
	this.shape_411.setTransform(639.4,328.2);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#D6D4D5").s().p("AgBAbQgYgDgBgYQAAgKAIgJQAJgIAKABQALAAAIAJQAIAIgBAKQAAAMgJAHQgHAHgKAAIgCAAg");
	this.shape_412.setTransform(669.3,334.5);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#D6D4D5").s().p("AAAAbQgMAAgHgIQgIgJABgKQAAgMAJgHQAIgIALABQAYADACAYQAAALgIAIQgJAHgLAAIAAAAg");
	this.shape_413.setTransform(669.1,359.5);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQABgYAYgCQAMgBAIAHQAIAHAAAMQABAKgIAJQgIAIgLABIgBAAQgJAAgIgIg");
	this.shape_414.setTransform(634.6,347.2);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQAAgLAIgIQAJgIAKABQAZABABAZQABAKgIAJQgIAIgMAAQgKAAgIgIg");
	this.shape_415.setTransform(626,359.5);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQACgWAYgEQAKgBAIAJQAJAJAAAMQgCAWgYACIgBAAQgKAAgIgIg");
	this.shape_416.setTransform(686.4,284);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#D6D4D5").s().p("AAAAbQgZgDAAgYQAAgLAJgIQAIgJAKACQAZAFgBAaQAAAJgIAHQgHAGgLAAIAAAAg");
	this.shape_417.setTransform(634.6,284);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#D6D4D5").s().p("AgSATQgIgJABgKQACgXAYgCQAaADAAAWQAAAagZABQgLgBgJgHg");
	this.shape_418.setTransform(604.7,277.8);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#D6D4D5").s().p("AgSAUQgHgHgBgMQAAgKAIgJQAJgIAKABQAYABABAZQABALgJAHQgIAIgNAAQgKgBgFgGg");
	this.shape_419.setTransform(682.4,265.2);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQABgWAZgFQAKgBAIAJQAIAIABALQgCAYgXACIgCAAQgKAAgHgHg");
	this.shape_420.setTransform(647.9,277.7);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQADgZAXgBQALAAAIAJQAJAJgBAKQgDAYgWABQgMAAgJgIg");
	this.shape_421.setTransform(686.6,258.9);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#D6D4D5").s().p("AgRAUQgIgHgBgMQAAgKAIgJQAJgIAJAAQAZADACAYQgCAYgXABIgCABQgKAAgHgHg");
	this.shape_422.setTransform(691.1,277.7);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgHAKAAQAKAAAIAHQAIAJgBAKQgBAZgZAAQgXAAgDgZg");
	this.shape_423.setTransform(587.5,265.3);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgHgIQgIgJAAgKQADgZAXAAQAZAAABAaQABAKgJAJQgIAIgKAAIAAAAg");
	this.shape_424.setTransform(622.2,227.7);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#D6D4D5").s().p("AgTASQgIgJACgKQACgXAXgCQAMABAIAIQAIAIgBALQgCAXgZABIgCABQgKAAgHgJg");
	this.shape_425.setTransform(639.3,240.2);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#D6D4D5").s().p("AgQAUQgJgIgBgLQAAgIAIgJQAJgJAKgBQAKAAAIAHQAIAIAAALQgBAZgXABIgDABQgJAAgHgHg");
	this.shape_426.setTransform(596,277.7);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#D6D4D5").s().p("AgRAUQgIgHgBgMQAAgJAJgKQAIgJAKABQAYADACAYQgCAZgXAAIgCABQgKAAgHgHg");
	this.shape_427.setTransform(622,277.7);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#D6D4D5").s().p("AgBAaQgYgCgBgYQAAgLAJgHQAIgIALAAQAXACACAWQgBAMgIAJQgHAIgKAAIgCgBg");
	this.shape_428.setTransform(630.4,290.3);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgIAJAAQAZADABAXQABALgJAIQgIAIgMAAQgXgDgBgXg");
	this.shape_429.setTransform(660.5,284);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgZQAAgKAJgIQAJgJAJAAQAKAAAIAJQAIAIAAAJQAAAMgHAHQgIAIgLAAIgBAAg");
	this.shape_430.setTransform(591.4,284);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#D6D4D5").s().p("AgZABQgBgKAJgJQAJgJAJACQAaADgBAXQgBAagZAAQgYgBgBgZg");
	this.shape_431.setTransform(673.8,277.7);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#D6D4D5").s().p("AAAAaQgWAAgEgaQgBgJAJgIQAKgJAKAAQAYAEABAWQAAALgIAIQgHAIgKAAIgCgBg");
	this.shape_432.setTransform(656.5,240.2);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQAAgKAIgIQAJgIAMAAQAXAEABAWQAAAMgIAIQgIAHgKAAIgBAAg");
	this.shape_433.setTransform(630.6,240.2);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgIQAIgJAKAAQALABAIAIQAIAIgBALQgCAZgXAAIgCAAg");
	this.shape_434.setTransform(695,271.5);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#D6D4D5").s().p("AgaACQAAgLAHgIQAIgIALgBQAKAAAJAIQAIAIAAAKQAAALgIAIQgJAIgKAAQgYgDgCgWg");
	this.shape_435.setTransform(626,271.5);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAHgIQAHgHALgBQALAAAIAHQAJAIgBALQAAAXgZADIgCABQgJAAgHgIg");
	this.shape_436.setTransform(648.1,227.7);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#D6D4D5").s().p("AgBAaQgZgCAAgYQAAgLAJgIQAJgIAKACQAXACACAYQgBALgIAIQgIAHgKAAIgBgBg");
	this.shape_437.setTransform(639.3,265.3);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgWAagEQAJgBAJAIQAIAHABALQABAKgIAJQgIAIgLABIgBAAQgKAAgIgHg");
	this.shape_438.setTransform(626.2,221.4);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#D6D4D5").s().p("AgDAbQgXgEAAgXQAAgLAIgIQAJgHAKAAQAXACACAZQABAKgJAIQgJAIgLAAIgBAAg");
	this.shape_439.setTransform(648.1,252.7);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIAKAAQAXACADAYQgCAZgXABIgCABQgKAAgHgIg");
	this.shape_440.setTransform(613.4,265.3);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgIABgLQABgLAIgIQAIgIALABQAYABABAZQABALgJAJQgHAHgLAAIgBAAg");
	this.shape_441.setTransform(578.8,265.3);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#D6D4D5").s().p("AgEAbQgVgDgBgYQAAgKAIgIQAIgJALABQAYACABAYQABAMgJAHQgIAIgMAAIgCAAg");
	this.shape_442.setTransform(634.8,259);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#D6D4D5").s().p("AgRATQgIgIgBgLQAAgKAIgIQAIgIALAAQAXABADAXQAAALgIAJQgHAJgLAAIgBAAQgKAAgHgIg");
	this.shape_443.setTransform(669.3,221.4);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#D6D4D5").s().p("AgRATQgIgHAAgLQgBgLAIgIQAIgIALAAQAXACADAYQgDAZgYACIAAAAQgKAAgHgIg");
	this.shape_444.setTransform(673.9,252.7);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgMAIgHQAIgIAOAAQAJABAHAHQAGAHABALQABAKgJAJQgIAIgKAAIgBAAg");
	this.shape_445.setTransform(605,252.7);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#D6D4D5").s().p("AgRATQgJgJABgKQACgXAYgDQAaAEAAAWQAAAYgaADIgBAAQgKAAgHgIg");
	this.shape_446.setTransform(613.3,240.2);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#D6D4D5").s().p("AAAAaQgXgBgDgZQAEgaAWAAQANAAAHAIQAIAIgBALQgBAMgIAHQgHAHgKAAIgBgBg");
	this.shape_447.setTransform(673.9,227.7);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#D6D4D5").s().p("AgRAUQgHgHgBgMQgBgKAIgIQAJgJAKAAQALAAAIAIQAHAIAAALQgCAZgZABQgKAAgHgHg");
	this.shape_448.setTransform(587.3,290.4);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQgBgKAIgIQAIgIALAAQAYABADAZQgBAXgYAEIgCAAQgJAAgIgHg");
	this.shape_449.setTransform(591.4,271.6);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#D6D4D5").s().p("AgRATQgJgIABgLQAAgLAIgIQAIgIAKABQAXACADAYQgCAYgYADIgBAAQgJAAgIgIg");
	this.shape_450.setTransform(669.1,271.6);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgXAZgDQALgBAIAIQAIAIAAALQAAALgIAIQgHAHgLABQgLAAgIgIg");
	this.shape_451.setTransform(643.2,271.5);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgLAIgIQAJgIAKABQAXABADAYQAAAMgIAHQgHAIgLAAIgBAAg");
	this.shape_452.setTransform(630.6,265.2);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgMAHgGQAIgHALAAQANABAHAHQAHAHgBAMQgBAYgaACIgBAAQgJAAgIgJg");
	this.shape_453.setTransform(617.5,234);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgaQgBgKAIgIQAJgIALAAQAWABAEAZQAAAKgIAJQgIAIgLAAIAAAAg");
	this.shape_454.setTransform(617.3,271.6);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAIAIQAIAIAAAKQgBAMgIAIQgIAHgKAAIgBAAg");
	this.shape_455.setTransform(660.5,271.6);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQACgaAYAAQALAAAIAIQAIAIAAAKQgCAagYABIgBAAQgKAAgHgIg");
	this.shape_456.setTransform(677.8,246.5);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#D6D4D5").s().p("AgaAAQAAgKAJgJQAIgIAKABQAMACAHAFQAHAGAAAIQgBAggaAAQgZgBgBgag");
	this.shape_457.setTransform(677.7,284);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#D6D4D5").s().p("AgSAUQgHgIgBgMQABgXAZgDQALgBAHAIQAIAIAAALQAAAYgYADIgCAAQgKAAgIgHg");
	this.shape_458.setTransform(626,246.4);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#D6D4D5").s().p("AgaABQgBgJAJgJQAJgJAJAAQALgBAIAIQAIAIAAALQAAALgHAIQgIAIgMAAQgWAAgEgag");
	this.shape_459.setTransform(643.3,284);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#D6D4D5").s().p("AAAAbQgagBAAgZQAAgXAZgDQAKgCAJAJQAIAIAAAKQABAMgJAIQgHAHgJAAIgCAAg");
	this.shape_460.setTransform(608.8,284);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgJgIQgIgJABgKQAEgYAXgBQALAAAIAIQAHAIAAALQgBAMgIAHQgHAHgKAAIgBAAg");
	this.shape_461.setTransform(682.2,290.3);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#D6D4D5").s().p("AAAAaQgYgBgBgYQgBgLAIgHQAIgIANgBQAVAAADAZQABAKgJAJQgIAJgKAAIgBgBg");
	this.shape_462.setTransform(613.2,290.4);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#D6D4D5").s().p("AgaACQgBgJAIgKQAJgJAKAAQAJgBAJAJQAJAJAAAJQAAAMgHAIQgIAHgMAAQgXAAgDgZg");
	this.shape_463.setTransform(630.7,277.7);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#D6D4D5").s().p("AgBAaQgZgBABgZQAAgMAIgHQAJgIAKABQALABAIAJQAHAJgCAKQgFAYgUAAIgCgBg");
	this.shape_464.setTransform(622.2,252.7);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAXAAAEAaQABAKgIAJQgJAJgLAAQgKAAgIgIg");
	this.shape_465.setTransform(613.6,252.7);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgJQgHgIAAgLQABgLAIgHQAIgHAKAAQALABAIAJQAIAJgCAJQgCAZgXAAIgBAAg");
	this.shape_466.setTransform(596.3,252.7);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgLQAAgKAJgJQAIgIAKABQAaACAAAXQAAAbgaAAIgBAAQgKAAgIgHg");
	this.shape_467.setTransform(600.2,259);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgZAYgBQALgBAJAJQAJAIgBALQAAAKgIAIQgJAIgKAAQgKAAgIgIg");
	this.shape_468.setTransform(634.8,221.5);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgWQgBgLAIgJQAIgJALAAQALgBAIAIQAIAHAAALQAAAKgIAJQgHAIgLAAIgBAAg");
	this.shape_469.setTransform(643.4,221.4);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#D6D4D5").s().p("AgBAbQgLgBgIgJQgHgJABgKQAEgYAXAAQALAAAIAJQAIAIgBAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_470.setTransform(643.4,259);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgKAJgIQAIgJAKAAQAaACAAAaQgBAXgXABIgDABQgJAAgIgHg");
	this.shape_471.setTransform(656.4,265.3);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQADgYAXgCQALgBAIAJQAIAIAAAMQAAAWgaADIgBAAQgKAAgIgIg");
	this.shape_472.setTransform(604.7,240.2);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#D6D4D5").s().p("AgCAbQgXgDgBgXQAAgMAIgIQAIgIALAAQALABAHAJQAIAIAAAKQgBALgJAIQgIAIgJAAIgCgBg");
	this.shape_473.setTransform(691.2,265.3);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgJAIgJQAJgIAJAAQAZABACAYQABALgIAIQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_474.setTransform(660.6,221.5);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgXAYgDQAKgBAJAIQAIAIABALQABALgIAIQgIAIgMAAIAAAAQgKAAgIgIg");
	this.shape_475.setTransform(652,221.4);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgJAKABQAZAEABAWQAAAMgIAIQgIAHgOAAQgWgBgBgZg");
	this.shape_476.setTransform(665.1,277.7);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgKQACgYAYgCQAKgBAJAJQAIAIAAAKQAAAMgHAIQgIAHgMAAQgLAAgIgIg");
	this.shape_477.setTransform(656.5,277.7);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#D6D4D5").s().p("AgBAbQgMAAgHgJQgHgKACgOQADgVAYABQALABAIAJQAHAJgCAKQgEAYgWAAIgBAAg");
	this.shape_478.setTransform(669.2,246.4);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgaQgBgIAJgKQAJgIAKAAQAXAAADAXQABANgJAIQgIAJgLAAIAAAAg");
	this.shape_479.setTransform(617.5,221.5);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQADgXAVgDQANAAAIAIQAIAHAAALQgBAYgZADIgBAAQgKAAgIgIg");
	this.shape_480.setTransform(600.1,271.6);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#D6D4D5").s().p("AAAAbQgZgEgBgXQgBgLAIgHQAIgIALAAQAMAAAIAHQAIAIgBALQAAALgIAIQgIAIgKAAIgBAAg");
	this.shape_481.setTransform(608.7,271.6);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAMQgBAWgZACIgBAAQgKAAgHgHg");
	this.shape_482.setTransform(651.9,271.5);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgMQAEgYAWAAQAMAAAHAIQAIAHAAALQgBAYgZADIgBAAQgKAAgIgIg");
	this.shape_483.setTransform(677.8,271.6);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgJQAJgJAKABQALABAHAIQAHAIAAAKQAAAMgIAHQgHAHgKAAIgCAAg");
	this.shape_484.setTransform(639.2,277.7);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#D6D4D5").s().p("AAAAbQgZgBgBgZQAAgLAHgIQAHgIAMAAQAKAAAIAIQAJAIAAAKQAAALgIAIQgIAIgLAAIAAAAg");
	this.shape_485.setTransform(591.7,259);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#D6D4D5").s().p("AgTATQgHgJAAgKQADgYAWgCQAKAAAJAHQAJAJAAAKQABAKgJAJQgIAIgLAAIAAAAQgLAAgIgIg");
	this.shape_486.setTransform(665.2,252.7);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#D6D4D5").s().p("AgSASQgJgIAAgKQABgLAJgIQAJgIAKABQALAAAIAIQAHAJgBALQgCAYgXABQgLAAgJgJg");
	this.shape_487.setTransform(647.9,265.3);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#D6D4D5").s().p("AgaADQgCgJAKgKQAJgKAKAAQAYADACAXQABALgIAIQgIAIgLAAQgYAAgDgYg");
	this.shape_488.setTransform(587.5,277.7);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAYAAADAaQABAKgIAJQgIAIgMAAQgLAAgHgHg");
	this.shape_489.setTransform(656.7,252.7);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQABgYAZgCQALAAAIAHQAIAIAAAMQgBAXgYADIgCAAQgJAAgIgHg");
	this.shape_490.setTransform(626.1,234);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgJQgJgKABgJQAEgYAYAAQAZACAAAYQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_491.setTransform(608.8,234);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgIQgJgJABgKQADgZAXAAQAMAAAIAHQAHAIAAALQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_492.setTransform(669.3,234);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQgBgKAJgIQAJgIALAAQAYABABAXQAAALgHAIQgIAJgKABIgCAAQgIAAgJgIg");
	this.shape_493.setTransform(652,234);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgXAWgDQAOAAAJAIQAIAHAAALQgBAXgaAEIgBAAQgJAAgIgIg");
	this.shape_494.setTransform(643.5,234);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgaQgBgJAJgJQAJgIAKAAQALAAAIAIQAIAIgBALQAAAMgIAHQgHAHgLAAIgBAAg");
	this.shape_495.setTransform(690.9,290.3);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#D6D4D5").s().p("AAAAaQgZgCgBgYQAAgLAJgHQAIgIAPAAQAJABAFAHQAGAHAAALQABALgIAIQgHAIgKAAIgCgBg");
	this.shape_496.setTransform(656.4,290.4);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgKAJgIQAJgJAMAAQAXAEABAVQAAALgHAJQgIAIgKAAIgCAAg");
	this.shape_497.setTransform(639.1,290.4);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgKAIgIQAJgJAMAAQAWABACAYQABAMgIAIQgHAIgLAAIgCAAQgJAAgIgHg");
	this.shape_498.setTransform(578.6,290.3);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQACgZAYgBQALgBAIAJQAIAIAAALQAAAKgIAIQgIAIgLAAQgKAAgIgIg");
	this.shape_499.setTransform(570.1,290.4);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgLAIgIQAIgHAKAAQALABAIAJQAIAJgBAJQgCAYgYABQgLAAgIgIg");
	this.shape_500.setTransform(651.9,246.4);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgKAJgIQAJgIAMAAQAWADABAXQAAAMgIAIQgHAHgKAAIgCAAg");
	this.shape_501.setTransform(643.2,246.4);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#D6D4D5").s().p("AgBAbQgZgCAAgYQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAKQgBAMgIAHQgGAHgLAAIgCAAg");
	this.shape_502.setTransform(634.7,246.5);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQAAgLAIgIQAIgIALABQAYABACAUQAAANgIAKQgHAJgLAAIgBAAQgJAAgIgIg");
	this.shape_503.setTransform(660.6,233.9);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#D6D4D5").s().p("AgaAAQAAgKAIgIQAIgJAKABQAMAAAIAIQAHAIgBALQAAAXgaADQgYgDgCgYg");
	this.shape_504.setTransform(600.1,246.5);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgLQACgWAYgDQALAAAJAIQAIAJgBAKQAAALgJAIQgIAHgLAAQgLgBgHgHg");
	this.shape_505.setTransform(617.4,246.5);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgJAKABQAZADABAXQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_506.setTransform(608.7,246.5);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIALAAQAZACAAAYQAAAXgYAEQgLAAgJgIg");
	this.shape_507.setTransform(665.2,240.2);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgIAJQgIAIgLAAQgKAAgJgIg");
	this.shape_508.setTransform(622,240.2);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgLAHgIQAHgHAMAAQAZABACAYQAAALgIAJQgIAIgJAAIgCAAg");
	this.shape_509.setTransform(634.8,234);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#D6D4D5").s().p("AAAAbQgMgBgHgGQgHgHAAgMQAAgYAZgCQAKgBAJAIQAIAIABAKQAAALgIAIQgIAIgKAAIgBAAg");
	this.shape_510.setTransform(579,252.7);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#D6D4D5").s().p("AgaABQgBgKAIgJQAIgIALgBQALABAIAHQAIAJAAAKQAAALgIAJQgIAHgLABQgXgBgDgag");
	this.shape_511.setTransform(630.8,252.7);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgLAJgHQAIgIAKAAQAaACAAAYQABAMgIAHQgIAIgLAAQgKAAgJgIg");
	this.shape_512.setTransform(673.6,290.3);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgYAZgCQAYAAADAZQABAKgIAJQgIAIgLABIgBAAQgKAAgIgIg");
	this.shape_513.setTransform(665,290.3);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgKQgBgLAIgIQAJgJAKAAQAZACACAYQABAJgJAJQgJAKgKAAIAAABQgJAAgIgJg");
	this.shape_514.setTransform(630.8,227.7);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#D6D4D5").s().p("AgTASQgIgJABgKQADgaAXABQAMAAAIAIQAIAJgBAKQgDAYgYACIgCAAQgJAAgIgJg");
	this.shape_515.setTransform(665.3,227.7);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQACgXAYgDQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgKAAQgLAAgIgIg");
	this.shape_516.setTransform(665.1,265.2);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#D6D4D5").s().p("AgRATQgJgJAAgKQAAgKAJgIQAJgJAJABQAMAAAHAIQAHAJAAANQgCAVgYACIgBAAQgJAAgIgIg");
	this.shape_517.setTransform(604.7,265.3);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgJQgHgJAAgKQABgLAIgIQAKgIAJACQAYADABAYQAAALgIAIQgIAHgLAAIAAAAg");
	this.shape_518.setTransform(596.1,265.3);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgIQAIgJAKAAQALAAAIAIQAIAIAAAKQAAAMgJAHQgJAIgNAAQgUgCgCgYg");
	this.shape_519.setTransform(677.9,258.9);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#D6D4D5").s().p("AgSASQgJgIACgKQADgaAXAAQAMAAAHAIQAHAJAAANQgEAXgXAAQgKAAgIgJg");
	this.shape_520.setTransform(660.6,258.9);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgIAKAAQAZACABAYQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_521.setTransform(651.9,259);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgMQAEgXAVgCQAKAAAJAHQAIAIABALQABALgIAIQgHAIgMAAQgKAAgIgIg");
	this.shape_522.setTransform(617.5,259);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#D6D4D5").s().p("AgRATQgJgIABgLQABgZAYgBQAKgBAIAIQAIAIABANQgCAXgXACIgCAAQgJAAgIgIg");
	this.shape_523.setTransform(608.8,259);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgLQAAgKAIgIQAJgJAKAAQALAAAIAIQAIAIgBALQAAAZgaABIgBAAQgKAAgIgHg");
	this.shape_524.setTransform(695,284);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#D6D4D5").s().p("AAAAbQgMgBgHgIQgIgJABgKQACgYAYgBQALgBAIAJQAIAIAAALQAAALgJAIQgHAHgKAAIgBAAg");
	this.shape_525.setTransform(617.4,284.1);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQABgYAZgCQAKgBAJAIQAIAIAAALQAAALgHAIQgIAIgMAAQgKAAgIgIg");
	this.shape_526.setTransform(600.1,284.1);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgJAJgJQAJgJAJABQAZACABAYQABALgIAIQgHAIgMAAQgLAAgIgHg");
	this.shape_527.setTransform(682.4,277.7);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQAAgMAIgHQAHgIAMABQAXAAADAaQABAKgJAJQgJAJgKAAQgLgBgIgIg");
	this.shape_528.setTransform(656.7,227.7);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#D6D4D5").s().p("AgaACQgBgLAHgIQAHgIAMgBQALgBAIAIQAIAHABAMQABAJgJAJQgJAJgMAAQgXgDgBgWg");
	this.shape_529.setTransform(613.6,227.7);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#D6D4D5").s().p("AAAAcQgLgBgIgJQgHgJAAgKQABgMAIgHQAIgHALABQAWACADAXQAAAMgIAJQgJAIgKAAIAAAAg");
	this.shape_530.setTransform(639.4,227.7);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#D6D4D5").s().p("AgTATQgHgIAAgLQAAgMAIgHQAJgIAKABQAZABABAZQABALgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_531.setTransform(621.9,290.4);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#D6D4D5").s().p("AAAAbQgYgCgCgZQgBgKAJgIQAIgIAKAAQAMAAAHAIQAIAIAAAKQAAAMgIAIQgIAHgJAAIgCAAg");
	this.shape_532.setTransform(604.6,290.4);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgJAIgJQAIgJALAAQALgBAIAJQAJAIAAAKQAAALgJAIQgIAIgJAAIgCAAg");
	this.shape_533.setTransform(695.2,259);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#D6D4D5").s().p("AgEAbQgVgEgBgXQgBgKAJgIQAIgIAKAAQAMAAAHAIQAJAJgBAKQAAALgJAHQgJAIgLAAIgCAAg");
	this.shape_534.setTransform(583,259);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgJABgKQAAgMAJgHQAJgIAKABQAYADABAXQABALgJAJQgIAHgKAAIgBAAg");
	this.shape_535.setTransform(587.6,252.7);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#D6D4D5").s().p("AgTATQgHgHAAgMQABgXAZgDQAKgBAJAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIg");
	this.shape_536.setTransform(651.8,284);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#D6D4D5").s().p("AgSAUQgJgJABgLQABgYAZgCQAJgCAJAJQAJAIAAALQABALgIAIQgHAIgNAAIAAAAQgLAAgHgHg");
	this.shape_537.setTransform(613.4,277.7);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#D6D4D5").s().p("AAAAbQgXgCgDgYQgBgKAIgIQAIgIALgBQAMAAAIAHQAHAHAAAMQAAALgIAIQgHAIgKAAIgCAAg");
	this.shape_538.setTransform(686.4,271.6);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQAAgLAIgIQAIgIAKABQAMAAAIAIQAHAIAAAKQAAAMgIAIQgIAHgLAAQgKAAgIgIg");
	this.shape_539.setTransform(647.8,290.3);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgIgHQgIgJABgLQACgXAYgCQALgBAJAJQAIAIgBALQAAALgIAIQgIAHgLAAIAAAAg");
	this.shape_540.setTransform(574.3,259);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgKAIgJQAIgIAKAAQAMAAAIAIQAIAIgBALQgBAZgZABIgBAAQgKAAgHgHg");
	this.shape_541.setTransform(622,265.3);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#D6D4D5").s().p("AgaACQgBgKAIgJQAIgJALAAQAKgBAIAIQAJAIAAALQABALgJAIQgIAIgMABQgWgCgDgYg");
	this.shape_542.setTransform(673.8,265.3);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgMAJgHQAIgHALABQAaADgCAZQgCAZgZAAQgKAAgIgJg");
	this.shape_543.setTransform(582.8,271.6);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgIQgIgIABgLQAAgLAIgIQAJgIAKABQAZACABAYQABALgJAIQgIAIgLAAIAAAAg");
	this.shape_544.setTransform(682.6,252.7);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgJAIQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_545.setTransform(660.5,246.5);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgHgJQgJgIABgKQABgLAJgIQAJgJAJACQAZADAAAXQAAAMgHAIQgIAHgLAAIgBAAg");
	this.shape_546.setTransform(647.9,240.2);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#D6D4D5").s().p("AABAbQgZgBgCgYQgBgKAIgJQAHgIAMgBQAKgBAIAIQAJAHAAAMQABAKgIAJQgIAIgKAAIgBAAg");
	this.shape_547.setTransform(673.8,240.2);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgZQgBgKAIgIQAIgJALAAQALAAAIAIQAJAIgBAKQAAAMgIAIQgHAHgKAAIgCAAg");
	this.shape_548.setTransform(626.1,259);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgKAIgIQAIgJAKAAQALAAAJAJQAIAJgBAKQgDAagXAAIgBABQgLAAgHgIg");
	this.shape_549.setTransform(639.4,252.7);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#D6D4D5").s().p("AgBAbQgYgDgBgYQAAgKAIgJQAJgIAKABQALAAAIAJQAIAIgBAKQAAAMgJAHQgHAHgKAAIgCAAg");
	this.shape_550.setTransform(669.3,259);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgLAHgIQAIgIALAAQALAAAJAIQAHAHAAALQAAAMgHAIQgIAHgKAAIgCAAg");
	this.shape_551.setTransform(596,290.3);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#D6D4D5").s().p("AAAAbQgMAAgHgIQgIgJABgKQAAgMAJgHQAIgIALABQAYADACAYQAAALgIAIQgJAHgLAAIAAAAg");
	this.shape_552.setTransform(669.1,284);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQABgXAYgDQAMAAAIAGQAIAHAAAMQABALgIAIQgIAJgLAAIgBAAQgJAAgIgIg");
	this.shape_553.setTransform(634.6,271.6);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQAAgLAIgIQAJgIAKABQAZABABAZQABAKgIAJQgIAIgMAAQgKAAgIgIg");
	this.shape_554.setTransform(626,284);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#D6D4D5").s().p("AAAAbQgZgDAAgYQAAgLAJgIQAIgJAKACQAZAFgBAaQAAAJgIAHQgHAGgLAAIAAAAg");
	this.shape_555.setTransform(634.6,208.5);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQABgWAZgFQAKgBAIAJQAIAIABALQgCAYgXACIgCAAQgKAAgHgHg");
	this.shape_556.setTransform(647.9,202.2);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#D6D4D5").s().p("AAAAbQgLgBgHgIQgIgJAAgKQADgZAXAAQAZAAABAaQABAKgJAJQgIAIgKAAIAAAAg");
	this.shape_557.setTransform(622.2,152.2);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#D6D4D5").s().p("AgTASQgIgJACgKQACgXAXgCQAMABAIAIQAIAIgBALQgCAXgZABIgCABQgKAAgHgJg");
	this.shape_558.setTransform(639.3,164.7);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#D6D4D5").s().p("AgRAUQgIgHgBgMQAAgJAJgKQAIgJAKABQAYADACAYQgCAZgXAAIgCABQgKAAgHgHg");
	this.shape_559.setTransform(622,202.2);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#D6D4D5").s().p("AgBAaQgYgCgBgYQAAgLAJgHQAIgIALAAQAXACACAWQgBAMgIAJQgHAIgKAAIgCgBg");
	this.shape_560.setTransform(630.4,214.8);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#D6D4D5").s().p("AgaABQAAgKAIgJQAJgIAJAAQAZADABAXQABALgJAIQgIAIgMAAQgXgDgBgXg");
	this.shape_561.setTransform(660.5,208.5);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#D6D4D5").s().p("AAAAaQgWAAgEgaQgBgJAJgIQAKgJAKAAQAYAEABAWQAAALgIAIQgHAIgKAAIgCgBg");
	this.shape_562.setTransform(656.5,164.7);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQAAgKAIgIQAJgIAMAAQAXAEABAWQAAAMgIAIQgIAHgKAAIgBAAg");
	this.shape_563.setTransform(630.6,164.7);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#D6D4D5").s().p("AgaABQAAgKAHgIQAIgIALgBQAKAAAJAIQAIAIAAAKQAAALgIAIQgJAIgKAAQgYgDgCgXg");
	this.shape_564.setTransform(626,196);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#D6D4D5").s().p("AgBAbQgZgEAAgXQAAgLAJgIQAJgIAKACQAXACACAYQgBALgIAIQgIAHgKAAIgBAAg");
	this.shape_565.setTransform(639.3,189.8);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#D6D4D5").s().p("AgDAbQgXgEAAgXQAAgLAIgIQAJgHAKAAQAXACACAZQABAKgJAIQgJAIgLAAIgBAAg");
	this.shape_566.setTransform(648.1,177.2);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIAKAAQAXACADAYQgCAZgXABIgCABQgKAAgHgIg");
	this.shape_567.setTransform(613.4,189.8);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#D6D4D5").s().p("AgEAbQgVgDgBgYQAAgLAIgHQAIgJALABQAYACABAYQABAMgJAHQgIAIgMAAIgCAAg");
	this.shape_568.setTransform(634.8,183.5);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#D6D4D5").s().p("AgRATQgJgJABgKQACgXAYgDQAaAEAAAWQAAAYgaADIgBAAQgKAAgHgIg");
	this.shape_569.setTransform(613.3,164.7);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgIgJQgIgIABgKQACgaAYAAQALAAAIAJQAJAIgBAKQgBALgIAHQgIAIgJAAIgBAAg");
	this.shape_570.setTransform(605,152.2);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgXAZgDQALgBAIAIQAIAIAAALQAAALgIAIQgHAHgLABQgLAAgIgIg");
	this.shape_571.setTransform(643.2,196);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#D6D4D5").s().p("AAAAbQgZgCgBgYQAAgLAIgIQAJgIAKABQAXABADAYQAAALgIAIQgIAIgKAAIgBAAg");
	this.shape_572.setTransform(630.6,189.7);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#D6D4D5").s().p("AgSASQgIgJAAgKQABgMAHgGQAIgHALAAQANABAHAHQAHAHgBAMQgBAYgaACIgBAAQgJAAgIgJg");
	this.shape_573.setTransform(617.5,158.5);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgaQgBgKAIgIQAJgIALAAQAWABAEAZQAAAKgIAJQgIAIgLAAIAAAAg");
	this.shape_574.setTransform(617.3,196.1);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#D6D4D5").s().p("AAAAbQgZgDgBgYQgBgKAJgIQAIgIAKAAQAMAAAIAIQAIAIAAAKQgBAMgIAIQgIAHgKAAIgBAAg");
	this.shape_575.setTransform(660.5,196.1);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#D6D4D5").s().p("AgSAUQgHgIgBgMQABgYAZgCQALgBAHAIQAIAIAAALQAAAYgYADIgCAAQgKAAgIgHg");
	this.shape_576.setTransform(626,170.9);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#D6D4D5").s().p("AAAAbQgWAAgEgZQgBgJAJgKQAJgIAJgBQALAAAIAHQAIAIAAALQAAALgHAJQgHAHgLAAIgCAAg");
	this.shape_577.setTransform(643.3,208.5);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#D6D4D5").s().p("AgaACQgBgKAIgJQAJgJAKAAQAJgBAJAJQAJAJAAAJQAAAMgHAIQgIAHgMAAQgXAAgDgZg");
	this.shape_578.setTransform(630.7,202.2);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#D6D4D5").s().p("AgBAaQgZgBABgZQAAgMAIgHQAJgIAKABQALABAIAJQAHAJgCAKQgFAYgUAAIgCgBg");
	this.shape_579.setTransform(622.2,177.2);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAXAAAEAaQABAKgIAJQgJAIgLABQgKAAgIgIg");
	this.shape_580.setTransform(613.6,177.2);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#D6D4D5").s().p("AgBAbQgLgBgIgJQgHgJABgKQAEgYAXAAQALAAAIAJQAIAIgBAKQAAALgJAIQgIAHgJAAIgCAAg");
	this.shape_581.setTransform(643.4,183.5);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#D6D4D5").s().p("AgRAUQgIgIgBgLQAAgKAJgIQAIgJAKAAQAaACAAAaQgBAXgXABIgDABQgJAAgIgHg");
	this.shape_582.setTransform(656.4,189.8);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQADgYAXgCQALgBAIAJQAIAIAAAMQAAAWgaADIgBAAQgKAAgIgIg");
	this.shape_583.setTransform(604.7,164.7);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgKQACgYAYgCQAKgBAJAJQAIAIAAAKQAAAMgHAIQgIAHgMAAQgLAAgIgIg");
	this.shape_584.setTransform(656.5,202.2);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#D6D4D5").s().p("AgBAbQgMAAgHgJQgHgJACgPQADgVAYABQALAAAIAKQAHAJgCAKQgEAYgWAAIgBAAg");
	this.shape_585.setTransform(669.2,170.9);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAMQgBAWgZACIgBAAQgKAAgHgHg");
	this.shape_586.setTransform(651.9,196);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#D6D4D5").s().p("AAAAbQgXAAgDgaQAAgKAJgJQAJgJAKABQALAAAHAJQAHAIAAAKQAAAMgIAHQgHAHgKAAIgCAAg");
	this.shape_587.setTransform(639.2,202.2);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#D6D4D5").s().p("AgTATQgHgIAAgLQADgZAWgBQAKAAAJAHQAJAJAAAKQABAKgJAJQgIAIgLAAIAAAAQgLAAgIgIg");
	this.shape_588.setTransform(665.2,177.2);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#D6D4D5").s().p("AgSASQgJgIAAgKQABgLAJgIQAJgIAKABQALAAAIAIQAHAJgBALQgCAYgXABQgLAAgJgJg");
	this.shape_589.setTransform(647.9,189.8);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgLAIgIQAIgIAKABQAYAAADAaQABAKgIAJQgIAIgMAAQgLAAgHgHg");
	this.shape_590.setTransform(656.7,177.2);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#D6D4D5").s().p("AgRAUQgJgJAAgLQABgYAZgCQALAAAIAHQAIAIAAAMQgBAXgYADIgCAAQgJAAgIgHg");
	this.shape_591.setTransform(626.1,158.5);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgIgJQgJgKABgJQAEgYAYAAQAZACAAAYQAAAKgIAJQgIAIgKAAIgBAAg");
	this.shape_592.setTransform(608.8,158.5);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#D6D4D5").s().p("AAAAaQgZgCgBgYQAAgLAJgHQAIgIAPAAQAJABAFAHQAGAHAAALQABALgIAIQgHAIgKAAIgCgBg");
	this.shape_593.setTransform(656.4,214.9);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#D6D4D5").s().p("AAAAbQgXgBgDgZQgBgKAJgIQAJgJAMAAQAXAEABAVQAAALgHAJQgIAIgKAAIgCAAg");
	this.shape_594.setTransform(639.1,214.9);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQABgLAIgIQAIgHAKAAQALABAIAJQAIAJgBAJQgCAYgYABQgLAAgIgIg");
	this.shape_595.setTransform(651.9,170.9);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgKAJgIQAJgIAMAAQAWADABAXQAAAMgIAIQgHAHgKAAIgCAAg");
	this.shape_596.setTransform(643.2,170.9);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#D6D4D5").s().p("AgBAbQgZgCAAgYQAAgLAIgIQAIgIAKAAQALAAAIAJQAIAIAAAKQgBAMgIAHQgGAHgLAAIgCAAg");
	this.shape_597.setTransform(634.7,171);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#D6D4D5").s().p("AgTATQgIgJABgLQACgWAYgDQALAAAJAIQAIAIgBALQAAALgJAIQgIAHgLAAQgLgBgHgHg");
	this.shape_598.setTransform(617.4,171);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQAAgKAJgIQAIgIALAAQAZACAAAYQAAAXgYAEIgBAAQgKAAgJgIg");
	this.shape_599.setTransform(665.2,164.7);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#D6D4D5").s().p("AgSATQgJgJABgKQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgIAJQgIAIgLAAQgKAAgJgIg");
	this.shape_600.setTransform(622,164.7);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#D6D4D5").s().p("AAAAbQgYgDgCgYQAAgLAHgIQAHgHAMAAQAZABACAYQAAALgIAJQgIAIgJAAIgCAAg");
	this.shape_601.setTransform(634.8,158.5);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#D6D4D5").s().p("AgaABQgBgKAIgIQAIgJALAAQALAAAIAHQAIAJAAAKQAAALgIAJQgIAHgLABQgXgBgDgag");
	this.shape_602.setTransform(630.8,177.2);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#D6D4D5").s().p("AgSASQgJgIACgKQADgaAXAAQAMAAAHAIQAHAJAAANQgEAXgXAAQgKAAgIgJg");
	this.shape_603.setTransform(660.6,183.4);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#D6D4D5").s().p("AgSATQgIgIAAgLQAAgKAJgIQAIgIAKAAQAZACABAYQABALgIAIQgIAIgMAAQgKAAgIgIg");
	this.shape_604.setTransform(651.9,183.5);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgMQAEgXAVgCQAKAAAJAHQAIAIABALQABALgIAIQgHAIgMAAQgKAAgIgIg");
	this.shape_605.setTransform(617.5,183.5);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#D6D4D5").s().p("AgRAUQgJgIABgLQABgZAYgCQALAAAHAHQAIAJABAMQgCAXgXACIgCAAQgJAAgIgHg");
	this.shape_606.setTransform(608.8,183.4);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#D6D4D5").s().p("AgaACQgBgLAHgIQAHgIAMgBQAKgBAJAIQAIAHABALQABAKgJAJQgJAJgMAAQgXgDgBgWg");
	this.shape_607.setTransform(613.6,152.2);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#D6D4D5").s().p("AAAAbQgKgBgJgJQgIgKABgIQAEgZAWAAQAMAAAIAHQAHAIAAALQAAALgJAIQgHAIgJAAIgCAAg");
	this.shape_608.setTransform(600.2,158.5);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#D6D4D5").s().p("AgTATQgHgIAAgLQAAgMAIgHQAJgIAKABQAZABABAZQABALgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_609.setTransform(621.9,214.9);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#D6D4D5").s().p("AgTATQgHgHAAgMQABgXAZgDQAKgBAJAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIg");
	this.shape_610.setTransform(651.8,208.5);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#D6D4D5").s().p("AgSATQgIgJAAgKQAAgLAIgIQAIgIAKABQAMAAAIAIQAHAIAAAKQAAAMgIAIQgIAHgLAAQgKAAgIgIg");
	this.shape_611.setTransform(647.8,214.8);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#D6D4D5").s().p("AgRAUQgJgIAAgLQAAgKAIgJQAIgIAKAAQAMAAAIAIQAIAIgBALQgBAZgZABIgBAAQgKAAgHgHg");
	this.shape_612.setTransform(622,189.8);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#D6D4D5").s().p("AgTATQgIgIABgLQABgYAZgCQAKgBAIAIQAJAIAAALQABAKgJAIQgIAJgLAAIgBAAQgKAAgIgIg");
	this.shape_613.setTransform(660.5,171);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#D6D4D5").s().p("AAAAbQgLAAgHgJQgJgIABgKQABgLAJgIQAJgJAJACQAZADAAAXQAAAMgHAIQgIAHgLAAIgBAAg");
	this.shape_614.setTransform(647.9,164.7);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#D6D4D5").s().p("AAAAbQgYgBgCgZQgBgKAIgIQAIgJALAAQALAAAIAIQAJAIgBAKQAAAMgIAIQgHAHgKAAIgCAAg");
	this.shape_615.setTransform(626.1,183.5);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#D6D4D5").s().p("AgSAUQgIgIAAgMQAAgKAIgIQAIgJAKAAQALAAAJAJQAIAJgBAKQgDAagXAAIgBABQgLAAgHgIg");
	this.shape_616.setTransform(639.4,177.2);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#D6D4D5").s().p("AgRATQgJgIAAgLQABgXAYgDQAMAAAIAGQAIAHAAAMQABALgIAIQgIAJgLAAIgBAAQgJAAgIgIg");
	this.shape_617.setTransform(634.6,196.1);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#D6D4D5").s().p("AgSATQgJgIABgLQAAgLAIgIQAJgIAKABQAZABABAZQABAKgIAJQgIAIgMAAQgKAAgIgIg");
	this.shape_618.setTransform(626,208.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1094));

	// Layer 1 copy 2
	this.instance = new lib.cloud3();
	this.instance.parent = this;
	this.instance.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(315));

	// Layer 1
	this.instance_1 = new lib.cloud3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(315));

	// Layer 1 copy
	this.instance_2 = new lib.cloud1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).wait(91));

	// Layer 1 copy 3
	this.instance_3 = new lib.cloud1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(300));

	// Layer 1
	this.instance_4 = new lib.cloud1("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(300));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,372.2);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 36,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;