(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween143 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,0,1).p("AAAhWIAAjRAAAEoIAAk4");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween142 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,0,1).p("AAAhWIAAjRAAAEoIAAk4");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween139 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,0,1).p("AAAB6IAAjz");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-13.7,3,27.4);


(lib.Tween138 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,0,1).p("AAAB6IAAjz");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-13.7,3,27.4);


(lib.Tween137 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,0,1).p("AAADnIAAnN");
	this.shape.setTransform(0,6.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,0,1).p("AAAAjIAAhF");
	this.shape_1.setTransform(0,-26.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween136 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(3,0,1).p("AAADnIAAnN");
	this.shape.setTransform(0,6.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(3,0,1).p("AAAAjIAAhF");
	this.shape_1.setTransform(0,-26.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-31.1,3,62.3);


(lib.Tween135 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjqBcQAqgZAxgVQCahDCdABQgEgIgKgLQAYgHAXgFQAlAcAeAlQgRgEgaABQg0AAgrAVIBPAfIg0AaIAXgWQg1gFhTADQilAGiSAqQAMgIAVgNgABUhaIAdgGQAcAJAZAOQgPADgWAIQgWgRgXgLgAgdhtIAegDQAogBAnAIIgXAFQgogNguAEg");
	this.shape.setTransform(0,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DA1E48").s().p("AlNFOQiKiKAAjEQAAjDCKiKQCLiKDCAAQDEAACKCKQCKCKAADDQAADDiKCLQiKCKjEAAQjCAAiLiKg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.2,-47.2,94.5,94.5);


(lib.Tween134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjqBcQAqgZAxgVQCahDCdABQgEgIgKgLQAYgHAXgFQAlAcAeAlQgRgEgaABQg0AAgrAVIBPAfIg0AaIAXgWQg1gFhTADQilAGiSAqQAMgIAVgNgABUhaIAdgGQAcAJAZAOQgPADgWAIQgWgRgXgLgAgdhtIAegDQAogBAnAIIgXAFQgogNguAEg");
	this.shape.setTransform(0,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DA1E48").s().p("AlNFOQiKiKAAjEQAAjDCKiKQCLiKDCAAQDEAACKCKQCKCKAADDQAADDiKCLQiKCKjEAAQjCAAiLiKg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.2,-47.2,94.5,94.5);


(lib.Tween133 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AA4AAIhwAA");
	this.shape.setTransform(-107.6,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AwMAAMAgZAAA");
	this.shape_1.setTransform(9.6,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.7,-1.5,229.6,3);


(lib.Tween132 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,0,1).p("AA4AAIhwAA");
	this.shape.setTransform(-107.6,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,0,1).p("AwMAAMAgZAAA");
	this.shape_1.setTransform(9.6,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.7,-1.5,229.6,3);


(lib.Tween121 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,0,1).p("AAAAWIAAgr");
	this.shape.setTransform(0,14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,0,1).p("AAAASIAAgj");
	this.shape_1.setTransform(0,-16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,0,1).p("AhDBEQAAAcAUAUQAUAUAbAAQAcAAAUgUQAUgUAAgcQAAgegTgTQgUgTgdAAQgcAAgTgSQgUgTAAgeQAAgcAUgUQAUgUAbAAQAcAAAUAUQAUAUAAAc");
	this.shape_2.setTransform(0,-0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("AjWDWQhYhYAAh+QAAh8BYhZQBahZB8AAQB+AABZBZQBYBZAAB8QAAB+hYBYQhZBZh+AAQh8AAhahZg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.3,-30.3,60.6,60.7);


(lib.Tween120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(3,0,1).p("AAAAWIAAgr");
	this.shape.setTransform(0,14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(3,0,1).p("AAAASIAAgj");
	this.shape_1.setTransform(0,-16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(3,0,1).p("AhDBEQAAAcAUAUQAUAUAbAAQAcAAAUgUQAUgUAAgcQAAgegTgTQgUgTgdAAQgcAAgTgSQgUgTAAgeQAAgcAUgUQAUgUAbAAQAcAAAUAUQAUAUAAAc");
	this.shape_2.setTransform(0,-0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D2D41").s().p("AjWDWQhYhYAAh+QAAh8BYhZQBahZB8AAQB+AABZBZQBYBZAAB8QAAB+hYBYQhZBZh+AAQh8AAhahZg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.3,-30.3,60.6,60.7);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.JUN2015 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 110
	this.instance = new lib.Tween120("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(713.8,-44.9);
	this.instance._off = true;

	this.instance_1 = new lib.Tween121("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(713.8,245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},44).to({state:[{t:this.instance_1}]},19).to({state:[]},1040).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44).to({_off:false},0).to({_off:true,y:245},19,cjs.Ease.elasticInOut).wait(1047));

	// Layer 2
	this.instance_2 = new lib.Tween136("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(686.8,-31.8);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween137("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(686.8,213.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},54).to({state:[{t:this.instance_3}]},11).to({state:[]},1038).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(54).to({_off:false},0).to({_off:true,y:213.2},11,cjs.Ease.elasticInOut).wait(1045));

	// Layer 3
	this.instance_4 = new lib.Tween138("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(710.3,-11.1);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween139("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(710.3,208.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},57).to({state:[{t:this.instance_5}]},11).to({state:[]},1039).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(57).to({_off:false},0).to({_off:true,y:208.9},11,cjs.Ease.elasticInOut).wait(1042));

	// Layer 129
	this.instance_6 = new lib.Tween142("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(739.2,-28);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween143("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(739.2,229);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},61).to({state:[{t:this.instance_7}]},10).wait(1039));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(61).to({_off:false},0).to({_off:true,y:229},10,cjs.Ease.elasticInOut).wait(1039));

	// Layer 125
	this.instance_8 = new lib.Tween132("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(929.5,416.4);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween133("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(700,416.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},5).to({state:[{t:this.instance_9}]},18).to({state:[]},1080).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(5).to({_off:false},0).to({_off:true,x:700},18,cjs.Ease.elasticInOut).wait(1087));

	// Layer 118
	this.instance_10 = new lib.Tween134("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(662.4,657.8);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween135("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(662.4,336.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},9).to({state:[{t:this.instance_11}]},34).to({state:[]},1060).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(9).to({_off:false},0).to({_off:true,y:336.7},34,cjs.Ease.elasticInOut).wait(1067));

	// Layer 123
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D71E48").ss(2.5).p("AASAHQgVgHgYgF");
	this.shape.setTransform(710.9,263.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D71E48").ss(2.5).p("ABRAtQhMhChfgU");
	this.shape_1.setTransform(717.1,266.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D71E48").ss(2.5).p("AB7BjQgZgugogoQhRhThtgW");
	this.shape_2.setTransform(721.4,271.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D71E48").ss(2.5).p("ACPCcQgVhwhUhTQhRhUhtgW");
	this.shape_3.setTransform(723.3,277.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D71E48").ss(2.5).p("ACTC/QgEibhshtQhShThtgW");
	this.shape_4.setTransform(723.7,280.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D71E48").ss(2.5).p("ACTEYIAAinQAAihhwhxQhShThtgX");
	this.shape_5.setTransform(723.7,289.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D71E48").ss(2.5).p("ACTFdIAAkyQAAighwhxQhShThtgX");
	this.shape_6.setTransform(723.7,296.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D71E48").ss(2.5).p("ACTHDIAAn9QAAihhwhxQhShThtgX");
	this.shape_7.setTransform(723.7,306.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#D71E48").ss(2.5).p("ACTIcIAAquQAAiihwhxQhShThtgW");
	this.shape_8.setTransform(723.7,315.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D71E48").ss(2.5).p("ACOJRQAFgfAAgiIAArkQAAiihwhxQhShThtgW");
	this.shape_9.setTransform(723.7,321.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#D71E48").ss(2.5).p("ABzJ/QAghIAAhVIAArkQAAiihwhxQhShThtgW");
	this.shape_10.setTransform(723.7,326.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D71E48").ss(2.5).p("AipLwQB9gQBbhdQBwhxAAihIAArkQAAiihwhxQhRhThtgW");
	this.shape_11.setTransform(722.4,337.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#D71E48").ss(2.5).p("AjsLyIBLAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThsgW");
	this.shape_12.setTransform(716,338);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D71E48").ss(2.5).p("An5LyIJlAAQCiAABwhxQBwhxAAihIAArkQAAiihwhxQhThThtgW");
	this.shape_13.setTransform(689,338);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#D71E48").ss(2.5).p("Ar1hfIAAHOQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgW");
	this.shape_14.setTransform(662.6,338);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D71E48").ss(2.5).p("Ar1j9IAAJsQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgW");
	this.shape_15.setTransform(662.6,338);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#D71E48").ss(2.5).p("Ar1lgIAALPQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgW");
	this.shape_16.setTransform(662.6,338);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#D71E48").ss(2.5).p("AotrJQguAagoAnQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgW");
	this.shape_17.setTransform(662.6,338);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#D71E48").ss(2.5).p("AndqeQhdAahJBIQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAnHtKIABAXQAAACAAABQABAPAEANAoSsgIBOA4Anep2IhKAr");
	this.shape_18.setTransform(662.6,330.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#D71E48").ss(2.5).p("Al/qtQgDAAgDAAQiTAIhrBpQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAlhqtIgZAAQgDAAgCAAIipBiAoSsgICbBuIgIAFAnHtKIABAXQAAACAAABQADAcALAYQAaA3A9AQ");
	this.shape_19.setTransform(662.6,330.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#D71E48").ss(2.5).p("Al/qtQgDAAgDAAQiTAIhrBpQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAktqtICYAAAnHtKIABAXQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAIipBiAoSsgICbBuIgIAF");
	this.shape_20.setTransform(662.6,330.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#D71E48").ss(2.5).p("Al/qtQgDAAgDAAQiTAIhrBpQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAnHtKIABAXQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAAoSsgICbBuIgIAFIipBiAktqtIGPAA");
	this.shape_21.setTransform(662.6,330.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#D71E48").ss(2.5).p("Al/pjQgDAAgDAAQiTAIhrBpQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAl7uHQgRAKgOAOQgtAuAAA/IABAZQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAAoSrWICbBuIgIAFIipBiAktpjIGPAA");
	this.shape_22.setTransform(662.6,323);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#D71E48").ss(2.5).p("Al/pYQgDAAgDAAQiTAHhrBqQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAiBuSIitAAQg/AAgtAuQgtAuAAA/IABAZQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAAoSrLICbBuIgIAFIipBiAktpYIGPAA");
	this.shape_23.setTransform(662.6,321.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#D71E48").ss(2.5).p("Al/pYQgDAAgDAAQiTAHhrBqQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWABeuSImMAAQg/AAgtAuQgtAuAAA/IABAZQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAAoSrLICbBuIgIAFIipBiAktpYIGPAA");
	this.shape_24.setTransform(662.6,321.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#D71E48").ss(2.5).p("AFKuQQgLgCgLAAIpiAAQg/AAgtAuQgtAuAAA/IABAZQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAQgDAAgDAAQiTAHhrBqQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAoSrLICbBuIgIAFIipBiAktpYIGPAA");
	this.shape_25.setTransform(662.6,321.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#D71E48").ss(2.5).p("AHNr5QgBg+gsgtQgtgug/AAIpiAAQg/AAgtAuQgtAuAAA/IABAZQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAQgDAAgDAAQiTAHhrBqQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhShThtgWAoSrLICbBuIgIAFIipBiAktpYIGPAA");
	this.shape_26.setTransform(662.6,321.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#D71E48").ss(2.5).p("Al/pYQgDAAgDAAQiTAHhrBqQhyByAAChIAALkQAAChByBxQByBxCiAAILkAAQChAABwhxQBwhxAAihIAArkQAAiihwhxQhwhxihAAIhLAAICjifQAAg/gtguQgtgug/AAIpiAAQg/AAgtAuQgtAuAAA/IABAZQAAACAAABQADAcALAYQAkBLBnAEIhNAAQgDAAgCAAgAoSrLICbBuIgIAFIipBiAktpYIGPAA");
	this.shape_27.setTransform(662.6,321.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[]},1076).wait(7));

	// Layer 1 copy 2
	this.instance_12 = new lib.cloud3();
	this.instance_12.parent = this;
	this.instance_12.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(331));

	// Layer 1
	this.instance_13 = new lib.cloud3();
	this.instance_13.parent = this;
	this.instance_13.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(331));

	// Layer 1 copy
	this.instance_14 = new lib.cloud1("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).to({_off:true},91).wait(16));

	// Layer 1 copy 3
	this.instance_15 = new lib.cloud1("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(316));

	// Layer 1
	this.instance_16 = new lib.cloud1("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(316));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,186.7);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 36,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;