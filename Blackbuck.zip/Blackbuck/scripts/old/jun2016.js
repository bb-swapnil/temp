(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween137 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgVQAAgYASgSQASgRAXgBQAZAAASASQARASAAAYQAAAVgeA9QgPAggPAbQgOgbgPgggAgRgyQgIAHAAALQAAALAIAHQAHAIAKAAQALAAAHgIQAJgHgBgLQAAgLgIgHQgHgIgLAAQgKAAgHAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween136 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAIAAALQAAALAIAHQAHAIAKAAQALAAAIgIQAHgHAAgLQAAgLgHgIQgIgHgLAAQgKAAgHAHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween135 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgHAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAHAAALQAAALAHAIQAIAIAKAAQALAAAIgIQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgIAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween133 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZARgSQATgRAXAAQAZAAASARQARASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgyQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgHAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween132 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZARgSQASgRAYAAQAZAAARARQARASABAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAIAAALQAAALAIAHQAHAIAKAAQALAAAHgIQAIgHAAgLQAAgLgIgIQgHgHgLAAQgKAAgHAHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween131 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZARgSQASgRAYAAQAZAAARARQARASABAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAIgHQAHgIAAgLQAAgLgHgHQgIgIgLAAQgKAAgHAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween130 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgyQgHAHAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgHQgHgIgLAAQgKAAgIAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween129 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQASgRAXAAQAZAAARARQARASABAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgRgzQgIAHAAALQAAALAIAIQAHAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgHQgHgIgLAAQgKAAgHAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween128 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAYAAASASQARARABAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgyQgHAHAAALQAAALAHAIQAIAHAKAAQALAAAHgHQAIgIAAgLQAAgLgIgHQgHgIgLAAQgKAAgIAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween127 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgUQAAgZASgSQARgRAYAAQAZAAARARQASASAAAZQAAAUgeA9QgPAfgPAbQgOgbgPgfgAgSgzQgHAIAAALQAAALAHAIQAIAHAKAAQALAAAHgIQAIgIAAgKQAAgLgIgIQgHgHgLAAQgKAAgIAHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween126 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgVQAAgZASgRQASgSAYAAQAYAAARASQASARAAAZQAAAVgdA9QgPAggPAbQgPgbgPgggAgSgzQgHAIAAALQAAALAHAHQAJAIAKAAQAKAAAIgIQAIgIgBgKQABgLgIgIQgIgIgKAAQgKAAgJAIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.2);


(lib.Tween125 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgVQAAgYASgSQARgSAYAAQAZAAARASQASASAAAYQAAAVgeA9QgPAggPAbQgOgbgPgggAgSgzQgHAIAAALQAAALAHAHQAIAIAKAAQALAAAHgIQAIgHAAgLQAAgLgIgIQgHgHgLAAQgKAAgIAHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.Tween124 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71D49").s().p("AgdAqQgeg9AAgVQAAgYASgSQARgSAYAAQAZAAARASQASASAAAYQAAAVgeA9QgPAggPAbQgOgbgPgggAgSgzQgHAIAAALQAAALAHAHQAIAIAKAAQALAAAHgIQAIgHAAgLQAAgLgIgIQgHgHgLAAQgKAAgIAHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-10,12,20.1);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.JUN2016 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 31 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAELAkmMAAAg2bMBAEAAAMAAAA2bg");
	mask.setTransform(436.7,234.2);

	// Layer 18
	this.instance = new lib.Tween135("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(641.9,-15.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(67).to({_off:false},0).to({y:429.5},12,cjs.Ease.elasticInOut).to({_off:true},223).wait(792));

	// Layer 19
	this.instance_1 = new lib.Tween134("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(643.5,-13.6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(53).to({_off:false},0).to({y:388.4},12,cjs.Ease.elasticInOut).to({_off:true},237).wait(792));

	// Layer 20
	this.instance_2 = new lib.Tween133("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(619.6,-13.9);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(66).to({_off:false},0).to({y:359.1},12,cjs.Ease.elasticInOut).to({_off:true},224).wait(792));

	// Layer 22
	this.instance_3 = new lib.Tween127("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(584.9,-13.3);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({y:303.7},12,cjs.Ease.elasticInOut).to({_off:true},242).wait(792));

	// Layer 21
	this.instance_4 = new lib.Tween128("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(637.6,-13.6);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({_off:false},0).to({y:294.4},11,cjs.Ease.elasticInOut).to({_off:true},238).wait(792));

	// Layer 23
	this.instance_5 = new lib.Tween126("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(606.2,-11.3);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(30).to({_off:false},0).to({y:259.7},12,cjs.Ease.elasticInOut).to({_off:true},260).wait(792));

	// Layer 24
	this.instance_6 = new lib.Tween124("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(650.7,-12);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween125("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(643.3,212);

	var maskedShapeInstanceList = [this.instance_6,this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},40).to({state:[{t:this.instance_7}]},11).to({state:[]},251).wait(792));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(40).to({_off:false},0).to({_off:true,x:643.3,y:212},11,cjs.Ease.elasticInOut).wait(1043));

	// Layer 25
	this.instance_8 = new lib.Tween130("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(662.7,-9.3);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(46).to({_off:false},0).to({y:409.7},14,cjs.Ease.elasticInOut).to({_off:true},242).wait(792));

	// Layer 26
	this.instance_9 = new lib.Tween129("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(684,-8.9);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(58).to({_off:false},0).to({y:335.1},14,cjs.Ease.elasticInOut).to({_off:true},230).wait(792));

	// Layer 27
	this.instance_10 = new lib.Tween131("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(709.4,-8.7);
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(69).to({_off:false},0).to({y:271.3},15,cjs.Ease.elasticInOut).to({_off:true},218).wait(792));

	// Layer 28
	this.instance_11 = new lib.Tween132("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(670,-10.2);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(78).to({_off:false},0).to({y:290.8},16,cjs.Ease.elasticInOut).to({_off:true},208).wait(792));

	// Layer 29
	this.instance_12 = new lib.Tween136("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(798.4,-7.9);
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(85).to({_off:false},0).to({y:266.1},15,cjs.Ease.elasticInOut).to({_off:true},202).wait(792));

	// Layer 30
	this.instance_13 = new lib.Tween137("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(744.7,-8.7);
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(97).to({_off:false},0).to({y:300.3},17,cjs.Ease.elasticInOut).to({_off:true},188).wait(792));

	// Layer 16 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFCGQg4g3AAhPIAAAAQAAhOA4g3IAAAAQA3g4BOAAIAAAAQBPAAA4A4IAAAAQA3A3AABOIAAAAQAABPg3A3IAAAAQg4A4hPAAIAAAAQhOAAg3g4gAhkAHIBVhPgABjgWIhohVIgKAyIAKgyg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AihCiQhDhDAAhfIAAAAQAAheBDhDIAAAAQBEhDBdAAIAAAAQBfAABDBDIAAAAQBDBDAABeIAAAAQAABfhDBDIAAAAQhDBDhfAAIAAAAQhdAAhEhDgAhLhKQgoAngaAqIAAAAQAagqAognIAAAAQAWgUAWgRIAAAAIAHANIAAAAIANgUIAAAAIASgcIAAAAQAbASAYAWIAAAAQAqAjAdApIAAAAIAKAPIAAAAIgKgPIAAAAQgdgpgqgjIAAAAQgYgWgbgSIAAAAIgSAcIAAAAIgNAUIAAAAIgHgNIAAAAQgWARgWAUg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Ai8C9QhPhPAAhuIAAAAQAAhuBPhOIAAAAQBPhOBtAAIAAAAQBvAABOBOIAAAAQBPBOAABuIAAAAQAABuhPBPIAAAAQhOBOhvAAIAAAAQhtAAhPhOgAhphnQgzAygaA7IAAAAQAag7AzgyIAAAAQAcgaAfgUIAAAAIANALIAAAAQAKgMAMgJIAAAAQAQgPAPgKIAAAAQAkATAgAdIAAAAQA1AxAdA6IAAAAIAKAUIAAAAIgKgUIAAAAQgdg6g1gxIAAAAQgggdgkgTIAAAAQgPAKgQAPIAAAAQgMAJgKAMIAAAAIgNgLIAAAAQgfAUgcAag");
	var mask_1_graphics_3 = new cjs.Graphics().p("AjXDYQhahaAAh+IAAAAQAAh+BahZIAAAAQBahaB9AAIAAAAQCAAABZBaIAAAAQBZBZAAB+IAAAAQAAB+hZBaIAAAAQhZBaiAAAIAAAAQh9AAhahagAiFiEQhAA+gZBMIAAAAQAZhMBAg+IAAAAQAighAmgXIAAAAIATAJIAAAAQAPgNARgJIAAAAQAWgOAWgIIAAAAQAtAXAnAkIAAAAQBBA8AcBMIAAAAIAJAZIAAAAIgJgZIAAAAQgchMhBg8IAAAAQgngkgtgXIAAAAQgWAIgWAOIAAAAQgRAJgPANIAAAAIgTgJIAAAAQgmAXgiAhg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AjzDzQhlhkAAiPIAAAAQAAiPBlhkIAAAAQBmhlCNAAIAAAAQCQAABkBlIAAAAQBlBkAACPIAAAAQAACPhlBkIAAAAQhkBmiQAAIAAAAQiNAAhmhmgAijiiQhMBKgZBeIAAAAQAZheBMhKIAAAAQAognAugaIAAAAQANADANAEIAAAAQAUgNAVgJIAAAAQAdgNAcgHIAAAAQA2AaAvArIAAAAQBNBIAbBeIAAAAIAIAeIAAAAIgIgeIAAAAQgbhehNhIIAAAAQgvgrg2gaIAAAAQgcAHgdANIAAAAQgVAJgUANIAAAAQgNgEgNgDIAAAAQguAagoAng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AkOEPQhxhxABieIAAAAQgBieBxhxIAAAAQBxhvCdAAIAAAAQCgAABwBvIAAAAQBvBxAACeIAAAAQAACehvBxIAAAAQhwBwigAAIAAAAQidAAhxhwgACyjdQBYBUAbBvIAAAAQAFASADASIAAAAQgDgSgFgSIAAAAQgbhvhYhUIAAAAQg2gzg/gcIAAAAQgiAEglANIAAAAQgZAJgYANIAAAAQgRgDgPgBIAAAAQg2AcgvAuIAAAAQhYBVgYBwIAAAAQAYhwBYhVIAAAAQAvguA2gcIAAAAQAPABARADIAAAAQAYgNAZgJIAAAAQAlgNAigEIAAAAQA/AcA2Azg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AkqEqQh8h8AAiuIAAAAQAAivB8h7IAAAAQB8h8CuAAIAAAAQCvAAB8B8IAAAAQB8B7AACvIAAAAQAACuh8B8IAAAAQh8B8ivABIAAAAQiugBh8h8gADPj6QBlBgAaCAIAAAAQAFAWACAUIAAAAQgCgUgFgWIAAAAQgaiAhlhgIAAAAQg9g6hIgfIAAAAQgoABgsANIAAAAQgeAJgcAOIAAAAIgDAAIAAAAIADAAIAAAAQAcgOAegJIAAAAQAsgNAogBIAAAAQBIAfA9A6gAhrkwQg+Afg1A0IAAAAQhjBigYCBIAAAAQAYiBBjhiIAAAAQA1g0A+gfIAAAAIAAAAgAhlkwIAFAAIAAAAIgFAAgAhfkwIgBAAIAAAAIABAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AlFFFQiHiHAAi+IAAAAQAAi+CHiIIAAAAQCHiGC+AAIAAAAQC/AACHCGIAAAAQCHCIAAC+IAAAAQAAC+iHCHIAAAAQiHCIi/AAIAAAAQi+AAiHiIgAhKF2IAAAAIAAAAIAAAAgAhJF2QAiAAAmgFIAAAAQgmAFgiAAgAhPF2IgFAAIAAAAIAFAAgAABFwIADgBIAAAAIgDABgABYl5QBRAhBEBCIAAAAQBxBsAZCRIAAAAQAEAYACAXIAAAAQgCgXgEgYIAAAAQgZiRhxhsIAAAAQhEhChRghIAAAAIAAAAgAh6lWQhGAhg7A7IAAAAQhvBugYCSIAAAAQAYiSBvhuIAAAAQA7g7BGghIAAAAIAAAAgAh2lWIAUgBIAAAAIgUABgAhNlXQAggOAkgJIAAAAQgkAJggAOIAAAAIgGAAIAAAAIAGAAgAhhlXIAAAAIAAAAIAAAAgAgFlvQAsgKApgBIAAAAQgpABgsAKgABVl6IAAAAgABRl6IAAAAIAAAAIAAAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AlgFhQiSiTgBjOIAAAAQABjOCSiTIAAAAQCSiRDOAAIAAAAQDQAACSCRIAAAAQCRCTABDOIAAAAQgBDOiRCTIAAAAQiSCTjQgBIAAAAQjOABiSiTgAhDGeIAAAAIAAAAIAAAAgAhCGeQAhAAAigFIAAAAQgiAFghAAgAhcGeIgCAAIAAAAIACAAgABlmgQBbAkBLBIIAAAAQB9B5AYCjIAAAAQAFAaABAbIAAAAQgBgbgFgaIAAAAQgYijh9h5IAAAAQhLhIhbgkIAAAAIgCAAIAAAAIACAAgAiJl9QhOAlhBBAIAAAAQh8B6gXCjIAAAAQAXijB8h6IAAAAQBBhABOglIAAAAIAAAAgAiFl9QATgDAUAAIAAAAQgUAAgTADgAhVl/QAkgQAogIIAAAAQgoAIgkAQIAAAAIAAAAgAhdmAIAAAAIAAAAIAAAAgAgGmYIADAAIAAAAIgDAAgAgDmYIAAAAIAAAAIAAAAgAgBmZQApgIAlAAIAAAAQglAAgpAIgABOmhIAAAAIAAAAIAAAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("Al8F8QieidAAjfIAAAAQAAjfCeidIAAAAQCfidDdAAIAAAAQDgAACdCdIAAAAQCdCdABDfIAAAAQgBDfidCdIAAAAQidCejgAAIAAAAQjdAAifiegAhBHHIAAAAIAAAAIAAAAgAhAHHQAeAAAggEIAAAAQggAEgeAAgAhkHFIgBAAIAAAAIABAAgAhnHFIgCAAIAAAAIACAAgAABHDIACgBIAAAAIgCABgABznGQBjAmBTBQIAAAAQCICEAYC1IAAAAQAEAdABAeIAAAAQgBgegEgdIAAAAQgYi1iIiEIAAAAQhThQhjgmIAAAAIAAAAgAgJnAQgtAHgpAQIAAAAQgdABgcAFIAAAAQhWAnhIBHIAAAAQiHCGgWC0IAAAAQAWi0CHiGIAAAAQBIhHBWgnIAAAAQAcgFAdgBIAAAAQApgQAtgHIAAAAQArgIAoAAIAAAAQgoAAgrAIgABwnHIgCAAIAAAAIACAAgABLnIIAAAAIAAAAIAAAAg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AmYGXQioioAAjvIAAAAQAAjvCoipIAAAAQCrioDtAAIAAAAQDwAACpCoIAAAAQCoCpAADvIAAAAQAADvioCoIAAAAQipCqjwAAIAAAAQjtAAiriqgAg9HvIAAAAIAAAAIAAAAgAg9HvQAeAAAfgDIAAAAQgfADgeAAgAhwHtIAAAAIAAAAIAAAAgACAntQBtApBaBYIAAAAQCUCQAXDFIAAAAQAEAgABAhIAAAAQgBghgEggIAAAAQgXjFiUiQIAAAAQhahYhtgpIAAAAIgEAAIAAAAIAEAAgAgInqQgyAIgtARIAAAAQgiABgeAGIAAAAQhdAqhPBOIAAAAQiUCSgVDFIAAAAQAVjFCUiSIAAAAQBPhOBdgqIAAAAQAegGAigBIAAAAQAtgRAygIIAAAAIAAAAgAgGnqQApgGAmAAIAAAAQgmAAgpAGgABKnwIAAAAIAAAAIAAAAg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AmzGyQi0i0AAj+IAAAAQAAj/C0i0IAAAAQC1i0D+AAIAAAAQEAAAC0C0IAAAAQC0C0AAD/IAAAAQAAD+i0C0IAAAAQi0C2kAAAIAAAAQj+AAi1i2gAg7IYIgBAAIAAAAIABAAgAg7IYQAcAAAdgDIAAAAQgdADgcAAgAABIVIADgBIAAAAIgDABgAh4IVIgFgBIAAAAIAFABgACOoUQB2AsBgBeIAAAAQChCdAWDXIAAAAQAEAjAAAjIAAAAQAAgjgEgjIAAAAQgWjXihidIAAAAQhgheh2gsIAAAAIgDAAIAAAAIADAAgAgIoTQg2AHgyASIAAAAQglACgiAHIAAAAQhkAuhWBTIAAAAQifCegUDXIAAAAQAUjXCfieIAAAAQBWhTBkguIAAAAQAigHAlgCIAAAAQAygSA2gHIAAAAIAAAAgAgDoUIABAAIAAAAIgBAAgACLoUIgBAAIAAAAIABAAgAgCoUQAlgFAjAAIAAAAQgjAAglAFgABHoZIgBAAIAAAAIABAAg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AnPHOQi/i/AAkPIAAAAQAAkPC/i/IAAAAQDCi/ENAAIAAAAQEQAAC/C/IAAAAQC/C/ABEPIAAAAQgBEPi/C/IAAAAQi/DAkQAAIAAAAQkNAAjCjAgAg4JBIAAAAIAAAAIAAAAgAg3JBQAcAAAcgDIAAAAQgcADgcAAgAh4I9IgNgBIAAAAIANABgACbo6QB/AuBpBmIAAAAQCsCpAVDnIAAAAQADAiABAhIAAAAQgBghgDgiIAAAAQgVjnisipIAAAAQhphmh/guIAAAAIAAAAgAgIo8Qg7AHg2ASIAAAAQgoADglAJIAAAAQhtAwhcBZIAAAAQiqCqgUDpIAAAAQAUjpCqiqIAAAAQBchZBtgwIAAAAQAlgJAogDIAAAAQA2gSA7gHIAAAAIAAAAgAgDo9QAlgEAkAAIAAAAQgkAAglAEgABHpBIgBAAIAAAAIABAAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AnqHpQjLjLABkeIAAAAQgBkfDLjLIAAAAQDMjKEeAAIAAAAQEhAADKDKIAAAAQDKDLAAEfIAAAAQAAEejKDLIAAAAQjKDNkhgBIAAAAQkeABjMjNgAg2JpIgBAAIAAAAIABAAgAg2JpQAbAAAbgCIAAAAQgbACgbAAgAABJnIADAAIAAAAIgDAAgAiRJjIgCAAIAAAAIACAAgACpphQCIAxBvBtIAAAAQC4C0AVD6IAAAAQADAhAAAhIAAAAQAAghgDghIAAAAQgVj6i4i0IAAAAQhvhtiIgxIAAAAIAAAAgAgIpmQg/AIg7ASIAAAAQgqAEgpAKIAAAAQh1AyhiBhIAAAAQi2C2gUD6IAAAAQAUj6C2i2IAAAAQBihhB1gyIAAAAQApgKAqgEIAAAAQA7gSA/gIIAAAAIAAAAgACmphIgBgBIAAAAIABABgAgEpmIACAAIAAAAIgCAAgAAApmQAhgEAiAAIAAAAQgiAAghAEgABDpqIAAAAIAAAAIAAAAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AoFIFQjWjWAAkvIAAAAQAAkvDWjWIAAAAQDYjWEtAAIAAAAQEwAADWDWIAAAAQDWDWAAEvIAAAAQAAEvjWDWIAAAAQjWDXkwAAIAAAAQktAAjYjXgAg0KTIgBAAIAAAAIABAAgAg0KTIAxgCIAAAAIgxACgAAAKRIAAAAIAAAAIAAAAgAAAKRIAEAAIAAAAIgEAAgAiVKMIgIgBIAAAAIAIABgAC2qHQCRA0B3BzIAAAAQDEDBAUELIAAAAQADAgAAAhIAAAAQAAghgDggIAAAAQgUkLjEjBIAAAAQh3hziRg0IAAAAIgDgBIAAAAIADABgAgIqOQhDAGg/AUIAAAAQgvAEgrALIAAAAQh8A2hpBnIAAAAQjDDCgTELIAAAAQATkLDDjCIAAAAQBphnB8g2IAAAAQArgLAvgEIAAAAQA/gUBDgGIAAAAQAlgEAkAAIAAAAQgkAAglAEgABCqSIAAAAIAAAAIAAAAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AogIgQjhjhAAk/IAAAAQAAk/DhjhIAAAAQDjjiE9ABIAAAAQFBgBDgDiIAAAAQDiDhgBE/IAAAAQABE/jiDhIAAAAQjgDjlBgBIAAAAQk9ABjjjjgAg0K7IAAAAIAAAAIAAAAgAgzK7QAZAAAagBIAAAAQgaABgZAAgAigK0IgHgCIAAAAIAHACgADEquQCaA2B+B8IAAAAQDQDNATEbIAAAAQADAgAAAgIAAAAQAAgggDggIAAAAQgTkbjQjNIAAAAQh+h8iag2IAAAAIAAAAgAgHq4QhJAHhDAUIAAAAQgyAFguANIAAAAQiEA4hvBuIAAAAQjQDNgREdIAAAAQARkdDQjNIAAAAQBvhuCEg4IAAAAQAugNAygFIAAAAQBDgUBJgHIAAAAIAAAAgAC8qwIgBAAIAAAAIABAAgAgFq4QAigDAhAAIAAAAQghAAgiADgAA/q7IAAAAIAAAAIAAAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Ao8I7QjtjtAAlOIAAAAQAAlQDtjsIAAAAQDujtFOAAIAAAAQFQAADtDtIAAAAQDsDsABFQIAAAAQgBFOjsDtIAAAAQjtDulQABIAAAAQlOgBjujugAgvLlIgBAAIAAAAIABAAgAgvLlIAvgCIAAAAIgvACgAijLcIgEAAIAAAAIAEAAgAipLbIgDAAIAAAAIADAAgAisLbIgGgBIAAAAIAGABgADRrVQCkA5CECDIAAAAQDcDZATEtIAAAAQACAdAAAdIAAAAQAAgdgCgdIAAAAQgTktjcjZIAAAAQiEiDikg5IAAAAIgIgCIAAAAIAIACgAgHrhQhNAGhIAVIAAAAQg1AGgyAOIAAAAQiLA7h2B0IAAAAQjbDZgREuIAAAAQARkuDbjZIAAAAQB2h0CLg7IAAAAQAygOA1gGIAAAAQBIgVBNgGIAAAAIAGAAIAAAAIgGAAgAAAriQAegCAfAAIAAAAQgfAAgeACgAA+rkIgBAAIAAAAIABAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ApYJWQj3j4AAleIAAAAQAAlgD3j3IAAAAQD6j4FeAAIAAAAQFgAAD5D4IAAAAQD3D3AAFgIAAAAQAAFej3D4IAAAAQj5D6lgAAIAAAAQleAAj6j6gAgvMNIAAAAIAAAAIAAAAgAguMNIApgBIAAAAIgpABgADfr7QCsA7CMCLIAAAAQDoDkASE/IAAAAIACA1IAAAAIgCg1IAAAAQgSk/jojkIAAAAQiMiLisg7IAAAAIgEgBIAAAAIAEABgAgHsKQhSAFhMAWIAAAAQg4AHg1AQIAAAAQiUA+h8B6IAAAAQjmDlgRFAIAAAAQARlADmjlIAAAAQB8h6CUg+IAAAAQA1gQA4gHIAAAAQBMgWBSgFIAAAAIAAAAgAAAsLQAdgCAdAAIAAAAQgdAAgdACgAA6sNIAAAAIAAAAIAAAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("ApzJxQkDkDAAluIAAAAQAAlvEDkEIAAAAQEFkDFuAAIAAAAQFxAAEDEDIAAAAQEDEEAAFvIAAAAQAAFukDEDIAAAAQkDEGlxAAIAAAAQluAAkFkGgAgqM3IgBAAIAAAAIABAAgAgqM3IAlgBIAAAAIglABgAi4MsIgFgBIAAAAIAFABgAi+MrIgJgCIAAAAIAJACgADssiQC2A+CTCSIAAAAQD0DwASFRIAAAAIABAyIAAAAIgBgyIAAAAQgSlRj0jwIAAAAQiTiSi2g+IAAAAIgDgBIAAAAIADABgAgHs0QhWAGhQAXIAAAAQg8AHg4ARIAAAAQibBBiDCAIAAAAQjzDygQFQIAAAAQAQlQDzjyIAAAAQCDiACbhBIAAAAQA4gRA8gHIAAAAQBQgXBWgGIAAAAQAggCAgAAIAAAAQggAAggACgAA6s2IgBAAIAAAAIABAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AqOKNQkPkPAAl+IAAAAQAAl/EPkPIAAAAQEQkOF+AAIAAAAQGBAAEPEOIAAAAQEOEPAAF/IAAAAQAAF+kOEPIAAAAQkPEQmBAAIAAAAQl+AAkQkQgAgqNgIgBAAIAAAAIABAAgAgqNgIAngBIAAAAIgnABgAAANfIADgBIAAAAIgDABgAD6tJQC/BCCaCYIAAAAQD/D9ARFiIAAAAIACAxIAAAAIgCgxIAAAAQgRlij/j9IAAAAQiaiYi/hCIAAAAIgGgBIAAAAIAGABgAgGtdQhcAGhUAXIAAAAQg/AIg7ATIAAAAQikBDiICGIAAAAQj/D+gPFiIAAAAQAPliD/j+IAAAAQCIiGCkhDIAAAAQA7gTA/gIIAAAAQBUgXBcgGIAAAAIAAAAgADztKIgFgBIAAAAIAFABgADqtMIgBAAIAAAAIABAAgAAFteIAxgBIAAAAIgxABgAA2tfIAAAAIAAAAIAAAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AqqKoQkakZABmPIAAAAQgBmQEakZIAAAAQEckbGOAAIAAAAQGRAAEaEbIAAAAQEaEZgBGQIAAAAQABGPkaEZIAAAAQkaEdmRAAIAAAAQmOAAkckdgAgmOJIAAAAIAAAAIAAAAgAgmOJIAfgBIAAAAIgfABgAjWN5IgGgBIAAAAIAGABgAEHtvQDIBECiCfIAAAAQEMEKAQFyIAAAAIABAyIAAAAIgBgyIAAAAQgQlykMkKIAAAAQiiifjIhEIAAAAIAAAAgAgGuGQhgAFhYAXIAAAAQhDAKg/AUIAAAAQiqBGiQCNIAAAAQkKEKgPFzIAAAAQAPlzEKkKIAAAAQCQiNCqhGIAAAAQA/gUBDgKIAAAAQBYgXBggFIAAAAIACAAIAAAAIgCAAgAD+tyIgDAAIAAAAIADAAgAgCuGQAcgCAcAAIAAAAQgcAAgcACgAA3uIIgBAAIAAAAIABAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("ArFLDQklklAAmeIAAAAQAAmgElklIAAAAQEoklGdAAIAAAAQGhAAElElIAAAAQElElAAGgIAAAAQAAGeklElIAAAAQklEomhAAIAAAAQmdAAkokogAglOyIgBAAIAAAAIABAAgAglOyIAigBIAAAAIgiABgAEVuWQDRBGCpCoIAAAAQEXEVAPGEIAAAAIACAwIAAAAIgCgwIAAAAQgPmEkXkVIAAAAQipiojRhGIAAAAIgCAAIAAAAIACAAgAgGuwQhlAFhcAZIAAAAQhGAKhBAVIAAAAQi0BJiVCTIAAAAQkXEWgOGEIAAAAQAOmEEXkWIAAAAQCViTC0hJIAAAAQBBgVBGgKIAAAAQBcgZBlgFIAAAAQAcgBAdAAIAAAAQgdAAgcABgAETuWIgJgDIAAAAIAJADgAAzuxIAAAAIAAAAIAAAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("ArgLfQkxkxAAmuIAAAAQAAmwExkxIAAAAQEzkwGtAAIAAAAQGxAAEwEwIAAAAQExExAAGwIAAAAQAAGukxExIAAAAQkwEzmxAAIAAAAQmtAAkzkzgAglPbIgBAAIAAAAIABAAgAglPbIAeAAIAAAAIgeAAgAAAPaIADAAIAAAAIgDAAgAEiu9QDaBKCwCuIAAAAQEkEhAOGVIAAAAIABAxIAAAAIgBgxIAAAAQgOmVkkkhIAAAAQiwiujahKIAAAAIAAAAgAgFvZQhqAFhhAZIAAAAQhJALhFAXIAAAAQi7BLibCaIAAAAQkjEigOGVIAAAAQAOmVEjkiIAAAAQCbiaC7hLIAAAAQBFgXBJgLIAAAAQBhgZBqgFIAAAAIAAAAgAEeu+IAAAAIAAAAIAAAAgAEeu+IgCAAIAAAAIACAAgAgDvZIAzgBIAAAAIgzABgAAwvaIAAAAIAAAAIAAAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Ar8L6Qk8k8ABm+IAAAAQgBnAE8k8IAAAAQE/k7G9AAIAAAAQHCAAE7E7IAAAAQE8E8gBHAIAAAAQABG+k8E8IAAAAQk7E+nCAAIAAAAQm9AAk/k+gAglQEIgBAAIAAAAIABAAgAglQEIAdAAIAAAAIgdAAgAgGQEIAEAAIAAAAIgEAAgAjxPxIgKgCIAAAAIAKACgAEvvjQDkBMC3C2IAAAAQEvEsAOGnIAAAAIABAqIAAAAIgBgqIAAAAQgOmnkvksIAAAAQi3i2jkhMIAAAAIAAAAgAgFwCQhuAFhmAZIAAAAQhNAMhHAYIAAAAQjDBOihChIAAAAQkvEtgNGnIAAAAQANmnEvktIAAAAQChihDDhOIAAAAQBHgYBNgMIAAAAQBmgZBugFIAAAAIAAAAgAEmvlIgBAAIAAAAIABAAgAgCwCIAvgBIAAAAIgvABgAAtwDIAAAAIAAAAIAAAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AsXMVQlHlHAAnOIAAAAQAAnQFHlHIAAAAQFKlHHNAAIAAAAQHSAAFGFHIAAAAQFHFHAAHQIAAAAQAAHOlHFHIAAAAQlGFKnSAAIAAAAQnNAAlKlKgAglQtIAAAAIAAAAIAAAAgAglQtIAjAAIAAAAIgjAAgAj9QYIgBAAIAAAAIABAAgAE8wJQDuBOC+C9IAAAAQE7E5ANG4IAAAAIABApIAAAAIgBgpIAAAAQgNm4k7k5IAAAAQi+i9juhOIAAAAIgJgDIAAAAIAJADgAgFwrQhyAEhrAaIAAAAQhPAOhLAZIAAAAQjLBRioCnIAAAAQk7E5gMG4IAAAAQAMm4E7k5IAAAAQCoinDLhRIAAAAQBLgZBPgOIAAAAQBrgaBygEIAAAAIAugBIAAAAIguABgAAqwsIgBAAIAAAAIABAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AsyMwQlTlRAAnfIAAAAQAAngFTlSIAAAAQFVlTHdAAIAAAAQHhAAFSFTIAAAAQFTFSAAHgIAAAAQAAHflTFRIAAAAQlSFWnhAAIAAAAQndAAlVlWgAggRWIgBAAIAAAAIABAAgAggRWIAfAAIAAAAIgfAAgAgBRWIADAAIAAAAIgDAAgAkDRBIgFgBIAAAAIAFABgAkLQ/IAAAAIAAAAIAAAAgAFKwxQD2BSDGDEIAAAAQFHFFANHJIAAAAIAAApIAAAAIAAgpIAAAAQgNnJlHlFIAAAAQjGjEj2hSIAAAAIgDAAIAAAAIADAAgAgFxVQh3AFhuAbIAAAAQhTAOhOAaIAAAAQjTBUivCtIAAAAQlGFFgMHKIAAAAQAMnKFGlFIAAAAQCvitDThUIAAAAQBOgaBTgOIAAAAQBugbB3gFIAAAAIAAAAgAAAxVIApAAIAAAAIgpAAgAAqxVIgBAAIAAAAIABAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AtONMQleleAAnuIAAAAQAAnxFeldIAAAAQFhleHtAAIAAAAQHyAAFdFeIAAAAQFdFdABHxIAAAAQgBHuldFeIAAAAQldFgnyABIAAAAQntgBlhlggAghR/IAAAAIAAAAIAAAAgAggR/IAiAAIAAAAIgiAAgAkURnIgHgCIAAAAIAHACgAFXxXQEABUDNDLIAAAAQFSFRAMHbIAAAAIABAoIAAAAIgBgoIAAAAQgMnblSlRIAAAAQjNjLkAhUIAAAAIAAAAgAgEx+Qh9AEhyAbIAAAAQhXAPhRAcIAAAAQjaBXi1C0IAAAAQlSFRgMHbIAAAAQAMnbFSlRIAAAAQC1i0DahXIAAAAQBRgcBXgPIAAAAQBygbB9gEIAAAAIAAAAgAFRxZIgDgBIAAAAIADABgAgBx+IAAAAIAAAAIAAAAgAAEx+IAigBIAAAAIgiABgAAnx/IgBAAIAAAAIABAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AtpNnQlqloABn/IAAAAQgBoAFqlqIAAAAQFsloH9gBIAAAAQICABFoFoIAAAAQFpFqAAIAIAAAAQAAH/lpFoIAAAAQloFsoCABIAAAAQn9gBlslsgAgcSpIgBAAIAAAAIABAAgAgcSpIAegBIAAAAIgeABgAkeSPIgFgBIAAAAIAFABgAFlx9QEJBWDTDTIAAAAQFfFdAMHsIAAAAIAAAmIAAAAIAAgmIAAAAQgMnslfldIAAAAQjTjTkJhWIAAAAIAAAAgAgEynQiBAEh3AcIAAAAQhZAQhVAdIAAAAQjiBZi7C6IAAAAQleFegLHsIAAAAQALnsFeleIAAAAQC7i6DihZIAAAAQBVgdBZgQIAAAAQB3gcCBgEIAAAAIAAAAgAFRyDIgCAAIAAAAIACAAgAAAynIAmgBIAAAAIgmABgAAmyoIAAAAIAAAAIAAAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AuEOCQl1l0AAoOIAAAAQAAoRF1l0IAAAAQF3l0INAAIAAAAQISAAF0F0IAAAAQF0F0AAIRIAAAAQAAIOl0F0IAAAAQl0F4oSAAIAAAAQoNAAl3l4gAgcTSIAAAAIAAAAIAAAAgAgcTSIAegBIAAAAIgeABgAklS3IgDgBIAAAAIADABgAkoS2IgIgCIAAAAIAIACgAFyykQESBZDcDaIAAAAQFqFpALH9IAAAAIAAAgIAAAAIAAggIAAAAQgLn9lqlpIAAAAQjcjakShZIAAAAIAAAAgAgEzQQiGADh7AdIAAAAQhdAQhXAfIAAAAQjqBcjCDAIAAAAQlqFqgKH9IAAAAQAKn9FqlqIAAAAQDCjADqhcIAAAAQBXgfBdgQIAAAAQB7gdCGgDIAAAAIADgBIAAAAIgDABgAFuylIgHgCIAAAAIAHACgAACzRIAhAAIAAAAIghAAgAAjzRIAAAAIAAAAIAAAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AugOeQmAl/AAofIAAAAQAAogGAmBIAAAAQGDl/IdAAIAAAAQIiAAGAF/IAAAAQF/GBAAIgIAAAAQAAIfl/F/IAAAAQmAGDoiAAIAAAAQodAAmDmDgAgYT7IAAAAIAAAAIAAAAgAgYT7IAVAAIAAAAIgVAAgAktTfIgCgBIAAAAIACABgAkwTeIgFgBIAAAAIAFABgAk3TdIgDgBIAAAAIADABgAGAzLQEbBcDiDhIAAAAQF3F1AKIPIAAAAIAAAZIAAAAIAAgZIAAAAQgKoPl3l1IAAAAQjijhkbhcIAAAAIAAAAgAgEz5QiJADiAAeIAAAAQhhARhaAgIAAAAQjyBfjIDGIAAAAQl2F2gKIPIAAAAQAKoPF2l2IAAAAQDIjGDyhfIAAAAQBaggBhgRIAAAAQCAgeCJgDIAAAAIAkgBIAAAAIgkABgAF8zMIgDgBIAAAAIADABgAF1zOIgCgBIAAAAIACABgAAgz6IAAAAIAAAAIAAAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Au7O5QmMmLABouIAAAAQgBowGMmMIAAAAQGOmKItgBIAAAAQIyABGLGKIAAAAQGKGMAAIwIAAAAQAAIumKGLIAAAAQmLGPoyAAIAAAAQotAAmOmPgAgYUkIgBAAIAAAAIABAAgAgYUkIAZAAIAAAAIgZAAgAk+UFIgCAAIAAAAIACAAgAGNzxQElBeDpDpIAAAAQGCGBAKIgIAAAAIAAAZIAAAAIAAgZIAAAAQgKogmCmBIAAAAQjpjpklheIAAAAIgKgEIAAAAIAKAEgAgD0jQiPAEiEAeIAAAAQhkASheAhIAAAAQj5BijODMIAAAAQmDGDgIIfIAAAAQAIofGDmDIAAAAQDOjMD5hiIAAAAQBeghBkgSIAAAAQCEgeCPgEIAAAAIADAAIAAAAIgDAAgAGCz1IgDAAIAAAAIADAAgAAC0jIAbAAIAAAAIgbAAgAAd0jIAAAAIAAAAIAAAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AvXPVQmWmXAAo+IAAAAQAApBGWmWIAAAAQGamWI9AAIAAAAQJCAAGWGWIAAAAQGWGWAAJBIAAAAQAAI+mWGXIAAAAQmWGZpCAAIAAAAQo9AAmamZgAgUVOIgBAAIAAAAIABAAgAgUVOIAVgBIAAAAIgVABgAGb0YQEtBhDxDwIAAAAQGOGNAJIyIAAAAIAAAXIAAAAIAAgXIAAAAQgJoymOmNIAAAAQjxjwkthhIAAAAIgFgBIAAAAIAFABgAgD1MQiTADiJAfIAAAAQhnAShgAkIAAAAQkCBkjVDTIAAAAQmOGOgIIxIAAAAQAIoxGOmOIAAAAQDVjTEChkIAAAAQBggkBngSIAAAAQCJgfCTgDIAAAAIAgAAIAAAAIggAAgAAd1MIAAAAIAAAAIAAAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AvyPwQmimhAApPIAAAAQAApRGimiIAAAAQGlmhJNAAIAAAAQJSAAGhGhIAAAAQGiGiAAJRIAAAAQAAJPmiGhIAAAAQmhGlpSAAIAAAAQpNAAmlmlgAgUV3IAAAAIAAAAIAAAAgAgUV3IAVAAIAAAAIgVAAgAGo0/QE3BlD3D3IAAAAQGbGZAIJDIAAAAIAAAXIAAAAIAAgXIAAAAQgIpDmbmZIAAAAQj3j3k3hlIAAAAIgLgDIAAAAIALADgAgD12QiYADiNAgIAAAAQhqAUhkAjIAAAAQkJBpjbDZIAAAAQmbGagHJCIAAAAQAHpCGbmaIAAAAQDbjZEJhpIAAAAQBkgjBqgUIAAAAQCNggCYgDIAAAAIAAAAgAGd1CIgGgBIAAAAIAGABgAGW1EIgDgBIAAAAIADABgAAA12IAZAAIAAAAIgZAAgAAa12IgBAAIAAAAIABAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AwOQLQmsmtAApeIAAAAQAAphGsmtIAAAAQGxmtJdABIAAAAQJjgBGsGtIAAAAQGsGtAAJhIAAAAQAAJemsGtIAAAAQmsGwpjAAIAAAAQpdAAmxmwgAgQWgIAAAAIAAAAIAAAAgAgQWgIARAAIAAAAIgRAAgAldV8IgHgCIAAAAIAHACgAG21lQE/BmD/D/IAAAAQGnGlAHJUIAAAAIAAAZIAAAAIAAgZIAAAAQgHpUmnmlIAAAAQj/j/k/hmIAAAAIgLgDIAAAAIALADgAgC2fQieADiRAgIAAAAQhtAVhnAlIAAAAQkRBrjiDfIAAAAQmlGmgIJUIAAAAQAIpUGlmmIAAAAQDijfERhrIAAAAQBnglBtgVIAAAAQCRggCegDIAAAAIAAAAgAAB2fIAZAAIAAAAIgZAAgAAa2fIAAAAIAAAAIAAAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AwpQnQm5m5AApuIAAAAQAApxG5m5IAAAAQG8m3JtgBIAAAAQJzABG4G3IAAAAQG4G5AAJxIAAAAQAAJum4G5IAAAAQm4G8pzAAIAAAAQptAAm8m8gAgPXJIgBAAIAAAAIABAAgAgPXJIARAAIAAAAIgRAAgAlgWlIgOgDIAAAAIAOADgAHE2MQFIBqEHEFIAAAAQGyGyAGJlIAAAAIAAAWIAAAAIAAgWIAAAAQgGplmymyIAAAAQkHkFlIhqIAAAAIAAAAgAgC3IQiiADiVAgIAAAAQhxAWhqAnIAAAAQkZBtjoDmIAAAAQmyGxgGJmIAAAAQAGpmGymxIAAAAQDojmEZhtIAAAAQBqgnBxgWIAAAAQCVggCigDIAAAAIAYAAIAAAAIgYAAgAG+2OIgDgBIAAAAIADABgAG52PIgHgCIAAAAIAHACgAAX3IIgBAAIAAAAIABAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AxFRCQnDnEAAp+IAAAAQAAqBHDnEIAAAAQHInDJ9AAIAAAAQKCAAHEHDIAAAAQHDHEAAKBIAAAAQAAJ+nDHEIAAAAQnEHHqCAAIAAAAQp9AAnInHgAgMXzIAAAAIAAAAIAAAAgAgIXzIAAAAIAAAAIAAAAgAgFXzIAAAAIAAAAIAAAAgAlpXNIgQgEIAAAAIAQAEgAHR2zQFRBsEOENIAAAAQG+G9AGJ4IAAAAIAAAPIAAAAIAAgPIAAAAQgGp4m+m9IAAAAQkOkNlRhsIAAAAIAAAAgAgB3xQinACiaAhIAAAAQh0AXhuAoIAAAAQkgBwjvDtIAAAAQm+G9gFJ3IAAAAQAFp3G+m9IAAAAQDvjtEghwIAAAAQBugoB0gXIAAAAQCaghCngCIAAAAIAUAAIAAAAIgUAAgAAU3xIgBAAIAAAAIABAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AxgRdQnPnOAAqPIAAAAQAAqSHPnOIAAAAQHTnPKNAAIAAAAQKTAAHOHPIAAAAQHPHOAAKSIAAAAQAAKPnPHOIAAAAQnOHTqTAAIAAAAQqNAAnTnTgAgLYcIgBAAIAAAAIABAAgAgLYcIAMgBIAAAAIgMABgAHf3ZQFaBuEVEVIAAAAQHKHJAFKJIAAAAIAAAQIAAAAIAAgQIAAAAQgFqJnKnJIAAAAQkVkVlahuIAAAAIAAAAgAgB4aQirABifAjIAAAAQh3AXhwApIAAAAQkpB0j1DyIAAAAQnJHKgFKIIAAAAQAFqIHJnKIAAAAQD1jyEph0IAAAAQBwgpB3gXIAAAAQCfgjCrgBIAAAAIAAAAgAHa3aIgEgBIAAAAIAEABgAHS3dIgPgEIAAAAIAPAEgAAA4bIAQAAIAAAAIgQAAgAAQ4bIAAAAIAAAAIAAAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ax7R5QnanaAAqfIAAAAQAAqiHanZIAAAAQHenaKdgBIAAAAQKjABHZHaIAAAAQHbHZgBKiIAAAAQABKfnbHaIAAAAQnZHdqjABIAAAAQqdgBnendgAgLZFIgBAAIAAAAIABAAgAgLZFIAGAAIAAAAIgGAAgAgFZFIAGAAIAAAAIgGAAgAlvYgIgGgCIAAAAIAGACgAl6YdIgHgBIAAAAIAHABgAmHYaIgHgBIAAAAIAHABgAHr3/QFlBwEcEcIAAAAQHVHVAFKaIAAAAIAAARIAAAAIAAgRIAAAAQgFqanVnVIAAAAQkckcllhwIAAAAIAAAAgAgB5EQiwACijAiIAAAAQh7AZhyArIAAAAQkxB2j7D5IAAAAQnWHVgFKZIAAAAQAFqZHWnVIAAAAQD7j5Exh2IAAAAQBygrB7gZIAAAAQCjgiCwgCIAAAAIARAAIAAAAIgRAAgAAQ5EIAAAAIAAAAIAAAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AyXSTQnlnlAAquIAAAAQAAqyHlnlIAAAAQHqnlKtAAIAAAAQKzAAHlHlIAAAAQHlHlAAKyIAAAAQAAKunlHlIAAAAQnlHqqzAAIAAAAQqtAAnqnqgAgLZuIgBAAIAAAAIABAAgAgLZuIAMAAIAAAAIgMAAgAmJZEIgCgBIAAAAIACABgAmVZBIgEgBIAAAAIAEABgAH54mQFtBzEjEjIAAAAQHiHiAEKrIAAAAIAAAOIAAAAIAAgOIAAAAQgEqrniniIAAAAQkjkjlthzIAAAAIAAAAgAAA5tQi2ABinAkIAAAAQh9AZh3AsIAAAAQk4B5kBD/IAAAAQnjHhgDKrIAAAAQADqrHjnhIAAAAQEBj/E4h5IAAAAQB3gsB9gZIAAAAQCngkC2gBIAAAAIANAAIAAAAIgNAAgAH14oIgKgDIAAAAIAKADgAAN5tIAAAAIAAAAIAAAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AyySvQnxnwAAq/IAAAAQAArBHxnxIAAAAQH1nxK9AAIAAAAQLDAAHxHxIAAAAQHwHxAALBIAAAAQAAK/nwHwIAAAAQnxH1rDAAIAAAAQq9AAn1n1gAgHaYIgBAAIAAAAIABAAgAgHaYIAIgBIAAAAIgIABgAmZZqIgHgCIAAAAIAHACgAIG5NQF3B3ErEqIAAAAQHtHtADK8IAAAAIABAHIAAAAIgBgHIAAAAQgDq8ntntIAAAAQkrkql3h3IAAAAIAAAAgAAA6WQi6ABirAkIAAAAQiBAah6AtIAAAAQlAB8kIEGIAAAAQntHugEK7IAAAAQAEq7HtnuIAAAAQEIkGFAh8IAAAAQB6gtCBgaIAAAAQCrgkC6gBIAAAAIANAAIAAAAIgNAAgAH95QIgEgBIAAAAIAEABgAAN6WIAAAAIAAAAIAAAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AzOTLQn8n9ABrOIAAAAQgBrRH8n9IAAAAQIBn7LNgBIAAAAQLTABH8H7IAAAAQH8H9gBLRIAAAAQABLOn8H9IAAAAQn8IArTAAIAAAAQrNAAoBoAgAgHbBIgBAAIAAAAIABAAgAgFbBIAAAAIAAAAIAAAAgAmpaRIgFgCIAAAAIAFACgAIU5zQF/B5EyExIAAAAQH5H6ADLNIAAAAIABAHIAAAAIgBgHIAAAAQgDrNn5n6IAAAAQkykxl/h5IAAAAIAAAAgAAA6/Qi+ABiwAlIAAAAQiFAah8AvIAAAAQlIB+kPENIAAAAQn5H5gCLNIAAAAQACrNH5n5IAAAAQEPkNFIh+IAAAAQB8gvCFgaIAAAAQCwglC+gBIAAAAIAKgBIAAAAIgKABgAIS50IgDgBIAAAAIADABgAIC55IgBAAIAAAAIABAAgAHy5+IgBAAIAAAAIABAAgAAK7AIAAAAIAAAAIAAAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AzpTmQoHoIgBreIAAAAQABriIHoHIAAAAQIMoILdABIAAAAQLjgBIIIIIAAAAQIHIHAALiIAAAAQAALeoHIIIAAAAQoIIMrjgBIAAAAQrdABoMoMgAgDbqIAAAAIAAAAIAAAAgAgDbqIACAAIAAAAIgCAAgAmya4IgGgBIAAAAIAGABgAAA7oQjCAAi0AlIAAAAQiJAch/AxIAAAAQlQCBkVESIAAAAQoFIFgCLfIAAAAQACrfIFoFIAAAAQEVkSFQiBIAAAAQB/gxCJgcIAAAAQC0glDCAAIAAAAIADgBIAAAAIgDABgAIh6aQGJB8E5E4IAAAAQIGIGACLfIAAAAQgCrfoGoGIAAAAQk5k4mJh8IAAAAIAAAAgAIc6cIgCAAIAAAAIACAAgAIX6dIgKgDIAAAAIAKADgAAH7pIgBAAIAAAAIABAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A0EUBQoToSAArvIAAAAQAAryIToSIAAAAQIXoTLtAAIAAAAQLzAAITITIAAAAQISISAALyIAAAAQAALvoSISIAAAAQoTIXrzAAIAAAAQrtAAoXoXgAgDcTIgBAAIAAAAIABAAgAm+bgIgEgBIAAAAIAEABgAAA8SQjHABi5AmIAAAAQiLAciDAxIAAAAQlXCEkbEZIAAAAQoSISgBLwIAAAAQABrwISoSIAAAAQEbkZFXiEIAAAAQCDgxCLgcIAAAAQC5gmDHgBIAAAAIAAAAgAIv7BQGSB/FAFAIAAAAQIRISABLvIAAAAQgBrvoRoSIAAAAQlAlAmSh/IAAAAIAAAAgAIi7FIgHgCIAAAAIAHACgAAE8SIgBAAIAAAAIABAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A0fUcQofodAAr/IAAAAQAAsCIfoeIAAAAQIioeL9AAIAAAAQMEAAIdIeIAAAAQIeIeAAMCIAAAAQAAL/oeIdIAAAAQodIjsEAAIAAAAQr9AAoiojgAmI8UQiPAdiGAzIAAAAQlfCHkhEfIAAAAQoeIegBMAIAAAAQABsAIeoeIAAAAQEhkfFfiHIAAAAQCGgzCPgdIAAAAQC9gnDLAAIAAAAQEwAAEMBUIAAAAQGcCBFGFHIAAAAQIeIeABMBIAAAAQgBsBoeoeIAAAAQlGlHmciBIAAAAQkMhUkwAAIAAAAQjLAAi9Ang");
	var mask_1_graphics_44 = new cjs.Graphics().p("A07U3QoqopAAsOQAAsSIqopQIuopMNgBQMUABIpIpQIpIpgBMSQABMOopIpQopIusUAAQsNAAououg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_1,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_2,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_3,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_4,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_5,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_6,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_7,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_8,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_9,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_10,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_11,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_12,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_13,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_14,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_15,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_16,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_17,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_18,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_19,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_20,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_21,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_22,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_23,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_24,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_25,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_26,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_27,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_28,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_29,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_30,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_31,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_32,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_33,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_34,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_35,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_36,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_37,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_38,x:652.8,y:299.4}).wait(1).to({graphics:mask_1_graphics_39,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_40,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_41,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_42,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_43,x:652.8,y:299.3}).wait(1).to({graphics:mask_1_graphics_44,x:652.8,y:299.4}).wait(1050));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D6D4D5").s().p("An7XIQgBgKAJgJQAJgJAKgBQAKAAAJAIQAIAIAAALQAAAMgHAIQgIAIgMAAQgYAAgDgagApRXIQgCgKAJgJQAJgJALgBQAKAAAIAIQAIAIAAALQABAMgIAIQgHAIgMAAQgYAAgDgagAnGWYQgIgJAAgLQAAgLAJgIQAIgIALAAQAMAAAHAIQAIAJAAALQAAAMgIAHQgIAIgMAAQgLAAgIgIgAodWYQgIgJAAgLQAAgLAIgIQAJgIALAAQALAAAIAIQAIAJAAALQgBAMgIAHQgIAIgLAAQgLAAgIgIgApgWgQgYgBgDgZQgBgLAJgIQAJgIANgBQAXAEABAWQAAAMgHAIQgIAIgLAAIgBAAgAnhVhQgMAAgIgIQgHgIAAgMQABgXAZgDQALgBAJAIQAIAIAAAMQAAALgIAIQgIAIgKAAIgBAAgApRVHQgCgKAJgJQAJgJALgBQAKAAAIAIQAIAIAAALQABAMgIAIQgHAIgMAAQgYAAgDgagAqnVHQgBgKAJgJQAJgJAKgBQAKAAAJAIQAIAIAAALQAAAMgHAIQgIAIgMAAQgXAAgEgagAmlVGQAAgLAIgJQAJgIAKABQAZABABAZQABALgJAIQgIAIgNAAQgXgDgBgXgApgUiQgXgBgDgZQAAgLAJgJQAJgJALAAQALABAHAIQAHAIAAALQAAANgIAHQgHAHgLAAIgCAAgAq2UiQgYgBgCgZQgBgLAJgJQAKgJALAAQAKABAHAIQAIAIgBALQAAANgIAHQgHAHgLAAIgBAAgAnGUZQgJgIABgLQADgYAYgDQALgBAIAJQAJAJAAALQAAAMgIAHQgHAIgNAAQgLAAgIgJgAobUaQgIgIAAgLQABgYAZgDQAKgCAJAJQAIAIAAANQgBAYgYABIgCAAQgKAAgIgHgAlwUaQgGgHgBgMQgBgLAJgJQAJgJAKABQAZAEACAXQAAAMgIAIQgJAHgOAAQgKAAgGgHgAqfTdQgJgIAAgLQABgYAYgDQANgBAIAHQAIAHAAAMQABAMgIAIQgIAJgLAAIgBAAQgKAAgIgIgAr2TdQgIgIAAgLQAAgYAZgDQANgBAIAHQAIAHAAAMQABAMgIAIQgIAJgLAAIgCAAQgKAAgIgIgAmMTkQgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAAMQAAALgJAIQgIAHgJAAIgDAAgAnzTdQgIgJAAgKQgBgMAIgIQAIgIALAAQAMAAAHAIQAIAJABANQgCAWgYACIgDAAQgJAAgIgHgAlGTcQgJgIABgLQAAgMAIgIQAIgHALAAQAXACADAZQgCAYgYADIgCAAQgKAAgHgIgApKTcQgIgJAAgLQABgYAZgCQAMgBAIAIQAIAIAAAMQAAALgIAIQgHAHgLAAIgCAAQgKAAgIgHgAocScQgJgIABgLQABgLAIgIQAJgIALABQAMAAAHAIQAIAJgBAMQgCAYgYABQgMAAgJgJgApgSlQgZgDAAgZQAAgLAJgIQAJgHALABQAXACACAZQgBAMgIAHQgIAHgKAAIgCAAgAluSdQgJgIAAgLQACgYAYgDQALgBAJAIQAIAIAAAMQAAALgHAIQgIAIgKAAQgMAAgIgIgAnFSeQgIgIgBgLQAAgKAJgJQAIgJALABQAaABAAAbQgBAXgXABIgDAAQgKAAgIgGgAq2SkQgZAAgBgaQAAgLAIgIQAJgIALAAQAXACADAYQAAAMgIAIQgHAHgKAAIgDAAgAk0RnQgZgDgBgZQAAgLAJgIQAIgIALAAQALABAIAIQAIAJAAALQgBAMgIAHQgIAHgKAAIgCAAgAnzReQgIgIAAgLQAAgLAJgIQAIgIALABQAZABABAZQABALgIAJQgIAIgMAAQgLgBgIgIgAo3RmQgLAAgIgJQgHgJABgLQAEgZAYAAQALAAAIAJQAIAJgBALQAAALgJAIQgIAGgJAAIgDAAgArjRmQgYgBgCgZQgBgLAIgIQAIgJAMAAQALAAAIAIQAJAJgBALQAAALgIAIQgHAHgKAAIgDAAgAqmRLQAAgMAIgIQAIgHAMAAQAYACABAZQABALgJAIQgJAIgOAAQgVgDgBgYgAmdRdQgIgJABgKQAEgaAXAAQAMgBAHAJQAIAJgBAOQgDAXgXAAQgMAAgIgJgApwQhQgIgIAAgMQAAgLAIgJQAIgIALAAQALAAAJAJQAIAJgBAKQgDAagXABIgCAAQgLAAgHgHgAnEQhQgHgIAAgMQAAgNAHgHQAIgIAMAAQAYABACAaQACAKgJAJQgIAJgLAAQgMAAgIgHgAq0QoQgXgBgDgZQgBgLAIgJQAIgJALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgLAAIgBAAgAluQgQgIgJAAgLQADgZAXgCQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLABQgLAAgIgIgAkWQgQgIgHAAgMQgBgLAIgIQAIgIAMAAQAXACADAZQgDAZgYABIgCAAQgKAAgGgHgAsMQnQgZgCABgZQAAgMAJgHQAIgIAMABQALABAHAJQAIAJgCALQgFAXgVAAIgDAAgAoKQnQgXgEAAgXQAAgMAIgIQAJgHALABQAXABACAaQABAKgJAIQgJAIgMAAIgBAAgAqOPpQgZgBAAgZQgBgLAJgJQAIgIALAAQALABAIAIQAIAJgBALQAAAMgIAHQgHAGgKAAIgDAAgAmePhQgIgIABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLAAQgMAAgIgIgAnzPhQgJgJABgLQAAgLAIgIQAJgIALABQAKAAAIAJQAIAJgBALQgBAXgZACQgLAAgIgIgAr2PiQgIgIAAgMQABgZAZgCQALgBAIAIQAIAIAAALQAAAZgZADIgCAAQgKAAgIgHgAo3PpQgZgDgCgYQAAgLAJgIQAJgIANAAQAWACABAYQAAAMgIAIQgHAIgKAAIgCAAgAk2PpQgMgBgGgJQgHgJABgOQADgVAZAAQALAAAIAKQAIAJgCALQgEAYgXAAIgCAAgAkFOrQgZgBgCgYQgBgMAHgIQAIgJALgBQAMAAAIAHQAIAIABAMQAAALgIAJQgHAIgLAAIgBAAgAseOjQgJgJABgKQABgZAZgDQALAAAIAIQAJAIAAALQABALgIAIQgIAJgLAAIgCAAQgKAAgIgIgAoJOqQgLAAgIgJQgIgIABgLQABgLAJgIQAJgJAKACQAZAEAAAYQAAALgIAIQgHAHgKAAIgDAAgAmzOqQgXgBgDgZQgBgKAJgJQAJgIAMAAQAYADAAAXQABAMgIAIQgHAHgKAAIgDAAgAq2OqQgZgDgBgYQAAgLAIgIQAJgIANAAQAXAEABAXQAAAMgIAIQgIAHgKAAIgCAAgApyOiQgIgJACgLQACgXAXgCQANAAAIAJQAIAIgBALQgCAYgaABIgBAAQgKAAgIgIgAluOiQgJgIAAgLQAAgKAJgJQAJgIALAAQAZADAAAYQAAAXgYAEQgMAAgJgIgAkzNtQgLgBgIgIQgIgJABgLQACgZAYAAQANAAAHAHQAIAHAAAMQAAALgJAJQgIAIgKAAIgBAAgAnyNlQgJgJAAgKQAAgLAIgIQAJgIANAAQAYABAAAXQABALgIAJQgIAJgKABIgBAAQgKAAgJgIgApHNlQgJgJAAgMQAAgXAXgCQAPgBAIAIQAJAHgBAMQAAAYgaADIgCAAQgKAAgHgHgAtLNkQgJgKABgLQAAgLAIgHQAHgHAMABQANAAAHAIQAHAHgBANQAAAYgaABIgCAAQgKAAgHgIgAr0NlQgJgIAAgMQABgZAZgBQAMgBAIAHQAIAIAAANQgBAXgYADIgEAAQgJAAgHgHgAqLNsQgZgDgCgXQAAgNAHgHQAHgIANAAQAYAAADAZQAAAMgIAJQgIAIgJAAIgCAAgAmbNjQgJgIAAgLQAAgLAIgIQAIgIAMABQAYABACAUQAAAOgIAJQgHAJgLABIgBAAQgKAAgIgJgApeMuQgLgBgIgIQgHgJAAgLQABgMAIgHQAIgHAMAAQAVACAEAXQAAANgIAJQgIAIgKAAIgCAAgAnEMlQgIgIABgMQAAgMAIgHQAHgHANAAQAXABADAaQABAKgJAJQgJAJgLAAQgLAAgIgJgAsKMtQgLAAgHgJQgIgIAAgLQADgYAYgBQAZAAABAaQABALgJAIQgIAIgJAAIgCAAgArFMlQgJgIAAgKQgBgMAIgIQAJgJALABQAZABACAYQABAKgJAKQgJAJgKAAIgBAAQgJAAgIgIgAt6MUQgBgMAHgIQAHgIAMgBQALAAAJAHQAIAHABAMQABAKgJAJQgJAJgNAAQgXgDgBgWgAoYMmQgIgJgBgLQAAgLAHgIQAHgHALgBQAMAAAIAIQAJAIgBALQAAAYgZADIgDAAQgJAAgHgHgAluMkQgIgJABgLQACgZAZAAQAMABAHAIQAIAIAAALQgEAYgYACIgCAAQgKAAgHgJgAkFMtQgXgBgDgaQAEgaAXAAQANAAAHAIQAIAIgBAMQgBAMgIAGQgHAHgKAAIgCAAgAqeLnQgJgIABgLQABgZAYgBQAMgBAJAJQAJAIgBALQAAAKgIAJQgJAIgKAAQgLAAgIgJgAuRLvQgKAAgHgJQgIgJAAgJQABgMAIgHQAJgIALAAQALABAIAIQAHAIAAALQgBALgJAIQgIAHgKAAIgCAAgAmcLnQgIgIAAgLQAAgLAIgIQAJgJAKABQAZABACAZQABALgIAIQgIAJgLAAIgCAAQgKAAgIgIgAjuLoQgIgIgBgMQAAgMAHgHQAHgHALgBQANAAAIAHQAIAIAAALQgBAZgYADIgDAAQgJAAgIgHgAs5LvQgZgBgBgZQgBgKAJgJQAIgJALAAQAXAAAEAWQAAAOgIAKQgHAIgLAAIgCAAgAlFLnQgIgIAAgMQgBgLAJgIQAIgIALABQAXAAAEAXQAAANgIAJQgIAIgLABQgLAAgIgIgAnyLnQgJgJABgKQABgZAYgCQALgBAJAHQAIAIABAMQAAALgHAIQgIAIgMAAIgBAAQgKAAgIgHgAr0LnQgJgIAAgMQAAgYAagCQALgCAIAIQAJAHAAALQABALgIAJQgHAJgMAAIgBAAQgLAAgHgHgAo1LuQgYgBgDgWQgBgMAIgJQAIgJAMAAQALgBAIAIQAIAHAAALQAAAMgIAIQgHAIgLAAIgBAAgAkaKlQgJgJAAgLQABgLAIgIQAJgIALABQAZABABAZQAAAMgHAIQgIAIgMAAQgLAAgIgIgAodKlQgIgJAAgLQAAgLAIgIQAJgIALAAQALAAAIAIQAIAIAAAMQgBALgIAIQgHAIgMAAQgLAAgIgIgAsgKlQgIgIAAgMQABgLAIgIQAIgIAMABQAZACABAZQAAALgIAIQgIAIgMAAQgLAAgIgIgAm0KtQgagDAAgYQgBgMAJgHQAJgIAQAAQAIABAGAHQAFAHABALQABAMgJAIQgHAIgKAAIgCAAgAhbKtQgXgCgDgZQgBgLAJgIQAJgIALAAQALAAAIAIQAIAIgBAMQAAAMgIAHQgHAHgLAAIgCAAgAlwKlQgIgIAAgMQABgZAZgBQAZgBADAZQABAMgIAJQgIAIgLABIgCAAQgKAAgIgIgApgKtQgYgBgDgZQgBgLAJgIQAJgIANgBQAXAEABAWQAAAMgHAIQgIAIgLAAIgBAAgAq5KsQgYgCgBgZQAAgLAJgIQAIgHAMAAQAXABACAXQgBANgIAJQgHAHgKAAIgDAAgAtjKsQgZgBgBgYQgBgMAIgHQAIgIAOgBQAVABADAYQABALgJAJQgHAIgKAAIgCAAgAixKsQgLAAgJgIQgIgJABgLQAEgZAYAAQALAAAIAIQAHAIAAAMQgBALgIAHQgHAHgKAAIgBAAgAs6JuQgMgBgHgIQgIgIABgMQACgXAZgCQALAAAIAIQAIAIAAAMQAAALgJAIQgHAHgKAAIgCAAgAk1JuQgLgBgIgIQgIgIABgLQAAgMAJgIQAJgIALACQAYADACAYQAAALgIAIQgJAIgKAAIgCAAgAnhJuQgMAAgIgIQgHgIAAgMQABgXAZgDQALgBAJAIQAIAIAAAMQAAALgIAIQgIAIgKAAIgBAAgAr3JmQgIgIAAgMQAAgLAJgIQAIgIAMAAQAYACACAZQABALgJAIQgIAJgLAAIgBAAQgLAAgIgIgApRJUQgCgKAJgJQAJgJALgBQAKAAAIAIQAIAIAAALQABAMgIAIQgHAIgMAAQgYAAgDgagAqOJtQgZgCAAgYQAAgMAJgIQAIgJALACQAZAEgBAcQAAAJgIAHQgHAFgJAAIgDAAgAhEJmQgIgIAAgLQAAgLAIgIQAJgJALAAQALAAAIAIQAIAJgBALQAAAZgaABIgCAAQgKAAgIgHgAuRJtQgZgBAAgZQgBgYAagDQALgBAIAIQAJAIAAALQAAALgIAJQgIAHgKAAIgCAAgAiaJmQgIgIAAgLQACgZAYgCQALgCAIAJQAJAJAAANQgCAWgYACIgCAAQgKAAgIgHgAjfJtQgZgBgBgaQAAgLAJgIQAJgJAKACQAMABAHAGQAHAFAAAIQgBAhgaAAIgBAAgAmlJTQAAgLAIgJQAJgIAKABQAZABABAZQABALgJAIQgIAIgNAAQgXgDgBgXgAgRIqQgIgJAAgLQABgZAYgBQALgBAIAIQAJAIgBALQgCAZgYACIgCAAQgJAAgHgHgApgIvQgXgBgDgZQAAgLAJgJQAJgJALAAQALABAHAIQAHAIAAALQAAANgIAHQgHAHgLAAIgCAAgAt1InQgIgIAAgLQACgZAYgDQALgBAJAJQAIAIABALQAAAMgHAIQgIAHgMABIgCAAQgKAAgIgIgAjDInQgIgIAAgMQAAgKAJgJQAJgJALABQAYACACAZQABAMgIAIQgIAIgMAAQgLAAgJgIgAnGImQgJgIABgLQADgYAYgDQALgBAIAJQAJAJAAALQAAAMgIAHQgHAIgNAAQgLAAgIgJgAhrIoQgIgIAAgLQgBgMAJgIQAIgJALABQAZADABAZQgBAXgYACIgDAAQgKAAgHgGgAobInQgIgIAAgLQABgYAZgDQAKgCAJAJQAIAIAAANQgBAYgYABIgCAAQgKAAgIgHgAseIoQgIgIAAgLQgBgLAJgJQAJgJAKABQAZADACAYQgDAZgWABIgCAAQgLAAgIgGgAq1IuQgYAAgCgZQgBgKAIgKQAIgJALAAQAKAAAJAIQAIAJABAKQAAAMgIAIQgHAHgLAAIgCAAgAvLInQgIgJABgLQACgYAZgBQAaACAAAYQAAAagZAAIgBAAQgMAAgIgHgAkgIUQAAgKAIgJQAJgKALACQAZAEAAAYQgBAZgbAAQgXAAgCgagAlwInQgGgHgBgMQgBgLAJgJQAJgJAKABQAZAEACAXQAAAMgIAIQgJAHgOAAQgKAAgGgHgABzHrQgIgIgBgMQAAgMAHgHQAHgIANAAQAMAAAIAIQAIAIgBALQgBAYgZADIgCAAQgJAAgIgHgAqfHqQgJgIAAgLQABgZAYgCQANgBAIAHQAIAHAAAMQABAMgIAIQgIAJgLAAIgBAAQgKAAgIgIgAiHHyQgZgDgCgXQgBgLAHgJQAIgIAMAAQANgBAHAIQAIAHAAAMQAAAMgIAIQgHAIgKAAIgCAAgAuRHxQgZgCgBgYQgBgMAIgIQAIgIAMAAQAMAAAIAIQAIAIgBALQAAAMgIAIQgIAHgKAAIgCAAgAjwHpQgJgJABgMQADgZAXAAQAMAAAIAIQAHAHAAAMQAAAZgaACIgCAAQgKAAgHgIgAAtHxQgZgDAAgYQAAgLAIgIQAIgJALABQALAAAIAJQAIAIAAALQAAALgJAIQgIAHgJAAIgDAAgAmMHxQgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAAMQAAALgJAIQgIAHgJAAIgDAAgAnzHqQgIgJAAgLQgBgLAIgIQAIgIALAAQAMAAAHAIQAIAJABANQgCAWgYACIgDAAQgJAAgIgHgAlGHpQgJgIABgLQAAgMAIgIQAIgHALAAQAXACADAZQgCAYgYADIgCAAQgKAAgHgIgAs7HxQgYgBgCgaQAAgLAIgIQAIgIAMAAQAXABADAZQABAMgJAIQgIAIgLAAIgBAAgAr+HXQAAgLAHgJQAIgIALAAQAMAAAIAIQAIAIAAALQAAAKgIAIQgJAIgLABQgYgEgCgWgApKHpQgIgJAAgLQABgYAZgCQAMgBAIAIQAIAIAAAMQAAALgIAIQgHAHgLAAIgCAAQgKAAgIgHgAhMHWQAAgLAJgIQAIgJALAAQALABAIAIQAIAJgBALQgCAZgZAAQgYgBgDgZgAgBG1QgLgBgHgJQgIgJABgLQABgLAIgHQAJgHAKAAQALABAIAJQAIAJgBAKQgBALgJAIQgIAHgJAAIgCAAgAChGrQgJgJABgLQAAgLAIgIQAJgIALAAQALABAIAIQAIAJgBALQgDAZgYABIgCAAQgKAAgHgIgAhaGzQgXgEgCgXQABgMAIgJQAIgIALABQALABAIAIQAIAJgBALQAAALgKAIQgIAHgIAAIgDAAgAseGrQgIgIgBgLQAAgLAJgJQAIgIALAAQALAAAIAIQAJAJgBALQgCAZgYACIgDAAQgJAAgIgIgAvLGrQgJgJAAgLQABgKAIgJQAJgIALAAQALABAHAIQAIAJgBANQgBAVgZADIgCAAQgJAAgIgIgAkgGZQgCgLAIgJQAIgJALAAQALgBAJAIQAIAIABAMQAAALgIAIQgJAJgMAAQgXgCgCgYgAocGpQgJgIABgLQABgLAIgIQAJgIALABQAMAAAHAIQAIAJgBAMQgCAYgYABQgMAAgJgJgApgGyQgZgDAAgZQAAgLAJgIQAJgHALABQAXADACAYQgBAMgIAHQgIAHgKAAIgCAAgAt0GqQgJgHAAgMQAAgKAJgJQAJgIAKAAQAYACACAZQgCAZgXACIgCAAQgKAAgIgIgABKGqQgJgJABgKQAAgLAJgIQAJgIALABQAXACACAZQgEAZgXABIgBAAQgKAAgIgIgAluGqQgJgIAAgLQACgYAYgDQALgBAJAIQAIAIAAAMQAAALgHAIQgIAIgKAAQgMAAgIgIgAnFGrQgIgIgBgLQAAgKAJgJQAIgJALABQAaABAAAbQgBAXgXABIgDAAQgKAAgIgGgAq2GxQgZAAgBgaQAAgLAIgIQAJgIALAAQAXACADAYQAAAMgIAIQgHAHgKAAIgDAAgAjDGqQgGgGgBgMQAAgLAIgJQAJgIALAAQAYACABAZQABAMgJAHQgIAHgOAAQgKAAgGgHgAk0FzQgZgCgBgZQAAgLAJgIQAIgIALAAQALABAIAIQAIAJAAALQgBAMgIAHQgIAHgJAAIgDgBgAo3FzQgLAAgIgJQgHgJABgLQAEgZAYAAQALAAAIAJQAIAJgBALQAAALgJAIQgIAGgJAAIgDAAgADcFzQgMAAgIgIQgHgJABgLQABgYAagBQALgBAIAIQAIAIAAAMQAAALgIAIQgIAHgKAAIgCAAgAAuFzQgYgBgBgZQgBgLAJgJQAJgIAMAAQALABAHAIQAHAHgBAMQAAALgIAIQgIAHgJAAIgDAAgArjFzQgYgBgCgZQgBgLAIgIQAIgJAMAAQALAAAIAIQAJAJgBALQAAALgIAIQgHAHgKAAIgDAAgAngFzQgLAAgIgIQgIgIAAgLQAAgLAJgIQAIgIALABQAZABABAZQABALgIAJQgIAHgKAAIgCAAgAgwFzQgYgBgDgZQgBgKAJgJQAIgIALgBQALAAAJAIQAIAIAAALQAAALgIAIQgIAIgLAAIgBAAgAtKFrQgJgIAAgNQADgXAWgCQALAAAJAHQAIAIABALQABAMgIAIQgHAIgMAAIgBAAQgLAAgHgIgAuhFrQgJgIABgLQABgZAYgCQALgBAIAIQAIAIABAOQgCAXgXACIgDAAQgJAAgIgIgAEuFzQgUgDgCgYQAAgLAIgIQAJgIALAAQALAAAIAIQAIAJgBALQAAALgJAIQgJAHgMAAIgCAAgAqQFzQgVgDgBgYQAAgMAIgIQAIgHAMAAQAYACABAZQABALgJAIQgIAIgNAAIgCAAgABrFZQAAgLAIgIQAIgJALAAQALAAAIAIQAIAJAAALQAAAMgIAHQgJAHgNAAQgWgCgCgYgAiZFrQgIgJABgLQADgaAYAAQALAAAIAJQAJAIgBALQgEAZgVABQgNAAgJgIgAj3FZQgBgLAIgIQAIgJALAAQAMgBAIAJQAIAIAAALQgBALgIAIQgJAIgOAAQgVgCgBgYgAmdFqQgIgJABgLQAEgZAXAAQAMgBAHAJQAIAJgBAOQgDAXgXAAQgMAAgIgJgAgYEcQgBgLAJgIQAIgJAKAAQALAAAIAJQAIAIgBALQgBAYgaACQgYgCgBgYgApwEuQgIgIAAgMQAAgLAIgJQAIgIALAAQALAAAJAJQAIAJgBAKQgDAagXABIgCAAQgLAAgHgHgAnEEuQgHgIAAgMQAAgNAHgHQAIgIAMAAQAYABACAaQACAKgJAJQgIAJgLAAQgMAAgIgHgABMEuQgJgIgBgLQAAgLAIgJQAJgIAKgBQAMAAAIAIQAJAIgBALQgBAagYACIgCAAQgKAAgIgHgAFhE1QgLAAgIgJQgIgIABgLQAAgMAJgIQAJgIALABQAYADABAZQABALgJAIQgIAIgKAAIgCAAgAtzEtQgHgIAAgLQAAgNAHgHQAIgIAMAAQAXABADAZQACALgJAJQgIAJgLAAIgCAAQgKAAgIgIgAq0E1QgXgBgDgZQgBgLAIgJQAIgJALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgLAAIgBAAgAjBEsQgIgIAAgMQABgLAIgIQAIgIAMABQAYACACAZQABALgJAIQgJAJgLAAQgMgBgHgIgAluEtQgIgJAAgLQADgZAXgCQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLABQgLAAgIgIgAkWEtQgIgHAAgMQgBgLAIgIQAIgIAMAAQAXACADAZQgDAZgYABIgCAAQgKAAgGgHgAChEtQgJgJABgKQADgaAYgBQAMgBAHAJQAIAIAAAOQgBAXgZAAIgCAAQgKAAgIgHgAu2E0QgZAAgBgaQAAgMAIgIQAIgHAOAAQAKABAGAHQAGAHABALQABALgIAJQgIAHgKAAIgCAAgAsME0QgZgCABgZQAAgMAJgHQAIgIAMABQALABAHAJQAIAJgCALQgFAXgVAAIgDAAgAELE0QgMAAgHgHQgHgHAAgMQAAgLAGgIQAHgHALgBQALgBAJAIQAJAIAAALQABALgIAIQgIAIgLAAIgBAAgAhrEsQgHgIAAgMQACgWAZgEQAYADADAYQABAKgIAJQgJAIgLAAQgMAAgIgIgAoKE0QgXgEAAgXQAAgMAIgIQAJgHALABQAXABACAaQABAKgJAIQgJAIgLAAIgCAAgAEhDwQgJgIAAgMQgBgLAIgJQAIgIALAAQAKAAAJAJQAKAJgBAKQgCAYgYADIgDAAQgJAAgHgHgAykDwQgJgIAAgMQgBgLAIgJQAIgIALAAQAKAAAJAJQAKAJgBAKQgCAYgYADIgDAAQgJAAgHgHgAByDvQgIgIAAgLQAAgMAJgIQAIgIALABQAXABADAXQABAMgIAJQgIAJgLAAQgMAAgIgIgAqOD2QgZgBAAgZQgBgLAJgJQAIgIALAAQALABAIAIQAIAJgBALQAAAMgIAHQgHAGgKAAIgDAAgAGID2QgLAAgJgIQgIgJABgLQAAgKAJgJQAJgIALABQAZADAAAWQAAANgIAJQgHAHgLAAIgBAAgAs7D2QgMAAgHgIQgHgJABgMQACgVAXgEQANABAIAIQAIAIAAALQgBALgIAIQgIAHgLAAIgBAAgAuQD2QgLAAgIgIQgIgIAAgLQAAgLAJgIQAIgIALAAQAZADABAYQABALgIAJQgIAHgKAAIgCAAgAw9D2QgLAAgJgIQgIgJABgLQAAgKAJgJQAJgIALABQAZADAAAWQAAANgIAJQgHAHgLAAIgBAAgAiaDuQgJgIABgLQAAgLAJgIQAIgIALAAQAMABAHAIQAIAIgBAMQgCAYgZABIgBAAQgKAAgIgIgAjwDuQgJgJABgKQABgaAZgBQALAAAJAIQAIAIgBALQgBAagYABIgBAAQgLAAgIgIgAmeDuQgIgIABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLAAQgMAAgIgIgAnzDuQgJgJABgLQAAgLAIgIQAJgIALABQAKAAAIAJQAIAJgBALQgBAXgZACQgLAAgIgIgAwBDcQAAgLAIgJQAIgIALAAQAMAAAIAIQAHAIgBANQAAAWgaADQgZgDgCgXgAAuD2QgZgCgBgZQAAgLAIgIQAIgJALABQALAAAIAJQAIAIAAALQAAALgIAIQgIAHgKAAIgCAAgAr2DvQgIgIAAgMQABgZAZgCQALgBAIAIQAIAIAAALQAAAZgZADIgCAAQgKAAgIgHgAo3D2QgZgDgCgYQAAgLAJgIQAJgIANAAQAWACABAYQAAAMgIAIQgHAIgKAAIgCAAgAk2D2QgMgBgGgJQgHgJABgOQADgVAZAAQALAAAIAKQAIAJgCALQgEAYgXAAIgCAAgADJDuQgIgJAAgLQABgXAXgDQANAAAIAIQAJAIgBALQgCAagYABIgBAAQgKAAgIgIgAhEDuQgHgHAAgMQgBgMAJgIQAIgIAMABQAMAAAHAIQAHAIgBANQgCAYgaAAQgMAAgGgHgAgSCyQgIgJAAgLQABgMAIgIQAIgIALABQAXACADAZQABALgJAIQgJAJgLAAQgKAAgIgIgAEIC4QgYgDgBgYQgBgMAJgIQAIgIALAAQALAAAIAJQAIAIAAALQgBAMgIAIQgIAHgJAAIgDAAgAy9C4QgYgDgBgYQgBgMAJgIQAIgIALAAQALAAAIAJQAIAIAAALQgBAMgIAIQgIAHgJAAIgDAAgAC0C4QgZgCgCgYQgBgKAIgJQAIgJALAAQALgBAIAIQAIAIABALQAAAMgIAIQgHAIgKAAIgCAAgA0RC4QgZgCgCgYQgBgKAIgJQAIgJALAAQALgBAIAIQAIAIABALQAAAMgIAIQgHAIgKAAIgCAAgAH6CwQgJgJABgLQACgYAYgDQALAAAIAIQAIAJABANQgBAWgZADIgCAAQgKAAgIgIgAvLCwQgJgJABgLQACgYAYgDQALAAAIAIQAIAJABANQgBAWgZADIgCAAQgKAAgIgIgAkFC4QgZgBgCgYQgBgMAHgIQAIgJALgBQAMAAAIAHQAIAIABAMQAAALgIAJQgHAIgLAAIgBAAgAseCwQgJgJABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgIAIQgIAJgLAAIgCAAQgKAAgIgIgAO8C3QgLAAgIgJQgIgIABgLQABgLAJgIQAJgJAKACQAZAEAAAYQAAALgIAIQgHAHgKAAIgDAAgAhqCwQgJgIABgLQABgZAXgDQALAAAJAIQAJAIAAALQgBAZgYACIgDAAQgJAAgIgHgAoJC3QgLAAgIgJQgIgIABgLQABgLAJgIQAJgJAKACQAZAEAAAYQAAALgIAIQgHAHgKAAIgDAAgAG3C3QgZgBgCgYQgBgLAIgJQAIgJALAAQALgBAIAIQAJAJAAALQAAAMgHAIQgHAHgKAAIgDAAgAmzC3QgXgBgDgZQgBgKAJgJQAJgIAMAAQAYADAAAXQABAMgIAIQgHAHgKAAIgDAAgAq2C3QgZgDgBgYQAAgLAIgIQAJgIANAAQAXAEABAXQAAAMgIAIQgIAHgKAAIgCAAgAwOC3QgZgBgCgYQgBgLAIgJQAIgJALAAQALgBAIAIQAJAJAAALQAAAMgHAIQgHAHgKAAIgDAAgAFOCvQgIgIAAgLQACgZAYgBQAMAAAIAIQAIAIgBALQgCAYgWACIgCAAQgLAAgIgIgAx3CvQgIgIAAgLQACgZAYgBQAMAAAIAIQAIAIgBALQgCAYgWACIgCAAQgLAAgIgIgApyCvQgIgJACgLQACgXAXgCQANAAAIAJQAIAIgBALQgCAYgaABIgBAAQgKAAgIgIgABDCaQACgaAaADQAMABAHAIQAHAIgCAMQgDAWgaABQgagFADgYgAluCvQgJgIAAgLQAAgKAJgJQAJgIALAAQAZACAAAZQAAAXgYAEQgMAAgJgIgAiwC3QgLgBgHgIQgIgIABgMQACgXAYgCQAKAAAJAJQAIAJgBALQAAAKgIAIQgIAHgJAAIgCAAgAt0CvQgJgJABgKQACgYAZgCQAaADAAAXQABAZgbACIgCAAQgKAAgHgIgAHfB6QgKgBgJgJQgIgKABgJQAEgZAXAAQAMAAAIAHQAHAIAAAMQAAALgJAIQgHAIgLAAIgBAAgAvmB6QgKgBgJgJQgIgKABgJQAEgZAXAAQAMAAAIAHQAHAIAAAMQAAALgJAIQgHAIgLAAIgBAAgAkzB6QgLgBgIgIQgIgJABgLQACgZAYAAQANAAAHAHQAIAHAAAMQAAALgJAJQgIAIgKAAIgBAAgAnyByQgJgJAAgKQAAgLAIgIQAJgIANAAQAYABAAAXQABALgIAJQgIAJgKABIgBAAQgKAAgJgIgAN+ByQgJgJAAgMQAAgXAXgCQAPgBAIAIQAJAHgBAMQAAAYgaADIgCAAQgKAAgHgHgApHByQgJgJAAgMQAAgXAXgCQAPgBAIAIQAJAHgBAMQAAAYgaADIgCAAQgKAAgHgHgAtLBxQgJgKABgLQAAgLAIgHQAHgHAMABQANAAAHAIQAHAHgBAMQAAAZgaABIgCAAQgKAAgHgIgAI2B5QgLAAgIgKQgJgJABgLQAEgYAZAAQAZACAAAYQAAAMgIAIQgIAIgKAAIgBAAgAAvB5QgLAAgIgJQgIgJAAgLQABgLAKgHQAJgHAOABQAUACAAAXQAAAMgIAIQgIAIgKAAIgBAAgAuPB5QgLAAgIgKQgJgJABgLQAEgYAZAAQAZACAAAYQAAAMgIAIQgIAIgKAAIgBAAgAEyB5QgZgEAAgXQAAgMAIgHQAJgIAOAAQAWADAAAYQABALgJAJQgIAHgJAAIgDAAgAgwB5QgMgCgHgHQgIgHABgLQABgaAZgBQAMAAAIAIQAIAHAAAMQAAALgJAJQgHAHgJAAIgDAAgAr0ByQgJgIAAgMQABgZAZgBQAMgBAIAHQAIAIAAANQgBAXgYADIgEAAQgJAAgHgHgAyTB5QgZgEAAgXQAAgMAIgHQAJgIAOAAQAWADAAAYQABALgJAJQgIAHgJAAIgDAAgACGB5QgZgDgBgYQgBgLAIgIQAIgIAMAAQAYABACAWQAAAOgIAJQgHAIgJAAIgDAAgADLBzQgIgHgBgMQgBgLAIgJQAIgIALAAQAMgBAIAIQAJAJgBALQAAAMgIAHQgHAGgLABIgDAAQgKAAgGgGgAz6BzQgIgHgBgMQgBgLAIgJQAIgIALAAQAMgBAIAIQAJAJgBALQAAAMgIAHQgHAGgLABIgDAAQgKAAgGgGgAqLB5QgZgDgCgXQAAgNAHgIQAHgHANAAQAYAAADAZQAAAMgIAJQgIAIgJAAIgCAAgAF3BwQgIgJAAgOQADgWAYAAQALAAAJAJQAIAIgBALQgCAXgZADIgCAAQgKAAgHgJgAxOBwQgIgJAAgOQADgWAYAAQALAAAJAJQAIAIgBALQgCAXgZADIgCAAQgKAAgHgJgAiYBxQgIgJAAgMQABgXAYgCQAaAAADAZQABAJgJAKQgJAJgKABIgBAAQgKAAgIgIgAjdB5QgZgCgBgZQAAgYAZgDQALgBAJAIQAIAHABAMQAAAKgIAJQgIAJgLAAIgBAAgAmbBwQgJgIAAgLQAAgMAIgHQAIgIAMABQAYABACAUQAAAOgIAJQgHAJgLABIgBAAQgKAAgIgJgAABA7QgYgBgBgZQgBgLAJgIQAIgIAMAAQAXADABAXQABAMgIAIQgHAHgKAAIgDAAgAFhA7QgKgBgJgIQgIgJABgLQACgZAZgBQALAAAJAIQAIAIgBAMQAAALgIAIQgIAIgKAAIgCAAgAxkA7QgKgBgJgIQgIgJABgLQACgZAZgBQALAAAJAIQAIAIgBAMQAAALgIAIQgIAIgKAAIgCAAgANnA7QgLgBgIgIQgHgJAAgLQABgMAIgHQAIgHAMAAQAVACAEAXQAAANgIAJQgIAIgKAAIgCAAgApeA7QgLgBgIgIQgHgJAAgLQABgMAIgHQAIgHAMAAQAVACAEAXQAAANgIAJQgIAIgKAAIgCAAgABeA7QgLgBgIgIQgJgJABgLQAAgLAIgHQAJgIALAAQAMAAAHAIQAIAIgBAMQAAALgIAIQgIAIgKAAIgBAAgAChAxQgJgKACgJQAEgYAWgBQAaABABAZQAAAKgJAJQgIAJgKAAQgKgBgJgJgAnEAyQgIgIABgMQAAgMAIgHQAHgHANAAQAXABADAaQABAKgJAJQgJAJgLAAQgLAAgIgJgA0kAxQgJgKACgJQAEgYAWgBQAaABABAZQAAAKgJAJQgIAJgKAAQgKgBgJgJgAsKA6QgLAAgHgJQgIgIAAgLQADgYAYgBQAZAAABAaQABALgJAIQgIAIgJAAIgCAAgAIPA6QgLAAgIgIQgIgJABgLQACgYAZgBQALAAAIAIQAJAJgBALQgBAKgIAIQgIAHgKAAIgBAAgAu2A6QgLAAgIgIQgIgJABgLQACgYAZgBQALAAAIAIQAJAJgBALQgBAKgIAIQgIAHgKAAIgBAAgArFAyQgJgIAAgKQgBgMAIgIQAJgJALABQAZABACAYQABAKgJAKQgJAJgKAAIgBAAQgJAAgIgIgAjBAyQgIgIAAgMQABgMAIgHQAJgIANABQAVABADAZQABALgJAIQgJAJgKAAQgLAAgJgIgAt6AhQgBgMAHgIQAHgIAMgBQALAAAJAHQAIAHABAMQABAKgJAJQgJAJgNAAQgXgDgBgWgAOtAzQgIgJgBgLQAAgLAHgIQAHgHALgBQAMAAAIAIQAJAIgBALQAAAYgZADIgDAAQgJAAgHgHgAhZA6QgYgEgBgWQABgNAIgIQAIgIAMABQAZADAAAZQAAALgJAIQgIAHgJAAIgDAAgAoYAzQgIgJgBgLQAAgLAHgIQAHgHALgBQAMAAAIAIQAJAIgBALQAAAYgZADIgDAAQgJAAgHgHgAluAxQgIgJABgLQACgZAZAAQAMABAHAIQAIAIAAALQgEAYgYACIgCAAQgKAAgHgJgAkFA6QgXgBgDgaQAEgaAXAAQANAAAHAIQAIAIgBAMQgBAMgIAGQgHAHgKAAIgCAAgAD4AxQgJgJABgKQACgMAGgHQAGgGAJAAQAPAAAJAIQAIAHgBAMQgCAZgZABIgBAAQgKAAgIgJgAzNAxQgJgJABgKQACgMAGgHQAGgGAJAAQAPAAAJAIQAIAHgBAMQgCAZgZABIgBAAQgKAAgIgJgAGeAgQAAgaAZgBQAMgBAIAIQAJAIgBALQgCAYgZADQgagEAAgWgAwnAgQAAgaAZgBQAMgBAIAIQAJAIgBALQgCAYgZADQgagEAAgWgACFgCQgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAALQgBALgIAJQgIAHgJAAIgDAAgA1AgCQgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAALQgBALgIAJQgIAHgJAAIgDAAgAMngLQgJgIABgLQABgZAYgBQAMgBAJAJQAJAIgBALQAAAKgIAJQgJAIgKAAQgLAAgIgJgAEggNQgIgKABgLQACgWAXABQANAAAIAHQAIAIAAALQAAAKgIAJQgJAIgLAAQgKgBgJgKgAqegLQgJgIABgLQABgZAYgBQAMgBAJAJQAJAIgBALQAAAKgIAJQgJAIgKAAQgLAAgIgJgAylgNQgIgKABgLQACgWAXABQANAAAIAHQAIAIAAALQAAAKgIAJQgJAIgLAAQgKgBgJgKgAF4gKQgJgIAAgLQgBgLAIgJQAIgIALAAQAZABADAYQAAALgHAJQgIAJgLAAIgCAAQgKAAgHgHgAxNgKQgJgIAAgLQgBgLAIgJQAIgIALAAQAZABADAYQAAALgHAJQgIAJgLAAIgCAAQgKAAgHgHgAuRgDQgKAAgHgJQgIgJAAgJQABgMAIgHQAJgIALAAQALABAIAIQAHAIAAALQgBALgJAIQgIAHgKAAIgCAAgAmcgLQgIgIAAgLQAAgLAIgIQAJgJAKABQAZABACAZQABALgIAIQgIAJgLAAIgCAAQgKAAgIgIgAiggcQgBgLAIgJQAIgJALAAQAYAAAEAaQABALgIAIQgIAJgMAAQgZgCgCgXgAjugKQgIgIgBgMQAAgMAHgHQAHgIALAAQANAAAIAHQAIAIAAALQgBAZgYADIgDAAQgJAAgIgHgAs5gDQgZgBgBgZQgBgKAJgJQAIgJALAAQAXAAAEAWQAAAOgIAKQgHAIgLAAIgCAAgAAdgMQgJgJABgLQACgYAXgBQAMgBAIAJQAJAIAAAOQgCAWgYACIgBAAQgLAAgIgJgAHNgMQgJgJABgKQADgZAYgBQALgBAIAIQAIAHAAALQAAAMgHAJQgIAIgMAAQgLAAgIgJgAlFgLQgIgIAAgMQgBgLAJgIQAIgIALABQAXAAAEAXQAAANgIAJQgIAIgLABQgLAAgIgIgAv4gMQgJgJABgKQADgZAYgBQALgBAIAIQAIAHAAALQAAAMgHAJQgIAIgMAAQgLAAgIgJgADcgEQgLAAgIgJQgIgKABgNQADgUAZgBQAJgBAIAJQAJAJgBAKQAAAKgJAJQgHAHgJAAIgCAAgAzpgEQgLAAgIgJQgIgKABgNQADgUAZgBQAJgBAIAJQAJAJgBAKQAAAKgJAJQgHAHgJAAIgCAAgAPTgLQgJgJABgLQABgYAYgCQALgBAJAHQAIAIABAMQAAALgHAIQgIAIgMAAIgBAAQgKAAgIgHgAnygLQgJgJABgLQABgYAYgCQALgBAJAHQAIAIABAMQAAALgHAIQgIAIgMAAIgBAAQgKAAgIgHgAr0gLQgJgIAAgMQAAgYAagCQALgCAIAIQAJAHAAALQABALgIAJQgHAJgMAAIgBAAQgLAAgHgHgAOQgEQgYgBgDgWQgBgMAIgJQAIgJAMAAQALgBAIAIQAIAHAAALQAAAMgIAIQgHAIgLAAIgBAAgAo1gEQgYgBgDgWQgBgMAIgJQAIgJAMAAQALgBAIAIQAIAHAAALQAAAMgIAIQgHAIgLAAIgBAAgAhDgNQgIgIABgLQAAgKAIgIQAJgIALAAQAZADABAXQAAAMgIAIQgHAIgMAAQgLAAgJgJgAgChEQgMgBgHgIQgIgIACgMQACgYAZgBQAKgBAIAKQAIAJAAALQgBALgIAHQgHAHgKAAIgCAAgAILhFQgYgBgDgZQAAgLAIgJQAIgIAMAAQALAAAIAIQAIAIAAALQgBAMgIAIQgHAHgKAAIgCAAgAu6hFQgYgBgDgZQAAgLAIgJQAIgIAMAAQALAAAIAIQAIAIAAALQgBAMgIAIQgHAHgKAAIgCAAgAOohNQgIgJAAgLQAAgLAIgIQAJgIALAAQALAAAIAIQAIAIAAAMQgBALgIAIQgHAIgMAAQgLAAgIgIgACfhNQgIgIABgMQABgZAZgBQALgBAIAJQAIAIAAAMQAAALgIAHQgIAIgKAAQgMAAgIgIgAkahNQgJgJAAgLQABgLAIgIQAJgIALABQAZABABAZQAAAMgHAIQgIAIgMAAQgLAAgIgIgAodhNQgIgJAAgLQAAgLAIgIQAJgIALAAQALAAAIAIQAIAIAAAMQgBALgIAIQgHAIgMAAQgLAAgIgIgAsghNQgIgIAAgMQABgLAIgIQAIgIAMABQAZABABAaQAAALgIAIQgIAIgMAAQgLAAgIgIgA0mhNQgIgIABgMQABgZAZgBQALgBAIAJQAIAIAAAMQAAALgIAHQgIAIgKAAQgMAAgIgIgAQRhFQgagDAAgYQgBgMAJgHQAJgIAQAAQAIABAGAHQAFAHABALQABAMgJAIQgHAIgKAAIgCAAgAG1hFQgYgBgDgZQAAgMAIgIQAHgIAMAAQAMgBAIAIQAHAIAAAMQABALgIAIQgIAIgKAAIgCAAgABahFQgZgEAAgZQADgXAXgCQAMAAAIAIQAIAHgBAMQAAALgIAIQgIAIgKAAIgCAAgAm0hFQgagDAAgYQgBgMAJgHQAJgIAQAAQAIABAGAHQAFAHABALQABAMgJAIQgHAIgKAAIgCAAgAwQhFQgYgBgDgZQAAgMAIgIQAHgIAMAAQAMgBAIAIQAHAIAAAMQABALgIAIQgIAIgKAAIgCAAgAhbhFQgXgCgDgZQgBgLAJgIQAJgIALAAQALAAAIAIQAIAIgBAMQAAAMgIAHQgHAHgLAAIgCAAgAD2hNQgJgHAAgLQgBgMAJgIQAIgIANgBQAXADABAXQABAMgHAIQgHAJgMAAIgBAAQgKAAgIgIgAzPhNQgJgHAAgLQgBgMAJgIQAIgIANgBQAXADABAXQABAMgHAIQgHAJgMAAIgBAAQgKAAgIgIgANlhFQgYgBgDgZQgBgLAJgIQAJgJANAAQAXAEABAWQAAAMgHAIQgIAIgLAAIgBAAgAlwhNQgIgIAAgMQABgZAZgBQAZgBADAZQABAMgIAJQgIAIgLABIgBAAQgLAAgIgIgApghFQgYgBgDgZQgBgLAJgIQAJgJANAAQAXAEABAWQAAAMgHAIQgIAIgLAAIgBAAgAFMhMQgHgHgBgMQgBgKAJgJQAJgJAKAAQAMABAHAHQAIAIgBAMQAAANgIAGQgHAHgLAAQgMAAgHgHgAx5hMQgHgHgBgMQgBgKAJgJQAJgJAKAAQAMABAHAHQAIAIgBAMQAAANgIAGQgHAHgLAAQgMAAgHgHgAq5hGQgYgCgBgZQAAgLAJgIQAIgHAMAAQAXABACAXQgBANgIAJQgHAHgKAAIgDAAgAtjhGQgZgBgBgYQgBgMAIgHQAIgIAOgBQAVABADAYQABALgJAJQgHAIgKAAIgCAAgAixhGQgLAAgJgIQgIgJABgLQAEgZAYAAQALAAAIAIQAHAIAAAMQgBALgIAHQgHAHgKAAIgBAAgAHLiMQgIgIAAgLQACgZAZgCQALgBAIAIQAJAIAAALQAAAMgIAIQgHAIgMAAIgCAAQgKAAgIgIgAv6iMQgIgIAAgLQACgZAZgCQALgBAIAIQAJAIAAALQAAAMgIAIQgHAIgMAAIgCAAQgKAAgIgIgABziLQgIgIAAgMQgBgWAagFQAKgBAJAJQAJAIAAAMQgDAYgXACIgCAAQgKAAgHgHgAAsiEQgYgDgBgYQAAgMAIgIQAIgIAMABQALAAAIAIQAIAJgBALQAAALgJAIQgIAHgJAAIgDAAgAs6iEQgMgBgHgIQgIgIABgMQACgYAZgBQALAAAIAIQAIAIAAAMQAAALgJAIQgHAHgKAAIgCAAgAPkiEQgMAAgIgIQgHgIAAgMQABgXAZgDQALgBAJAIQAIAIAAAMQAAALgIAIQgIAIgKAAIgBAAgAk1iEQgLgBgIgIQgIgIABgLQAAgMAJgIQAJgIALACQAYADACAYQAAALgIAIQgJAIgKAAIgCAAgAnhiEQgMAAgIgIQgHgIAAgMQABgXAZgDQALgBAJAIQAIAIAAAMQAAALgIAIQgIAIgKAAIgBAAgADIiMQgIgIAAgMQAAgLAJgIQAJgJAKACQAZACACAWQAAAMgJAJQgIAJgLAAIgBAAQgKAAgIgIgAr3iMQgIgIAAgMQAAgLAJgIQAIgIAMAAQAYACACAZQABALgJAIQgIAJgLAAIgBAAQgLAAgIgIgAN0ieQgCgKAJgJQAJgJALgBQAKAAAIAIQAIAIAAALQABAMgIAIQgHAIgMAAQgYAAgDgagAEeiMQgIgIABgMQABgXAZgDQALgBAJAJQAIAIgBAMQgBAXgZADQgMAAgIgIgApRieQgCgKAJgJQAJgJALgBQAKAAAIAIQAIAIAAALQABAMgIAIQgHAIgMAAQgYAAgDgagAqOiFQgZgCAAgYQAAgMAJgIQAIgJALACQAZAEgBAcQAAAJgIAHQgHAFgJAAIgDAAgAhEiMQgIgIAAgLQAAgLAIgIQAJgJALAAQALAAAIAIQAIAJgBALQAAAZgaABIgCAAQgKAAgIgHgAuRiFQgZgBAAgZQgBgYAagDQALgBAIAIQAJAIAAALQAAALgIAJQgIAHgKAAIgCAAgAiaiMQgIgIAAgLQACgZAYgCQALgCAIAJQAJAJAAANQgCAWgYACIgCAAQgKAAgIgHgAGIiFQgZgBgCgZQAAgKAJgJQAJgJAKAAQAKAAAIAJQAIAIAAAKQAAAMgHAIQgIAHgLAAIgBAAgAw9iFQgZgBgCgZQAAgKAJgJQAJgJAKAAQAKAAAIAJQAIAIAAAKQAAAMgHAIQgIAHgLAAIgBAAgAjfiFQgZgBgBgaQAAgLAJgIQAJgJAKACQAMABAHAGQAHAFAAAIQgBAhgaAAIgBAAgAQgifQAAgLAIgJQAJgIAKABQAZABABAZQABALgJAIQgIAIgNAAQgXgDgBgXgAmlifQAAgLAIgJQAJgIAKABQAZABABAZQABALgJAIQgIAIgNAAQgXgDgBgXgAgRjIQgIgJAAgLQABgZAYgBQALgBAIAIQAJAIgBALQgCAZgYACIgCAAQgJAAgHgHgANljDQgXgBgDgZQAAgLAJgJQAJgJALAAQALABAHAIQAHAIAAALQAAANgIAHQgHAHgLAAIgCAAgApgjDQgXgBgDgZQAAgLAJgJQAJgJALAAQALABAHAIQAHAIAAALQAAANgIAHQgHAHgLAAIgCAAgAt1jLQgIgIAAgLQACgZAYgDQALgBAJAJQAIAIABALQAAAMgHAIQgIAHgMABIgCAAQgKAAgIgIgAFFjbQgCgLAKgKQAKgKAKABQAZACACAYQAAAMgHAIQgIAIgMAAIgBAAQgXAAgEgYgAyAjbQgCgLAKgKQAKgKAKABQAZACACAYQAAAMgHAIQgIAIgMAAIgBAAQgXAAgEgYgAP/jMQgJgIABgLQADgYAYgDQALgBAIAJQAJAJAAALQAAAMgIAHQgHAIgNAAQgLAAgIgJgABJjLQgIgJAAgLQACgXAZgEQALgBAIAJQAJAIAAAMQAAAMgHAHQgIAIgNAAQgLAAgIgIgAjDjLQgIgIAAgMQAAgKAJgJQAJgJALABQAYACACAZQABALgIAJQgIAIgMAAQgLAAgJgIgAnGjMQgJgIABgLQADgYAYgDQALgBAIAJQAJAJAAALQAAAMgIAHQgHAIgNAAQgLAAgIgJgAOqjLQgIgIAAgLQABgYAZgDQAKgCAJAJQAIAIAAANQgBAYgYABIgCAAQgKAAgIgHgAobjLQgIgIAAgLQABgYAZgDQAKgCAJAJQAIAIAAANQgBAYgYABIgCAAQgKAAgIgHgAKnjKQgIgIAAgLQgBgLAJgJQAJgJAKABQAZADACAYQgDAZgWABIgCAAQgLAAgIgGgACsjEQgIAAgFgHQgGgHgBgMQAAgKAIgJQAJgIALAAQALABAIAJQAIAIgBALQgBAMgIAGQgJAGgOAAIgCAAgAsejKQgIgIAAgLQgBgLAJgJQAJgJAKABQAZADACAYQgDAZgWABIgCAAQgLAAgIgGgAMQjEQgYAAgCgZQgBgKAIgKQAIgJALAAQAKAAAJAIQAIAJABAKQAAAMgIAIQgHAHgLAAIgCAAgAH6jLQgIgJABgLQACgYAZgBQAaACAAAYQAAAagZAAIgBAAQgMAAgIgHgAq1jEQgYAAgCgZQgBgKAIgKQAIgJALAAQAKAAAJAIQAIAJABAKQAAAMgIAIQgHAHgLAAIgCAAgAvLjLQgIgJABgLQACgYAZgBQAaACAAAYQAAAagZAAIgBAAQgMAAgIgHgAkgjeQAAgKAIgJQAJgKALACQAZAEAAAYQgBAZgbAAQgXAAgCgagAlwjLQgGgHgBgMQgBgLAJgJQAJgJAKABQAZAEACAXQAAAMgIAIQgJAHgOAAQgKAAgGgHgAhrjKQgIgIAAgLQgBgMAJgIQAIgJALABQAZACABAaQgBAXgYACIgDAAQgKAAgHgGgAGljLQgJgHgBgLQAAgKAIgJQAJgJALAAQAKgBAIAIQAIAIAAALQgBAZgXACIgDAAQgKAAgHgHgAwgjLQgJgHgBgLQAAgKAIgJQAJgJALAAQAKgBAIAIQAIAIAAALQgBAZgXACIgDAAQgKAAgHgHgAEJjEQgZgBgBgZQgBgKAJgJQAJgJAKABQAZADACAWQAAANgIAIQgHAHgKAAIgDAAgABzkHQgIgIgBgMQAAgMAHgHQAHgIANAAQAMAAAIAIQAIAHgBAMQgBAYgZADIgCAAQgJAAgIgHgAMmkIQgJgIAAgLQABgZAYgCQANgBAIAHQAIAHAAAMQABAMgIAIQgIAJgLAAQgLAAgIgIgAqfkIQgJgIAAgLQABgZAYgCQANgBAIAHQAIAHAAAMQABAMgIAIQgIAJgLAAQgLAAgIgIgAF2kIQgJgIAAgLQgBgLAIgIQAIgJAMABQAYABADAZQgBAYgYADIgDAAQgJAAgIgHgAxPkIQgJgIAAgLQgBgLAIgIQAIgJAMABQAYABADAZQgBAYgYADIgDAAQgJAAgIgHgAiHkBQgZgBgCgYQgBgLAHgJQAIgIAMAAQANgBAHAIQAIAHAAAMQAAAMgIAIQgHAHgKAAIgCAAgAuRkBQgZgCgBgYQgBgMAIgIQAIgIAMAAQAMAAAIAIQAIAIgBALQAAAMgIAIQgIAHgJAAIgDAAgAjwkJQgJgJABgMQADgZAXAAQAMAAAIAIQAHAHAAAMQAAAZgaACIgCAAQgKAAgHgIgAEfkJQgIgJAAgMQABgLAJgHQAIgHAMABQAaADgCAZQgCAZgZAAIgBAAQgLAAgHgIgAymkJQgIgJAAgMQABgLAJgHQAIgHAMABQAaADgCAZQgCAZgZAAIgBAAQgLAAgHgIgAQ5kBQgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAAMQAAALgJAIQgIAHgJAAIgDAAgAPSkIQgIgJAAgLQgBgLAIgIQAIgJALABQAMAAAHAIQAIAJABANQgCAVgYADIgDAAQgJAAgIgHgAAtkBQgZgDAAgYQAAgLAIgIQAIgJALABQALAAAIAJQAIAIAAALQAAALgJAIQgIAHgJAAIgDAAgAmMkBQgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAAMQAAALgJAIQgIAHgJAAIgDAAgAnzkIQgIgJAAgLQgBgLAIgIQAIgJALABQAMAAAHAIQAIAJABANQgCAVgYADIgDAAQgJAAgIgHgAHMkJQgJgIABgLQACgYAVgDQAOAAAIAIQAJAIgBALQAAAZgZACIgDAAQgJAAgIgIgAlGkJQgJgIABgLQAAgMAIgIQAIgHALAAQAXACADAZQgCAYgYADIgCAAQgKAAgHgIgAv5kJQgJgIABgLQACgYAVgDQAOAAAIAIQAJAIgBALQAAAZgZACIgDAAQgJAAgIgIgAKKkBQgYgBgCgaQAAgLAIgIQAIgIAMAAQAXABADAZQABALgJAJQgIAIgLAAIgBAAgAs7kBQgYgBgCgaQAAgLAIgIQAIgIAMAAQAXABADAZQABALgJAJQgIAIgLAAIgBAAgALHkbQAAgLAHgJQAIgIALAAQAMAAAIAIQAIAIAAALQAAAKgIAIQgJAIgLABQgYgEgCgWgADBkdQABgZAZgBQAMAAAIAIQAIAJgBALQgCAWgaAEQgagEABgYgAr+kbQAAgLAHgJQAIgIALAAQAMAAAIAIQAIAIAAALQAAAKgIAIQgJAIgLABQgYgEgCgWgAN7kJQgIgJAAgLQABgYAZgCQAMgBAIAIQAIAIAAAMQAAALgIAIQgHAHgLAAIgCAAQgKAAgIgHgApKkJQgIgJAAgLQABgYAZgCQAMgBAIAIQAIAIAAAMQAAALgIAIQgHAHgLAAIgCAAQgKAAgIgHgAhMkcQAAgLAJgIQAIgJALAAQALABAIAIQAIAJgBALQgCAZgZAAQgYgBgDgZgAgBk9QgLgBgHgJQgIgJABgLQABgLAIgHQAJgHAKAAQALABAIAJQAIAJgBAKQgBALgJAIQgIAHgJAAIgCAAgAChlHQgJgJABgLQAAgLAIgIQAJgIALAAQALABAIAIQAIAJgBALQgDAZgYABIgCAAQgKAAgHgIgAhak/QgXgEgCgXQABgNAIgIQAIgIALABQALABAIAIQAIAJgBALQAAALgKAIQgIAHgIAAIgDAAgAKnlHQgIgIgBgLQAAgLAJgJQAIgIALAAQALAAAIAIQAJAJgBALQgCAZgYACIgDAAQgJAAgIgIgAselHQgIgIgBgLQAAgLAJgJQAIgIALAAQALAAAIAIQAJAJgBALQgCAZgYACIgDAAQgJAAgIgIgAH6lHQgJgJAAgLQABgKAIgJQAJgIALAAQALABAHAIQAIAJgBANQgBAVgZADIgCAAQgJAAgIgIgAvLlHQgJgJAAgLQABgKAIgJQAJgIALAAQALABAHAIQAIAJgBANQgBAVgZADIgCAAQgJAAgIgIgAkglZQgCgLAIgJQAIgJALAAQALgBAJAIQAIAIABAMQAAALgIAIQgJAIgMABQgXgCgCgYgAG2lAQgLAAgIgJQgIgIABgLQAAgLAJgIQAJgIALABQAYADABAZQAAALgIAIQgIAHgKAAIgCAAgAwPlAQgLAAgIgJQgIgIABgLQAAgLAJgIQAJgIALABQAYADABAZQAAALgIAIQgIAHgKAAIgCAAgAEJlAQgLAAgIgIQgIgIAAgMQABgLAIgIQAJgIALABQAYACABAZQABAMgIAIQgIAHgKAAIgCAAgAy8lAQgLAAgIgIQgIgIAAgMQABgLAIgIQAJgIALABQAYACABAZQABAMgIAIQgIAHgKAAIgCAAgAOplJQgJgIABgLQABgLAIgIQAJgIALABQAMAAAHAIQAIAJgBAMQgCAYgYABQgMAAgJgJgAoclJQgJgIABgLQABgLAIgIQAJgIALABQAMAAAHAIQAIAJgBAMQgCAYgYABQgMAAgJgJgANllAQgZgDAAgZQAAgLAJgIQAJgHALABQAXADACAYQgBAMgIAHQgIAHgKAAIgCAAgApglAQgZgDAAgZQAAgLAJgIQAJgHALABQAXADACAYQgBAMgIAHQgIAHgKAAIgCAAgAFGlaQgBgLAIgIQAIgIAMAAQALAAAHAIQAIAIAAALQgCAagYAAIgCAAQgXAAgCgagAx/laQgBgLAIgIQAIgIAMAAQALAAAHAIQAIAIAAALQgCAagYAAIgCAAQgXAAgCgagAJRlIQgJgIAAgLQAAgKAJgJQAJgIAKAAQAYACACAZQgCAZgXACIgCAAQgKAAgIgIgAt0lIQgJgIAAgLQAAgKAJgJQAJgIAKAAQAYACACAZQgCAZgXACIgCAAQgKAAgIgIgABKlIQgJgJABgKQAAgLAJgIQAJgIALABQAXACACAZQgEAZgXABIgBAAQgKAAgIgIgARXlIQgJgIAAgLQACgYAYgDQALgBAJAIQAIAIAAAMQAAALgHAIQgIAIgKAAQgMAAgIgIgAlulIQgJgIAAgLQACgYAYgDQALgBAJAIQAIAIAAAMQAAALgHAIQgIAIgKAAQgMAAgIgIgAQAlHQgIgIgBgLQAAgKAJgJQAIgJALABQAaABAAAbQgBAXgXABIgDAAQgKAAgIgGgAnFlHQgIgIgBgLQAAgKAJgJQAIgJALABQAaABAAAbQgBAXgXABIgDAAQgKAAgIgGgAMPlBQgZAAgBgaQAAgLAIgIQAJgIALAAQAXACADAYQAAAMgIAIQgHAHgKAAIgDAAgAq2lBQgZAAgBgaQAAgLAIgIQAJgIALAAQAXACADAYQAAAMgIAIQgHAHgKAAIgDAAgAjDlIQgGgGgBgMQAAgLAIgJQAJgIALAAQAYACABAZQABAMgJAHQgIAHgOAAQgKAAgGgHgASRl/QgZgCgBgZQAAgLAJgIQAIgIALAAQALABAIAIQAIAJAAALQgBAMgIAHQgIAHgJAAIgDgBgAk0l/QgZgCgBgZQAAgLAJgIQAIgIALAAQALABAIAIQAIAJAAALQgBAMgIAHQgIAHgJAAIgDgBgAOOl/QgLAAgIgJQgHgJABgLQAEgZAYAAQALAAAIAJQAIAJgBALQAAALgJAIQgIAGgJAAIgDAAgAo3l/QgLAAgIgJQgHgJABgLQAEgZAYAAQALAAAIAJQAIAJgBALQAAALgJAIQgIAGgJAAIgDAAgAAul/QgYgBgBgZQgBgLAJgJQAJgIAMAAQALABAHAIQAHAHgBAMQAAALgIAIQgIAHgJAAIgDAAgArjl/QgYgBgCgZQgBgLAIgIQAIgJAMAAQALAAAIAIQAJAJgBALQAAALgIAIQgHAHgKAAIgDAAgAzpl/QgMAAgIgIQgHgJABgLQABgYAagBQALgBAIAIQAIAIAAAMQAAALgIAIQgIAHgKAAIgCAAgAPll/QgLAAgIgIQgIgIAAgLQAAgLAJgIQAIgIALAAQAZACABAZQABALgIAJQgIAHgKAAIgCAAgAngl/QgLAAgIgIQgIgIAAgLQAAgLAJgIQAIgIALAAQAZACABAZQABALgIAJQgIAHgKAAIgCAAgAgwl/QgYgBgDgZQgBgKAJgJQAIgIALgBQALAAAJAIQAIAIAAALQAAALgIAIQgIAIgLAAIgBAAgAtKmHQgJgIAAgNQADgXAWgCQALAAAJAHQAIAIABALQABAMgIAIQgHAIgMAAIgBAAQgLAAgHgIgAv4mGQgIgIAAgLQgBgKAJgJQAJgJAKABQAaACABAXQAAAcgaAAQgMAAgIgHgAIkmHQgJgIABgLQABgZAYgCQALgBAIAIQAIAIABAOQgCAXgXACIgDAAQgJAAgIgIgAuhmHQgJgIABgLQABgZAYgCQALgBAIAIQAIAIABAOQgCAXgXACIgDAAQgJAAgIgIgAqQl/QgVgDgBgYQAAgMAIgIQAIgHAMAAQAYACABAZQABALgJAIQgIAIgNAAIgCAAgAw7l/QgZgBgBgZQgBgMAHgIQAIgIALAAQALgBAJAJQAIAIAAALQAAALgIAIQgIAIgKAAIgBAAgAyXl/QgUgDgCgYQAAgLAIgIQAJgIALAAQALAAAIAIQAIAJgBALQAAALgJAHQgJAIgMAAIgCAAgAUsmHQgIgJABgLQADgaAYAAQALAAAIAJQAJAIgBALQgEAZgVABQgNAAgJgIgATOmZQgBgLAIgIQAIgJALAAQAMgBAIAJQAIAIAAALQgBALgIAIQgJAIgOAAQgVgCgBgYgAQomIQgIgJABgLQAEgZAXAAQAMgBAHAJQAIAJgBAOQgDAXgXAAQgMAAgIgJgABrmZQAAgLAIgIQAIgJALAAQALAAAIAIQAIAJAAALQAAAMgIAHQgJAHgNAAQgWgCgCgYgAiZmHQgIgJABgLQADgaAYAAQALAAAIAJQAJAIgBALQgEAZgVABQgNAAgJgIgAj3mZQgBgLAIgIQAIgJALAAQAMgBAIAJQAIAIAAALQgBALgIAIQgJAIgOAAQgVgCgBgYgAmdmIQgIgJABgLQAEgZAXAAQAMgBAHAJQAIAJgBAOQgDAXgXAAQgMAAgIgJgAQBnEQgHgIAAgMQAAgNAHgHQAIgIAMAAQAYABACAaQACAKgJAJQgIAJgLAAQgMAAgIgHgAnEnEQgHgIAAgMQAAgNAHgHQAIgIAMAAQAYABACAaQACAKgJAJQgIAJgLAAQgMAAgIgHgANVnEQgIgIAAgMQAAgLAIgJQAIgIALAAQALAAAJAJQAIAJgBAKQgDAagXABIgDAAQgKAAgHgHgApwnEQgIgIAAgMQAAgLAIgJQAIgIALAAQALAAAJAJQAIAJgBAKQgDAagXABIgDAAQgKAAgHgHgAtznFQgHgIAAgLQAAgNAHgHQAIgIAMAAQAXABADAZQACALgJAJQgIAJgLAAIgCAAQgKAAgIgIgAxkm9QgLAAgIgJQgIgIABgLQAAgMAJgIQAJgIALABQAYADABAZQABALgJAIQgIAIgKAAIgCAAgAq0m9QgXgBgDgZQgBgLAIgJQAIgJALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgLAAIgBAAgAUEnGQgIgIAAgMQABgLAIgIQAIgIAMABQAYACACAZQABALgJAIQgJAJgLAAQgMgBgHgIgARXnFQgIgJAAgLQADgZAXgCQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLABQgLAAgIgIgAjBnGQgIgIAAgMQABgLAIgIQAIgIAMABQAYACACAZQABALgJAIQgJAJgLAAQgMgBgHgIgAlunFQgIgJAAgLQADgZAXgCQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLABQgLAAgIgIgASvnFQgIgHAAgMQgBgLAIgIQAIgIAMAAQAXACADAZQgDAZgYABIgCAAQgKAAgGgHgAkWnFQgIgHAAgMQgBgLAIgIQAIgIAMAAQAXACADAZQgDAZgYABIgCAAQgKAAgGgHgAIPm+QgZAAgBgaQAAgMAIgIQAIgHAOAAQAKABAGAHQAGAHABALQABALgIAJQgIAHgKAAIgCAAgAu2m+QgZAAgBgaQAAgMAIgIQAIgHAOAAQAKABAGAHQAGAHABALQABALgIAJQgIAHgKAAIgCAAgAsMm+QgZgCABgZQAAgMAJgHQAIgIAMABQALABAHAJQAIAJgCALQgFAXgVAAIgDAAgAy6m+QgagBAAgZQAAgLAGgIQAHgHALgBQALgBAJAIQAJAIAAALQABALgIAIQgIAIgLAAIgBAAgAwgnGQgIgJABgLQABgLAHgHQAIgIALABQALAAAIAJQAIAJgBALQgDAYgZAAQgLAAgHgIgAO7m+QgXgEAAgXQAAgMAIgIQAJgHALABQAXABACAaQABAKgJAIQgJAIgLAAIgCAAgAoKm+QgXgEAAgXQAAgMAIgIQAJgHALABQAXABACAaQABAKgJAIQgJAIgLAAIgCAAgAqOn8QgZgBAAgZQgBgLAJgJQAIgIALAAQALABAIAIQAIAJgBALQAAAMgIAHQgHAGgKAAIgDAAgAs7n8QgMAAgHgIQgHgJABgMQACgVAXgEQANABAIAIQAIAIAAALQgBALgIAIQgIAHgLAAIgBAAgAuQn8QgLAAgIgIQgIgIAAgLQAAgLAJgIQAIgIALAAQAZADABAYQABALgIAJQgIAHgKAAIgCAAgATVoEQgJgJABgKQABgaAZgBQALAAAJAIQAIAIgBALQgBAagYABIgBAAQgLAAgIgIgAjwoEQgJgJABgKQABgaAZgBQALAAAJAIQAIAIgBALQgBAagYABIgBAAQgLAAgIgIgAQnoEQgIgIABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLAAQgMAAgIgIgAPSoEQgJgJABgLQAAgLAIgIQAJgIALABQAKAAAIAJQAIAJgBALQgBAXgZACQgLAAgIgIgAmeoEQgIgIABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLAAQgMAAgIgIgAnzoEQgJgJABgLQAAgLAIgIQAJgIALABQAKAAAIAJQAIAJgBALQgBAXgZACQgLAAgIgIgAwBoWQAAgLAIgJQAIgIALAAQAMAAAIAIQAHAIgBANQAAAWgaADQgZgDgCgXgAr2oDQgIgIAAgMQABgZAZgCQALgBAIAIQAIAIAAALQAAAZgZADIgCAAQgKAAgIgHgAo3n8QgZgDgCgYQAAgLAJgIQAJgIANAAQAWACABAYQAAAMgIAIQgHAIgKAAIgCAAgASPn8QgMgBgGgJQgHgJABgOQADgVAZAAQAMAAAHAJQAIAKgCALQgEAYgXAAIgCAAgAk2n8QgMgBgGgJQgHgJABgOQADgVAZAAQAMAAAHAJQAIAKgCALQgEAYgXAAIgCAAgAvLpCQgJgJABgLQACgYAYgDQALAAAIAIQAIAJABANQgBAWgZADIgCAAQgKAAgIgIgATAo6QgZgBgCgYQgBgMAHgIQAIgJALgBQAMAAAIAHQAIAIABAMQAAALgIAJQgHAIgLAAIgBAAgAkFo6QgZgBgCgYQgBgMAHgIQAIgJALgBQAMAAAIAHQAIAIABAMQAAALgIAJQgHAIgLAAIgBAAgAsepCQgJgJABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgIAIQgIAJgLAAIgCAAQgKAAgIgIgAoJo7QgLAAgIgJQgIgIABgLQABgLAJgIQAJgJAKACQAZAEAAAYQAAALgIAIQgHAHgKAAIgDAAgAmzo7QgXgBgDgZQgBgKAJgJQAJgIAMAAQAYADAAAXQABAMgIAIQgHAHgKAAIgDAAgAq2o7QgZgDgBgYQAAgLAIgIQAJgIANAAQAXAEABAXQAAAMgIAIQgIAHgKAAIgCAAgApypDQgIgJACgLQACgXAXgCQANAAAIAJQAIAIgBALQgCAYgaABIgBAAQgKAAgIgIgARXpDQgJgIAAgLQAAgKAJgJQAJgIALAAQAZACAAAZQAAAXgYAEQgMAAgJgIgAlupDQgJgIAAgLQAAgKAJgJQAJgIALAAQAZACAAAZQAAAXgYAEQgMAAgJgIgAt0pDQgJgJABgKQACgYAZgCQAaADAAAXQABAZgbACIgCAAQgKAAgHgIgAnyqAQgJgJAAgKQAAgLAIgIQAJgIANAAQAYABAAAXQABALgIAJQgIAJgKABIgBAAQgKAAgJgIgAlGqBQgIgJABgLQACgZAYAAQANAAAHAHQAIAHAAAMQAAALgJAIQgIAJgLAAQgLgBgIgIgApHqAQgJgJAAgMQAAgXAXgCQAPgBAIAIQAJAHgBAMQAAAYgaADIgCAAQgKAAgHgHgAtLqCQgJgJABgLQAAgLAIgHQAHgHAMABQANAAAHAIQAHAHgBAMQAAAZgaABIgCAAQgKAAgHgJgAuPp5QgLAAgIgKQgJgJABgLQAEgYAZAAQAZACAAAYQAAAMgIAIQgIAIgKAAIgBAAgAr0qAQgJgIAAgMQABgZAZgBQAMgBAIAHQAIAIAAANQgBAXgYADIgEAAQgJAAgHgHgAqLp5QgZgDgCgXQAAgNAHgIQAHgHANAAQAYAAADAZQAAAMgIAJQgIAIgJAAIgCAAgAmbqCQgJgIAAgLQAAgMAIgHQAIgIAMAAQAYACACAUQAAAOgIAJQgHAJgLABIgBAAQgKAAgIgJgApeq3QgLgBgIgIQgHgJAAgLQABgMAIgHQAIgHAMAAQAVACAEAXQAAANgIAJQgIAIgKAAIgCAAgAnErAQgIgIABgMQAAgMAIgHQAHgHANAAQAXABADAaQABAKgJAJQgJAJgLAAQgLAAgIgJgAsKq4QgLAAgHgJQgIgIAAgLQADgYAYgBQAZAAABAaQABALgJAIQgIAIgJAAIgCAAgArFrAQgJgIAAgKQgBgMAIgIQAJgJALABQAZABACAYQABAKgJAKQgJAJgKAAIgBAAQgJAAgIgIgAt6rRQgBgMAHgIQAHgIAMgBQALAAAJAHQAIAHABAMQABAKgJAJQgJAJgNAAQgXgDgBgWgAoYq/QgIgJgBgLQAAgLAHgIQAHgHALgBQAMAAAIAIQAJAIgBALQAAAYgZADIgDAAQgJAAgHgHgAlurBQgIgJABgLQACgZAZAAQAMABAHAIQAIAIAAALQgEAYgYACIgCAAQgKAAgHgJgAkFq4QgXgBgDgaQAEgaAXAAQANAAAHAIQAIAIgBAMQgBAMgIAGQgHAHgKAAIgCAAgAqer+QgJgIABgLQABgZAYgBQAMgBAJAJQAJAIgBALQAAAKgIAJQgJAIgKAAQgLAAgIgJgAmcr+QgIgIAAgLQAAgLAIgIQAJgJAKABQAZABACAZQABALgIAIQgIAJgLAAQgLAAgJgIgAs5r2QgZgBgBgZQgBgKAJgJQAIgJALAAQAXAAAEAWQAAAOgIAKQgHAIgLAAIgCAAgAlFr+QgIgIAAgMQgBgLAJgIQAIgIALABQAXAAAEAXQAAANgIAJQgIAIgLABQgLAAgIgIgAnyr+QgJgJABgLQABgYAYgCQALgBAJAHQAIAIABAMQAAALgHAIQgIAIgMAAIgBAAQgKAAgIgHgAr0r+QgJgIAAgMQAAgYAagCQALgCAIAIQAJAHAAALQABALgIAJQgHAJgMAAIgBAAQgLAAgHgHgAo1r3QgYgBgDgWQgBgMAIgJQAIgJAMAAQALgBAIAIQAIAHAAALQAAAMgIAIQgHAIgLAAIgBAAgAodtAQgIgJAAgLQAAgLAIgIQAJgIALAAQALAAAIAIQAIAIAAAMQgBALgIAIQgHAIgMAAQgLAAgIgIgAsgtAQgIgIAAgMQABgLAIgIQAIgIAMABQAZABABAaQAAALgIAIQgIAIgMAAQgLAAgIgIgAm0s4QgagDAAgYQgBgMAJgHQAJgIAQAAQAIABAGAHQAFAHABALQABAMgJAIQgHAIgKAAIgCAAgApgs4QgYgBgDgZQgBgLAJgIQAJgJANAAQAXAEABAWQAAAMgHAIQgIAIgLAAIgBAAgAq5s5QgYgCgBgZQAAgLAJgIQAIgHAMAAQAXABACAXQgBANgIAJQgHAHgKAAIgDAAgAnht3QgMAAgIgIQgHgIAAgMQABgYAZgCQALgBAJAIQAIAIAAALQAAAMgIAIQgHAIgLAAIgBAAgApRuRQgCgKAJgJQAJgJALgBQAKAAAIAIQAIAIAAALQABAMgIAIQgHAIgMAAQgYAAgDgagAr3t/QgIgJAAgLQAAgLAJgIQAJgIALAAQAYACACAZQABALgJAIQgIAJgLAAQgMAAgIgIgAqOt4QgZgCAAgYQAAgMAJgIQAIgJALACQAZAEgBAcQAAAJgIAHQgHAFgJAAIgDAAgAmluSQAAgLAIgJQAJgIAKABQAZABABAZQABALgJAIQgIAIgNAAQgXgDgBgXgApgu2QgXgBgDgZQAAgLAJgJQAJgJALAAQALABAHAIQAHAIAAALQAAANgIAHQgHAHgKAAIgDAAgAnGu/QgJgIABgLQADgYAYgDQALgBAIAJQAJAJAAALQAAAMgIAHQgHAIgNAAQgLAAgIgJgAseu9QgIgIAAgLQgBgLAJgJQAJgJAKABQAZADACAYQgDAZgWABIgCAAQgLAAgIgGgAobu+QgIgIAAgLQABgYAZgDQAKgCAJAJQAIAIAAANQgBAYgYABIgBAAQgLAAgIgHgAq1u3QgYAAgCgZQgBgKAIgKQAIgJALAAQAKAAAJAIQAIAJABAKQAAAMgIAIQgHAHgLAAIgCAAgAqfv7QgJgIAAgLQABgZAYgCQANgBAIAHQAIAHAAAMQABAMgIAIQgIAJgLAAQgLAAgIgIgAmMv0QgYgDgCgYQAAgLAIgIQAIgIAMAAQALAAAIAIQAIAIAAAMQAAALgJAIQgIAHgJAAIgDAAgAnzv7QgIgJAAgLQgBgLAIgIQAIgJALABQAMAAAHAIQAIAJABANQgCAVgYADIgDAAQgJAAgIgHgAs7v0QgYgBgCgaQAAgLAIgIQAIgIAMAAQAXABADAZQABALgJAJQgIAIgLAAIgBAAgAr+wOQAAgLAHgJQAIgIALAAQAMAAAIAIQAIAIAAALQAAAKgIAIQgJAIgLABQgYgEgCgWgApKv8QgIgJAAgLQABgYAZgCQAMgBAIAIQAIAIAAAMQAAALgIAIQgHAHgLAAIgCAAQgKAAgIgHgAsew6QgIgIgBgLQAAgLAJgJQAIgIALAAQALAAAIAIQAJAJgBALQgCAYgYADIgDAAQgJAAgIgIgAocw8QgJgIABgLQABgLAIgIQAJgIALABQAMAAAHAIQAIAJgBAMQgCAYgYABQgMAAgJgJgApgwzQgZgDAAgZQAAgLAJgIQAJgHALABQAXADACAYQgBALgIAIQgIAHgKAAIgCAAgAt0w7QgJgIAAgLQAAgKAJgJQAJgIAKAAQAYACACAZQgCAZgXACIgCAAQgKAAgIgIgAnFw6QgIgIgBgLQAAgKAJgJQAIgJALABQAaABAAAbQgBAXgXABIgDAAQgKAAgIgGgAq2w0QgZAAgBgaQAAgLAIgIQAJgIALAAQAXACADAYQAAAMgIAIQgHAHgKAAIgDAAgAo3xyQgLAAgIgJQgHgJABgLQAEgZAYAAQALAAAIAJQAIAJgBALQAAALgJAIQgIAGgJAAIgDAAgArjxyQgYgBgCgZQgBgLAIgIQAIgJAMAAQALAAAIAIQAJAJgBALQAAALgIAIQgHAHgKAAIgDAAgAngxyQgLAAgIgIQgIgIAAgLQAAgLAJgIQAIgIALAAQAZACABAZQABALgIAJQgIAHgKAAIgCAAgAtKx6QgJgIAAgNQADgXAWgCQALAAAJAHQAIAIABALQABAMgIAIQgHAIgMAAIgBAAQgLAAgHgIgAuhx6QgJgIABgLQABgZAYgCQALgBAIAIQAIAIABAOQgCAXgXACIgDAAQgJAAgIgIgAqQxyQgVgDgBgYQAAgMAIgIQAIgHAMAAQAYACABAZQABALgJAIQgIAIgNAAIgCAAgAmdx7QgIgJABgLQAEgZAXAAQAMgBAHAJQAIAJgBAOQgDAWgXABQgMAAgIgJgAnEy3QgHgIAAgMQAAgNAHgHQAIgIAMAAQAYABACAaQACAKgJAJQgIAJgLAAQgMAAgIgHgApwy3QgIgIAAgMQAAgLAIgJQAIgIALAAQALAAAJAJQAIAIgBALQgDAagXABIgDAAQgKAAgHgHgAtzy4QgHgIAAgLQAAgNAHgHQAIgIAMAAQAXABADAZQACALgJAJQgIAJgLAAIgCAAQgKAAgIgIgAq0ywQgXgBgDgaQgBgKAIgJQAIgJALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgLAAIgBAAgAluy4QgIgJAAgLQADgZAXgCQALAAAIAIQAJAIAAALQABALgJAIQgIAIgLABQgLAAgIgIgAsMyxQgZgCABgZQAAgMAJgHQAIgIAMABQALABAHAJQAIAJgCALQgFAXgVAAIgDAAgAoKyxQgXgEAAgXQAAgMAIgIQAJgHALABQAXABACAaQABAKgJAIQgJAIgLAAIgCAAgAqOzvQgZgBAAgZQgBgLAJgJQAIgIALAAQALABAIAIQAIAJgBALQAAAMgIAHQgHAGgKAAIgDAAgAs7zvQgMAAgHgIQgHgJABgMQACgVAXgEQANAAAIAIQAIAJAAALQgBALgIAIQgIAHgLAAIgBAAgAmez3QgIgIABgLQABgYAZgDQALAAAIAIQAJAIAAAKQABALgJAJQgIAIgLAAQgMAAgIgIgAnzz3QgJgJABgLQAAgLAIgIQAJgIALABQAKAAAIAJQAIAJgBALQgBAXgZACQgLAAgIgIgAr2z2QgIgIAAgMQABgZAZgCQALgBAIAIQAIAIAAALQAAAZgZADIgCAAQgKAAgIgHgAo3zvQgZgDgCgYQAAgLAJgIQAJgJANABQAWACABAYQAAAMgIAIQgHAIgKAAIgCAAgAk2zvQgMgBgGgJQgHgJABgOQADgVAZAAQAMAAAHAJQAIAKgCALQgEAYgXAAIgCAAgAvL01QgJgJABgLQACgYAYgDQALAAAIAIQAIAJABANQgBAWgZADIgCAAQgKAAgIgIgAse01QgJgJABgLQABgYAZgDQALAAAIAIQAJAIAAALQABALgIAIQgIAJgLAAIgCAAQgKAAgIgIgAoJ0uQgLAAgIgJQgIgIABgLQABgLAJgIQAJgJAKACQAZAEAAAYQAAALgIAIQgHAHgKAAIgDAAgAq20uQgZgDgBgYQAAgLAIgIQAJgIANAAQAXAEABAXQAAAMgIAIQgIAHgKAAIgCAAgAmz0uQgXgBgDgZQgBgKAJgJQAJgIAMAAQAYADAAAXQABAMgIAIQgIAHgKAAIgCAAgApy02QgIgJACgLQACgXAXgCQANAAAIAJQAIAIgBALQgCAYgaABIgBAAQgKAAgIgIgAlu02QgJgIAAgLQAAgKAJgJQAJgIALAAQAZACAAAZQAAAXgYAEQgMAAgJgIgAt002QgJgJABgKQACgYAZgCQAaADAAAXQABAZgbACIgCAAQgKAAgHgIgAvm1rQgKgBgJgJQgIgKABgJQAEgZAXAAQAMAAAIAHQAHAIAAAMQAAALgJAIQgHAIgLAAIgBAAgAtL11QgJgJABgLQAAgLAIgHQAHgHAMABQANAAAHAIQAHAHgBAMQAAAZgaABIgCAAQgKAAgHgJgAuP1sQgLAAgIgKQgJgJABgLQAEgYAZAAQAZACAAAYQAAAMgIAIQgIAIgKAAIgBAAgAr01zQgJgJAAgLQABgZAZgBQAMgBAIAHQAIAIAAANQgBAXgYADIgEAAQgJAAgHgHgAqL1sQgZgDgCgXQAAgNAHgIQAHgHANAAQAYAAADAZQAAAMgIAJQgIAIgJAAIgCAAgAu22rQgLAAgIgIQgIgJABgLQACgZAZAAQALAAAIAIQAJAJgBALQgBAKgIAIQgIAHgKAAIgBAAgAsK2rQgLAAgHgJQgIgIAAgLQADgYAYgBQAZAAABAaQABAKgJAJQgIAIgKAAIgBAAgAt63EQgBgMAHgIQAHgIAMgBQALAAAJAHQAIAHABAMQABAKgJAJQgJAJgNAAQgXgDgBgWg");
	this.shape.setTransform(700,300);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},302).wait(792));

	// Layer 1 copy 2
	this.instance_14 = new lib.cloud3();
	this.instance_14.parent = this;
	this.instance_14.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(315));

	// Layer 1
	this.instance_15 = new lib.cloud3();
	this.instance_15.parent = this;
	this.instance_15.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(315));

	// Layer 1 copy
	this.instance_16 = new lib.cloud1("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).wait(91));

	// Layer 1 copy 3
	this.instance_17 = new lib.cloud1("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(300));

	// Layer 1
	this.instance_18 = new lib.cloud1("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(300));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,239.9);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;