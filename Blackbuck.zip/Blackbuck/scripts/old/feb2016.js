(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween125 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(3,1,1).p("AhYAAICxAA");
	this.shape.setTransform(125.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D6D4D5").ss(3,1,1).p("Ay1AAMAlrAAA");
	this.shape_1.setTransform(-13.4,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135.5,-1.5,271,3);


(lib.Tween123 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AA4AAQAAAYgQAQQgRAQgXAAQgXAAgQgQQgRgQAAgYQAAgXARgQQAQgQAXAAQAXAAARAQQAQAQAAAXg");
	this.shape.setTransform(44.3,71.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("AB9AAQAAA0glAkQgkAlg0AAQgyAAglglQglgkAAg0QAAgyAlglQAkgkAzAAQA0AAAkAkQAlAlAAAyg");
	this.shape_1.setTransform(44.3,71.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("AA5AAQAAAYgRAQQgQAQgYAAQgWAAgRgQQgQgQAAgYQAAgXAQgQQARgQAWAAQAYAAAQAQQARAQAAAXg");
	this.shape_2.setTransform(-10.6,71.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("AB9AAQAAA0glAkQgkAlg0AAQgyAAglglQgkgkAAg0QAAgyAkglQAlgkAyAAQA0AAAkAkQAlAlAAAyg");
	this.shape_3.setTransform(-10.6,71.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AA1BJIhpAAIAAiRIBpAAg");
	this.shape_4.setTransform(14.3,-59.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag0BJIAAiRIBpAAIAACRg");
	this.shape_5.setTransform(14.3,-59.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#BABABA").ss(3,1,1).p("ADcCIQAAANgKAKQgJAJgNAAIl3AAQgNAAgKgJQgJgKAAgNIAAkOQAAgOAJgJQAKgKANAAIF3AAQANAAAJAKQAKAJAAAOg");
	this.shape_6.setTransform(14.3,-49.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ai7CoQgNAAgKgJQgJgKAAgOIAAkOQAAgNAJgKQAKgJANAAIF3AAQANAAAJAJQAKAKAAANIAAEOQAAAOgKAKQgJAJgNAAg");
	this.shape_7.setTransform(14.3,-49.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#BABABA").ss(3,1,1).p("AA1B7IhpAAIAAj1IBpAAg");
	this.shape_8.setTransform(14.5,-17.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag0B7IAAj1IBpAAIAAD1g");
	this.shape_9.setTransform(14.5,-17.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#BABABA").ss(3,1,1).p("AE5FnQAAAOgJAJQgKAJgNAAIowAAQgOAAgJgJQgKgJAAgOIAArNQAAgOAKgJQAJgKAOAAIIwAAQANAAAKAKQAJAJAAAOg");
	this.shape_10.setTransform(14.5,9.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AkYGHQgNAAgJgJQgKgKAAgNIAArNQAAgNAKgKQAJgKANAAIIxAAQANAAAKAKQAJAKAAANIAALNQAAANgJAKQgKAJgNAAg");
	this.shape_11.setTransform(14.5,9.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#BABABA").ss(3,1,1).p("AixAAIFjAA");
	this.shape_12.setTransform(16.9,63.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#BABABA").ss(3,1,1).p("AIbLfIAtAAQAWAAAPgPQAQgPAAgWQAAgWgQgPQgPgPgWAAIsdAAIAA1VIl3AAQgUAAgOAOQgOAOAAAUQAAATAOAOQAOAPAUAAIEjAAIAAVdIBbAA");
	this.shape_13.setTransform(0,-10.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.1,-85.1,130.4,170.3);


(lib.Tween121 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AkvAAIJgAA");
	this.shape.setTransform(4.9,18.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("AhYAAICxAA");
	this.shape_1.setTransform(-44.3,18.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("AlgAAILBAA");
	this.shape_2.setTransform(21.1,-3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("AimAAIFMAA");
	this.shape_3.setTransform(-12.2,-18.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AhYAAICxAA");
	this.shape_4.setTransform(-32.1,-3.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,1,1).p("AhYAAICxAA");
	this.shape_5.setTransform(-47.5,-18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.9,-19.7,115.9,39.6);


(lib.Tween120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BABABA").ss(3,1,1).p("AkvAAIJgAA");
	this.shape.setTransform(4.9,18.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BABABA").ss(3,1,1).p("AhYAAICxAA");
	this.shape_1.setTransform(-44.3,18.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#BABABA").ss(3,1,1).p("AlgAAILBAA");
	this.shape_2.setTransform(21.1,-3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#BABABA").ss(3,1,1).p("AimAAIFMAA");
	this.shape_3.setTransform(-12.2,-18.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#BABABA").ss(3,1,1).p("AhYAAICxAA");
	this.shape_4.setTransform(-32.1,-3.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BABABA").ss(3,1,1).p("AhYAAICxAA");
	this.shape_5.setTransform(-47.5,-18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.9,-19.7,115.9,39.6);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


(lib.Tween127 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween125("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(9.9,85.2);

	this.instance_1 = new lib.Tween123("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-80.1,-1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-145.3,-86.6,290.7,173.3);


// stage content:
(lib.FEB2016 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_74 = new cjs.Graphics().p("A9DWRMAAAgshMA6HAAAMAAAAshg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(74).to({graphics:mask_graphics_74,x:741,y:349.6}).wait(672));

	// Layer 2
	this.instance = new lib.Tween127("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(383.2,299.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(74).to({_off:false},0).to({x:761.2},49,cjs.Ease.elasticInOut).to({_off:true},188).wait(435));

	// Layer 12
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA1E48").ss(3,1,1).p("AAyAAIhjAA");
	this.shape.setTransform(626.3,404.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#DA1E48").ss(3,1,1).p("ABdAAIi5AA");
	this.shape_1.setTransform(622,404.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#DA1E48").ss(3,1,1).p("AB8gBIjhAAQgMAAgKAD");
	this.shape_2.setTransform(618.9,405);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#DA1E48").ss(3,1,1).p("ACKgmIjhAAQgVAAgPAOQgOAPAAAUIAAAc");
	this.shape_3.setTransform(617.5,408.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#DA1E48").ss(3,1,1).p("ACKhIIjhAAQgVAAgPAOQgOAPAAAVIAAAtQAAAUAOAPQAPAPAVAAIAoAA");
	this.shape_4.setTransform(617.5,412.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#DA1E48").ss(3,1,1).p("ACKhIIjhAAQgVAAgPAOQgOAPAAAVIAAAtQAAAUAOAPQAPAPAVAAICCAA");
	this.shape_5.setTransform(617.5,412.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#DA1E48").ss(3,1,1).p("ACKhIIjhAAQgVAAgPAOQgOAPAAAVIAAAtQAAAUAOAPQAPAPAVAAIDIAA");
	this.shape_6.setTransform(617.5,412.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#DA1E48").ss(3,1,1).p("ABphIIjhAAQgUAAgPAOQgPAPAAAVIAAAtQAAAUAPAPQAPAPAUAAIEBAAQATAAAPgO");
	this.shape_7.setTransform(620.8,412.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#DA1E48").ss(3,1,1).p("ABhhIIjhAAQgUAAgPAOQgPAPAAAVIAAAtQAAAUAPAPQAPAPAUAAIEBAAQAUAAAPgPQAPgPAAgUIAAgl");
	this.shape_8.setTransform(621.6,412.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#DA1E48").ss(3,1,1).p("AiABJIEBAAQAUAAAPgPQAPgPAAgUIAAgtQAAgVgPgPQgPgOgUAAIkBAAQgUAAgPAOQgPAPAAAVIAAAtQAAAUAPAPQAPAPAUAAg");
	this.shape_9.setTransform(621.6,412.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#DA1E48").ss(3,1,1).p("ACJyEIARAAAiASFIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIkBAAQgUAAgPAPQgPAOAAAVIAAAuQAAAVAPAPQAPAOAUAAg");
	this.shape_10.setTransform(621.6,303.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#DA1E48").ss(3,1,1).p("ABIyEIBSAAAiASFIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIkBAAQgUAAgPAPQgPAOAAAVIAAAuQAAAVAPAPQAPAOAUAAg");
	this.shape_11.setTransform(621.6,303.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#DA1E48").ss(3,1,1).p("AALyEICPAAAiASFIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIkBAAQgUAAgPAPQgPAOAAAVIAAAuQAAAVAPAPQAPAOAUAAg");
	this.shape_12.setTransform(621.6,303.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#DA1E48").ss(3,1,1).p("Ag0yEIDOAAAiASFIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIkBAAQgUAAgPAPQgPAOAAAVIAAAuQAAAVAPAPQAPAOAUAAg");
	this.shape_13.setTransform(621.6,303.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},51).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[]},255).wait(424));

	// Layer 9
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAhqIAADV");
	this.shape_14.setTransform(699.6,197.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAimIAAFN");
	this.shape_15.setTransform(699.6,203.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAkFIAAG+QAAAnAAAm");
	this.shape_16.setTransform(699.5,213.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAk3IAAG+QAABcAABV");
	this.shape_17.setTransform(699.5,218.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAlkIAAG+QAACNAAB+");
	this.shape_18.setTransform(699.5,222.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAnNIAAG/QAAEJAADT");
	this.shape_19.setTransform(699.5,233.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAoEIAAG/QAAFQAAD6");
	this.shape_20.setTransform(699.5,238.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#DA1E48").ss(3,1,1).p("AAApoIAAG/QAAHiAAEw");
	this.shape_21.setTransform(699.5,248.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAr0IAAG/QAALsAAE+");
	this.shape_22.setTransform(699.5,262.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAtiIAAG/QAASQAAB2");
	this.shape_23.setTransform(699.5,273.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAuZIAAG/QAAUMAAAIIAABg");
	this.shape_24.setTransform(699.5,279.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAvfIAAG/QAAUMAAAIIAADs");
	this.shape_25.setTransform(699.5,286.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAwvIAAG/QAAUMAAAIIAAGM");
	this.shape_26.setTransform(699.5,294.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#DA1E48").ss(3,1,1).p("AAAxhIAAG/QAAUMAAAIIAAHw");
	this.shape_27.setTransform(699.5,299.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#DA1E48").ss(3,1,1).p("AAHyPIAAG/QgBUMABAIIAAIJQAAAkgNAf");
	this.shape_28.setTransform(698.9,303.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#DA1E48").ss(3,1,1).p("AB5y+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhBAAIhRAA");
	this.shape_29.setTransform(687.5,308.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DA1E48").ss(3,1,1).p("AEZy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAImQAA");
	this.shape_30.setTransform(671.5,308.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#DA1E48").ss(3,1,1).p("AFzy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIpEAA");
	this.shape_31.setTransform(662.5,308.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#DA1E48").ss(3,1,1).p("AHry+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIs0AA");
	this.shape_32.setTransform(650.5,308.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#DA1E48").ss(3,1,1).p("AI2y+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIvKAA");
	this.shape_33.setTransform(643,308.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#DA1E48").ss(3,1,1).p("AJjy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIwkAA");
	this.shape_34.setTransform(638.5,308.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#DA1E48").ss(3,1,1).p("AKpy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIywAA");
	this.shape_35.setTransform(631.5,308.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAgx");
	this.shape_36.setTransform(621.6,308.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAjl");
	this.shape_37.setTransform(621.6,308.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAnd");
	this.shape_38.setTransform(621.6,308.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAqb");
	this.shape_39.setTransform(621.6,308.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAtZ");
	this.shape_40.setTransform(621.6,308.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAwD");
	this.shape_41.setTransform(621.6,308.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAAyO");
	this.shape_42.setTransform(621.6,308.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAA0a");
	this.shape_43.setTransform(621.6,308.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAA3a");
	this.shape_44.setTransform(621.6,308.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAA55");
	this.shape_45.setTransform(621.6,308.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAA8P");
	this.shape_46.setTransform(621.6,308.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDIAA+5");
	this.shape_47.setTransform(621.6,308.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgha");
	this.shape_48.setTransform(621.6,308.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMy+IAAG/QgBUMABAIIAAIJQAABDgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjH");
	this.shape_49.setTransform(621.6,308.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMxpIAAG/QgBULABAIIAAIKQAABCgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhCMAAAgjlQAAhCAvgvQAwgvBCAAIA5AA");
	this.shape_50.setTransform(621.6,300);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMxpIAAG/QgBULABAIIAAIKQAABCgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhCMAAAgjlQAAhCAvgvQAwgvBCAAIE9AA");
	this.shape_51.setTransform(621.6,300);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMxpIAAG/QgBULABAIIAAIKQAABCgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhCMAAAgjlQAAhCAvgvQAwgvBCAAIHdAA");
	this.shape_52.setTransform(621.6,300);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMxpIAAG/QgBULABAIIAAIKQAABCgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhCMAAAgjlQAAhCAvgvQAwgvBCAAINEAA");
	this.shape_53.setTransform(621.6,300);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMxpIAAG/QgBULABAIIAAIKQAABCgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhCMAAAgjlQAAhCAvgvQAwgvBCAAIRIAA");
	this.shape_54.setTransform(621.6,300);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#DA1E48").ss(3,1,1).p("AMMJpIAAIKQAABCgvAvQgwAvhCAAIzVAAQhCAAgwgvQgvgvAAhCMAAAgjlQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAHIQAAAGAAAGQgBT/ABAIg");
	this.shape_55.setTransform(621.6,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[]},277).wait(424));

	// Layer 10
	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#DA1E48").ss(3,1,1).p("AhBgcIAtAAQAkAAAaAZQABABAAABQAQAOAGATQgIgUgPgPAhBgfIAqAAQAkAAAbAaQABABABAB");
	this.shape_56.setTransform(684,206.9);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#DA1E48").ss(3,1,1).p("ACEgDQABABABABQAPAOAHATQgIgUgQgPgAibgfIDdAAQAmAAAaAaQABABABABAibgcIDhAAQAkAAAaAZ");
	this.shape_57.setTransform(674.9,206.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#DA1E48").ss(3,1,1).p("AkDgcIGxAAQAlAAAaAZQAAABABABQAQAOAGATQgIgUgPgPAkDgfIGuAAQAlAAAbAaQABABABAB");
	this.shape_58.setTransform(664.5,206.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#DA1E48").ss(3,1,1).p("AlKgcII/AAQAkAAAaAZQABABABABQAPAOAHATQgIgUgQgPAlKgfII7AAQAmAAAaAaQABABABAB");
	this.shape_59.setTransform(657.4,206.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#DA1E48").ss(3,1,1).p("AnggcINrAAQAkAAAaAZQABABABABQAPAOAHATQgIgUgQgPAnggfINnAAQAmAAAaAaQABABABAB");
	this.shape_60.setTransform(642.4,206.9);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#DA1E48").ss(3,1,1).p("Ao6gcIQfAAQAkAAAaAZQABABABABQAPAOAHATQgIgUgQgPAo6gfIQbAAQAmAAAaAaQABABABAB");
	this.shape_61.setTransform(633.4,206.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#DA1E48").ss(3,1,1).p("AqKgbQAIgBAIAAISvAAQAkAAAaAZQABABABABQAPAOAHATQgIgUgQgPAqKgfQAGAAAHAAISuAAQAmAAAaAaQABABABAB");
	this.shape_62.setTransform(625.4,206.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#DA1E48").ss(3,1,1).p("AqrAiQAGgVARgQQAbgbAlAAISvAAQAkAAAaAZQABABAAABQAQAPAHATQgJgUgPgQAqwAiQAGgXATgSQAagaAmAAISuAAQAlAAAbAaQABABABAB");
	this.shape_63.setTransform(621.7,207.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtB3IAAiPQAAglAagbQAbgaAlAAISvAAQAkAAAaAYQABABABABQAPAQAHATQgIgUgQgRAqxB3IAAiSQAAgmAbgaQAagbAmAAISuAAQAmAAAaAbQABABABAA");
	this.shape_64.setTransform(621.5,215.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtDfIAAlfQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHATQgIgTgQgRAqxDfIAAljQAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABAB");
	this.shape_65.setTransform(621.5,226);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtEhIAAniQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHATQgIgUgQgQAqxEhIAAnmQAAgmAbgaQAagaAmAAISuAAQAmAAAaAaQABABABAB");
	this.shape_66.setTransform(621.5,232.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtGKIAAq1QAAglAagbQAbgaAlAAISvAAQAkAAAaAZQABAAABABQAPAQAHATQgIgUgQgQAqxGKIAAq4QAAgmAbgaQAagbAmAAISuAAQAmAAAaAbQABABABAB");
	this.shape_67.setTransform(621.5,243);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtHVIAAtLQAAglAagbQAbgaAlAAISvAAQAkAAAaAZQABAAABABQAPAQAHATQgIgUgQgQAqxHVIAAtOQAAgmAbgaQAagbAmAAISuAAQAmAAAaAbQABABABAB");
	this.shape_68.setTransform(621.5,250.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtIqIAAv1QAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAQAHATQgIgUgQgRAqxIqIAAv5QAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABAB");
	this.shape_69.setTransform(621.5,259.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtKXIAAzPQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHATQgIgTgQgRAqxKXIAAzTQAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABAB");
	this.shape_70.setTransform(621.5,270);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtLyIAA2FQAAglAagbQAbgaAlAAISvAAQAkAAAaAYQABABABABQAPAQAHATQgIgUgQgRAqxLyIAA2IQAAgmAbgaQAagbAmAAISuAAQAmAAAaAbQABABABAA");
	this.shape_71.setTransform(621.5,279);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#DA1E48").ss(3,1,1).p("AqtNqIAA50QAAgmAagbQAbgaAlAAISvAAQAkAAAaAZQABABABAAQAPAQAHATQgIgUgQgQAqxNqIAA54QAAgmAbgaQAagbAmAAISuAAQAmAAAaAbQABABABAB");
	this.shape_72.setTransform(621.5,291);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#DA1E48").ss(3,1,1).p("AqUOZQgZgaAAgkIAA6xQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHAUQgIgUgQgRAqUOZQgBgBgBgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABABAloOyIjuAAQglAAgZgZAloO1IjrAAQglAAgbgaQgBgBAAgB");
	this.shape_73.setTransform(621.5,298.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#DA1E48").ss(3,1,1).p("AqUOZQgZgaAAgkIAA6xQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHAUQgIgUgQgRAqUOZQgBgBgBgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABABAA7OyIqRAAQglAAgZgZAA7O1IqOAAQglAAgbgaQgBgBAAgB");
	this.shape_74.setTransform(621.5,298.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#DA1E48").ss(3,1,1).p("AqUOZQgZgaAAgkIAA6xQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHAUQgIgUgQgRAqUOZQgBgBgBgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABABAGPOyIvlAAQglAAgZgZAGPO1IviAAQglAAgbgaQgBgBAAgB");
	this.shape_75.setTransform(621.5,298.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#DA1E48").ss(3,1,1).p("AqUOZQgZgaAAgkIAA6xQAAgmAagaQAbgbAlAAISvAAQAkAAAaAZQABABABABQAPAPAHAUQgIgUgQgRAqUOZQgBgBgBgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAmAAAaAaQABABABABAIvOyIyFAAQglAAgZgZAIvO1IyCAAQglAAgbgaQgBgBAAgB");
	this.shape_76.setTransform(621.5,298.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#DA1E48").ss(3,1,1).p("AqXOZQgZgaAAgkIAA6xQAAgmAbgaQAbgbAlAAISuAAQAlAAAaAZQABABAAABQAQAPAHAUQgJgUgPgRAqXOZQgBgBAAgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAlAAAbAaQABABABABAK0MQIAABLQAAAlgbAbQgaAagmAAIyuAAQglAAgbgaQgBgBgBgBAKxMQIAABHQAAAmgbAaQgbAbglAAIyuAAQglAAgagZ");
	this.shape_77.setTransform(621.8,298.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAAAlIAAhJ");
	this.shape_78.setTransform(690.6,358.1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#DA1E48").ss(3,1,1).p("AqXOZQgZgaAAgkIAA6xQAAgmAbgaQAbgbAlAAISuAAQAlAAAaAZQABABAAABQAQAPAHAUQgJgUgPgRAqXOZQgBgBAAgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAlAAAbAaQABABABABAK0J7IAADgQAAAlgbAbQgaAagmAAIyuAAQglAAgbgaQgBgBgBgBAKxJ4IAADfQAAAmgbAaQgbAbglAAIyuAAQglAAgagZ");
	this.shape_79.setTransform(621.8,298.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAACzIAAll");
	this.shape_80.setTransform(690.6,343.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAAEHIAAoN");
	this.shape_81.setTransform(690.6,335.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAAFTIAAqk");
	this.shape_82.setTransform(690.6,327.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAAHLIAAuU");
	this.shape_83.setTransform(690.6,315.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAAIvIAAxd");
	this.shape_84.setTransform(690.6,305.9);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#DA1E48").ss(3.2,1,1).p("AAAKKIAA0T");
	this.shape_85.setTransform(690.6,296.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#DA1E48").ss(3,1,1).p("AKxrUIAAA4AqXOZQgZgaAAgkIAA6xQAAgmAbgaQAbgbAlAAISuAAQAlAAAaAZQABABAAABQAQAPAHAUQgJgUgPgRAqXOZQgBgBAAgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAlAAAbAaQABABABABAK0J7IAADgQAAAlgbAbQgaAagmAAIyuAAQglAAgbgaQgBgBgBgBAKxJ4IAADfQAAAmgbAaQgbAbglAAIyuAAQglAAgagZ");
	this.shape_86.setTransform(621.8,298.6);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#DA1E48").ss(3,1,1).p("AKYuYQAZAaAAAkIAAC+AqXOZQgZgaAAgkIAA6xQAAgmAbgaQAbgbAlAAISuAAQAlAAAaAZQABABAAABQAbAaAAAmAqXOZQgBgBAAgBQgbgaAAgmIAA6xQAAglAbgbQAagaAmAAISuAAQAlAAAbAaQABABABABAK0J7IAADgQAAAlgbAbQgaAagmAAIyuAAQglAAgbgaQgBgBgBgBAKxJ4IAADfQAAAmgbAaQgbAbglAAIyuAAQglAAgagZ");
	this.shape_87.setTransform(621.8,298.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_56}]},15).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_79},{t:this.shape_78}]},1).to({state:[{t:this.shape_79},{t:this.shape_80}]},1).to({state:[{t:this.shape_79},{t:this.shape_81}]},1).to({state:[{t:this.shape_79},{t:this.shape_82}]},1).to({state:[{t:this.shape_79},{t:this.shape_83}]},1).to({state:[{t:this.shape_79},{t:this.shape_84}]},1).to({state:[{t:this.shape_86},{t:this.shape_85}]},1).to({state:[{t:this.shape_87},{t:this.shape_85}]},1).to({state:[]},277).wait(424));

	// Layer 18 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_86 = new cjs.Graphics().p("AzYNGIAA6LMAmwAAAIAAaLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(86).to({graphics:mask_1_graphics_86,x:457.4,y:306.9}).wait(660));

	// Layer 17
	this.instance_1 = new lib.Tween120("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(655.5,268.8);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween121("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(530.5,268.8);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},86).to({state:[{t:this.instance_2}]},35).to({state:[]},187).wait(438));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(86).to({_off:false},0).to({_off:true,x:530.5},35,cjs.Ease.elasticInOut).wait(625));

	// Layer 1 copy 2
	this.instance_3 = new lib.cloud3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-58.6,y:231.4},152).to({x:-796.4,y:200.1},287).to({_off:true},6).wait(301));

	// Layer 1
	this.instance_4 = new lib.cloud3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:1009.6,y:205.3},152).to({x:-108.2,y:200.1},287).to({_off:true},6).wait(301));

	// Layer 1 copy
	this.instance_5 = new lib.cloud1("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},369).wait(77));

	// Layer 1 copy 3
	this.instance_6 = new lib.cloud1("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:1099.5,y:101.6},141).to({x:1045.9,y:101.9},11).to({x:-129.4,y:108.1},242).to({_off:true},66).wait(286));

	// Layer 1
	this.instance_7 = new lib.cloud1("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({x:805.2,y:103.2},152).to({x:-129.4,y:108.1},242).to({_off:true},66).wait(286));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,182.3);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;