(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween70 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AJrUTIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCMAAAAjkQAABDgvAvQgvAvhDAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween69 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AJrUTIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCMAAAAjkQAABDgvAvQgvAvhDAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAHJ");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAGw");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAFx");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAFR");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAEt");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAACQ");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAvAvAABCIAAA0");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQATATAMAX");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQBCAAAwAvQAEAEADAD");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQAoAAAhAR");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAITVAAQADAAADAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIRZAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIPLAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIPLAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIL8AA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIL8AA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIJAAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIF/AA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIDsAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAICkAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIBUAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIAJAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp2IAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhCAvgvQAwgvBCAAIAJAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-131.1,158.4,262.3);


(lib.Tween45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMp5IAAbpQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhDAvgvQAhggAqgK");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-130.9,158.4,261.8);


(lib.Tween44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMqPIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgjkQAAhAAtgu");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-128.6,158.4,257.3);


(lib.Tween43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMq+IAAboQAABEgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhEMAAAgjkQAAgIABgJ");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-123.9,158.4,247.9);


(lib.Tween42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMruIAAbpQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAgiW");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-119.1,158.4,238.4);


(lib.Tween41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMsOIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDMAAAghU");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-115.9,158.4,231.9);


(lib.Tween40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMs+IAAbpQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA/2");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-111.1,158.4,222.4);


(lib.Tween39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMuAIAAbpQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA9y");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-104.5,158.4,209.1);


(lib.Tween38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA7a");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA7a");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA6k");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA53");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAA3S");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAxt");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAwn");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAwn");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAvk");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAtw");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAr0");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAApC");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAApC");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAkV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAkV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAiQ");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAhC");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMMvEIAAboQAABDgvAvQgvAvhDAAIzVAAQhCAAgwgvQgvgvAAhDIAAhC");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-97.7,158.4,195.5);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AMDvEIAAboQAABDgvAvQgvAvhDAAIzUAAQhDAAgvgvQgTgSgLgW");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.3,-97.7,156.6,195.5);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AL7vEIAAboQAABDgvAvQgvAvhDAAIzUAAQhDAAgvgvQgIgHgGgI");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.5,-97.7,155,195.5);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("ALRvEIAAboQAABDgvAvQgvAvhDAAIzVAAQgWAAgVgF");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-73.3,-97.7,146.6,195.5);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AK5vEIAAboQAABDgvAvQgvAvhDAAIzQAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.9,-97.7,141.8,195.5);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AK5vEIAAboQAABDgvAvQgvAvhDAAIzQAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.9,-97.7,141.8,195.5);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AKZvEIAAboQAABDgvAvQgvAvhDAAIyQAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67.6,-97.7,135.3,195.5);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("ADRvEIAAboQAABDgvAvQgvAvhDAAIkAAA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.1,-97.7,44.2,195.5);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAvu9IAAboQAABEgvAvQgUAVgaAL");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-97,11.8,194.1);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAgu0IAAboQAABDguAvQgIAJgJAG");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.4,-96.1,8.8,192.3);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAt4IAAboQAAAFAAAE");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-90.1,2.4,180.3);


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAshIAAZD");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-81.3,2.4,162.8);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAquIAAVd");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-69.8,2.4,139.8);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAnKIAAOV");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-47.1,2.4,94.2);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAmHIAAMP");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-40.3,2.4,80.8);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAk0IAAJp");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-32.1,2.4,64.2);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAjkIAAHJ");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-24,2.4,48.2);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAhGIAACN");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-8.3,2.4,16.7);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAgaIAAA0");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-3.8,2.4,7.7);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AkvAAIJfAA");
	this.shape.setTransform(4.9,18.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_1.setTransform(-44.3,18.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AlgAAILBAA");
	this.shape_2.setTransform(21.1,-3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AilAAIFLAA");
	this.shape_3.setTransform(-12.2,-18.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_4.setTransform(-32.1,-3.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_5.setTransform(-47.5,-18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.4,-19.2,114.9,38.5);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AkvAAIJfAA");
	this.shape.setTransform(4.9,18.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_1.setTransform(-44.3,18.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AlgAAILBAA");
	this.shape_2.setTransform(21.1,-3.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AilAAIFLAA");
	this.shape_3.setTransform(-12.2,-18.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_4.setTransform(-32.1,-3.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_5.setTransform(-47.5,-18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.4,-19.2,114.9,38.5);


(lib.truck1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("ABRAAQAAAigXAYQgYAXgiAAQghAAgYgXQgXgYAAgiQAAghAXgXQAYgYAhAAQAiAAAYAYQAXAXAAAhg");
	this.shape.setTransform(227.4,53.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("ADLAAQAABUg7A7Qg8A8hUAAQhTAAg8g8Qg7g7AAhUQAAhTA7g8QA8g7BTAAQBUAAA8A7QA7A8AABTg");
	this.shape_1.setTransform(227.4,53.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiPCPQg7g7AAhUQAAhTA7g7QA8g8BTAAQBUAAA7A8QA8A7AABTQAABUg8A7Qg7A8hUAAQhTAAg8g8g");
	this.shape_2.setTransform(227.4,53.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("ACmCGIlLAAIAAkLIEPAAQAZAAASASQARASAAAZg");
	this.shape_3.setTransform(197.8,-5.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("AnbmYIGTAAQA/AAArAsQAsAtAAA+IAAD8ID3AAQA/AAAsArQAsAtAAA+IAAEIIu1AAg");
	this.shape_4.setTransform(215.6,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AnZGZIgCsxIGTAAQA/AAArAsQAsAtAAA+IAAD8ID3AAQA/AAAsArQAsAtAAA+IAAEIg");
	this.shape_5.setTransform(215.6,11.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("ANIJ5I6QAAIAAzxIaQAAg");
	this.shape_6.setTransform(84.1,-10.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AtHJ5IAAzxIaQAAIAATxg");
	this.shape_7.setTransform(84.1,-10.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("ABRAAQAAAigYAYQgXAXgiAAQghAAgXgXQgYgYAAgiQAAggAYgYQAYgYAgAAQAiAAAXAYQAYAYAAAgg");
	this.shape_8.setTransform(74.7,53.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag4A6QgYgYAAgiQAAggAYgYQAYgYAgAAQAiAAAXAYQAYAYAAAgQAAAigYAYQgXAXgiAAQghAAgXgXg");
	this.shape_9.setTransform(74.7,53.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#9E9B9C").ss(2.4,1,1).p("ADLAAQAABUg7A7Qg8A8hUAAQhTAAg7g8Qg8g7AAhUQAAhTA8g8QA7g7BTAAQBUAAA8A7QA7A8AABTg");
	this.shape_10.setTransform(74.8,53.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AiOCPQg8g7AAhUQAAhTA8g7QA6g8BUAAQBUAAA8A8QA7A7AABTQAABUg7A7Qg8A8hUAAQhUAAg6g8g");
	this.shape_11.setTransform(74.8,53.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.truck1, new cjs.Rectangle(-1.2,-75.1,265.6,150.2), null);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.AUG2015 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 12 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_66 = new cjs.Graphics().p("A9DWRMAAAgshMA6HAAAMAAAAshg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(66).to({graphics:mask_graphics_66,x:741,y:349.6}).wait(1030));

	// Layer 13
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AgaAAIA1AA");
	this.shape.setTransform(888,442);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AgoAAIBRAA");
	this.shape_1.setTransform(886.6,439);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AhYAAICxAA");
	this.shape_2.setTransform(881.8,439);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("Ag0AAIBpAB");
	this.shape_3.setTransform(858.6,438.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("Am0gDINpAH");
	this.shape_4.setTransform(820.2,438.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("ApfgEIS/AJ");
	this.shape_5.setTransform(803.1,438.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AsUgGIYpAN");
	this.shape_6.setTransform(785,438.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("At4gGIbxAN");
	this.shape_7.setTransform(775,438.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AvTgHIenAP");
	this.shape_8.setTransform(765.9,438.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AwggIMAhBAAR");
	this.shape_9.setTransform(758.2,438.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("Aw7gIMAh3AAR");
	this.shape_10.setTransform(755.5,438.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AxVgIMAirAAR");
	this.shape_11.setTransform(752.9,438);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},131).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_4},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_2}]},1).to({state:[{t:this.shape_6},{t:this.shape_2}]},1).to({state:[{t:this.shape_6},{t:this.shape_2}]},1).to({state:[{t:this.shape_7},{t:this.shape_2}]},1).to({state:[{t:this.shape_8},{t:this.shape_2}]},1).to({state:[{t:this.shape_9},{t:this.shape_2}]},1).to({state:[{t:this.shape_9},{t:this.shape_2}]},1).to({state:[{t:this.shape_10},{t:this.shape_2}]},1).to({state:[{t:this.shape_11},{t:this.shape_2}]},1).to({state:[{t:this.shape_11},{t:this.shape_2}]},1).to({state:[{t:this.shape_11},{t:this.shape_2}]},70).to({state:[]},878).to({state:[]},1).wait(1));

	// Layer 1
	this.instance = new lib.truck1();
	this.instance.parent = this;
	this.instance.setTransform(410.7,362.1,1,1,0,0,0,131.6,0);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(66).to({_off:false},0).to({x:726.2},45,cjs.Ease.elasticInOut).to({_off:true},949).wait(36));

	// Layer 10
	this.instance_1 = new lib.Tween1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(623.2,344.1);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(463.2,344.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},91).to({state:[{t:this.instance_2}]},44).wait(961));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(91).to({_off:false},0).to({_off:true,x:463.2},44,cjs.Ease.elasticOut).wait(961));

	// Layer 8
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAABRIAAih");
	this.shape_12.setTransform(551.9,358.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAEZIAAox");
	this.shape_13.setTransform(551.9,338.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAFXIAAqt");
	this.shape_14.setTransform(551.9,332.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAHIIAAuP");
	this.shape_15.setTransform(551.9,321.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#D8234B").ss(2.4,1,1).p("AAAIQIAAwf");
	this.shape_16.setTransform(551.9,313.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#D8234B").ss(2.4,1,1).p("AhEI/IAAwiQAAgmAagaQAbgbAkAAIAxAA");
	this.shape_17.setTransform(558.9,309.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#D8234B").ss(2.4,1,1).p("AkjI/IAAwiQAAgmAbgaQAagbAmAAIHsAA");
	this.shape_18.setTransform(581.1,309.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxI/IAAwiQAAgmAagaQAbgbAlAAISvAAQAlAAAbAbQAaAaAAAmIAAC4");
	this.shape_19.setTransform(620.9,309.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxI/IAAwiQAAgmAagaQAbgbAlAAISvAAQAlAAAbAbQAaAaAAAmIAAE6");
	this.shape_20.setTransform(620.9,309.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxI/IAAwiQAAgmAagaQAbgbAlAAISvAAQAlAAAbAbQAaAaAAAmIAAGt");
	this.shape_21.setTransform(620.9,309.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxI/IAAwiQAAgmAagaQAbgbAlAAISvAAQAlAAAbAbQAaAaAAAmIAANk");
	this.shape_22.setTransform(620.9,309.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxI/IAAwiQAAgmAagaQAbgbAlAAISvAAQAlAAAbAbQAaAaAAAmIAAPw");
	this.shape_23.setTransform(620.9,309.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxIZIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAARu");
	this.shape_24.setTransform(620.9,313.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxFgIAAwiQAAglAagbQAbgaAlAAISvAAQAlAAAbAaQAaAbAAAlIAAXf");
	this.shape_25.setTransform(620.9,331.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDOIAAwiQAAglAagbQAbgaAlAAISvAAQAlAAAbAaQAaAbAAAlIAAaxQAAAmgaAaQgMAMgOAG");
	this.shape_26.setTransform(620.9,346.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIjsAA");
	this.shape_27.setTransform(620.9,346.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIlQAA");
	this.shape_28.setTransform(620.9,346.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIonAA");
	this.shape_29.setTransform(620.9,346.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIqGAA");
	this.shape_30.setTransform(620.9,346.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIuTAA");
	this.shape_31.setTransform(620.9,346.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIyvAAQglAAgbgbQgagbAAgmIAAiW");
	this.shape_32.setTransform(620.9,346.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIyvAAQglAAgbgbQgagbAAgmIAAkK");
	this.shape_33.setTransform(620.9,346.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIyvAAQglAAgbgbQgagbAAgmIAAlV");
	this.shape_34.setTransform(620.9,346.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIyvAAQglAAgbgbQgagbAAgmIAAma");
	this.shape_35.setTransform(620.9,346.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxDKIAAwiQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIyvAAQglAAgbgbQgagbAAgmIAAoE");
	this.shape_36.setTransform(620.9,346.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#D8234B").ss(2.4,1,1).p("AqxtYQAAglAagbQAbgbAlAAISvAAQAlAAAbAbQAaAbAAAlIAAawQAAAmgaAbQgbAbglAAIyvAAQglAAgbgbQgagbAAgmg");
	this.shape_37.setTransform(620.9,346.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_12}]},17).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[]},1049).wait(1));

	// Layer 9
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#D8234B").ss(2.4,1,1).p("AhxAAIDjAA");
	this.shape_38.setTransform(624.7,238);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#D8234B").ss(2.4,1,1).p("AiZAAIEzAA");
	this.shape_39.setTransform(620.6,238);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#D8234B").ss(2.4,1,1).p("AiZw7IEzAAAAVQ8IgnAA");
	this.shape_40.setTransform(620.6,346.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#D8234B").ss(2.4,1,1).p("AilxZIEzAAACmRaIAAgJQAAgVgOgPQgPgPgVAAIiSAA");
	this.shape_41.setTransform(621.9,349.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#D8234B").ss(2.4,1,1).p("AilxjIEzAAACmRkIAAgdQAAgVgOgPQgPgPgVAAIiSAA");
	this.shape_42.setTransform(621.9,350.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#D8234B").ss(2.4,1,1).p("Ailx8IEzAAACaR9QAMgOAAgTIAAguQAAgVgOgPQgPgPgVAAIiSAA");
	this.shape_43.setTransform(621.9,352.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#D8234B").ss(2.4,1,1).p("AiZyEIEzAAAiyQtIAAAmQAAAVAPAPQAPAOAUAAIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIiTAA");
	this.shape_44.setTransform(620.6,353.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#D8234B").ss(2.4,1,1).p("AiZyEIEzAAAh7PzIgFAAQgUAAgPAPQgPAOAAAVIAAAuQAAAVAPAPQAPAOAUAAIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIiTAA");
	this.shape_45.setTransform(620.6,353.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#D8234B").ss(2.4,1,1).p("AiZyEIEzAAAiASFIEBAAQAUAAAPgOQAPgPAAgVIAAguQAAgVgPgOQgPgPgUAAIkBAAQgUAAgPAPQgPAOAAAVIAAAuQAAAVAPAPQAPAOAUAAg");
	this.shape_46.setTransform(620.6,353.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_38}]},72).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_46}]},1).to({state:[]},1013).wait(1));

	// Layer 1
	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(698.6,289.6);

	this.instance_4 = new lib.Tween4("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(698.6,294.1);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween5("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(698.6,309.8);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween6("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(698.6,317.9);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween7("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(698.6,326.1);
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween8("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(698.6,332.9);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween9("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(698.6,355.6);
	this.instance_9._off = true;

	this.instance_10 = new lib.Tween10("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(698.6,367.1);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween11("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(698.6,375.9);
	this.instance_11._off = true;

	this.instance_12 = new lib.Tween12("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(695.4,381.9);
	this.instance_12._off = true;

	this.instance_13 = new lib.Tween13("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(693.9,382.8);
	this.instance_13._off = true;

	this.instance_14 = new lib.Tween14("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(677.7,383.5);
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween15("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(632.2,383.5);
	this.instance_15._off = true;

	this.instance_16 = new lib.Tween16("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(628.9,383.5);
	this.instance_16._off = true;

	this.instance_17 = new lib.Tween17("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(628.9,383.5);
	this.instance_17._off = true;

	this.instance_18 = new lib.Tween18("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(626.5,383.5);
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween19("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(622.3,383.5);
	this.instance_19._off = true;

	this.instance_20 = new lib.Tween20("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(621.5,383.5);
	this.instance_20._off = true;

	this.instance_21 = new lib.Tween21("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(620.6,383.5);
	this.instance_21._off = true;

	this.instance_22 = new lib.Tween22("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(620.6,383.5);
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween23("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(620.6,383.5);
	this.instance_23._off = true;

	this.instance_24 = new lib.Tween24("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(620.6,383.5);
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween25("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(620.6,383.5);
	this.instance_25._off = true;

	this.instance_26 = new lib.Tween26("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(620.6,383.5);
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween27("synched",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(620.6,383.5);
	this.instance_27._off = true;

	this.instance_28 = new lib.Tween28("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(620.6,383.5);
	this.instance_28._off = true;

	this.instance_29 = new lib.Tween29("synched",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(620.6,383.5);
	this.instance_29._off = true;

	this.instance_30 = new lib.Tween30("synched",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(620.6,383.5);
	this.instance_30._off = true;

	this.instance_31 = new lib.Tween31("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(620.6,383.5);
	this.instance_31._off = true;

	this.instance_32 = new lib.Tween32("synched",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(620.6,383.5);
	this.instance_32._off = true;

	this.instance_33 = new lib.Tween33("synched",0);
	this.instance_33.parent = this;
	this.instance_33.setTransform(620.6,383.5);
	this.instance_33._off = true;

	this.instance_34 = new lib.Tween34("synched",0);
	this.instance_34.parent = this;
	this.instance_34.setTransform(620.6,383.5);
	this.instance_34._off = true;

	this.instance_35 = new lib.Tween35("synched",0);
	this.instance_35.parent = this;
	this.instance_35.setTransform(620.6,383.5);
	this.instance_35._off = true;

	this.instance_36 = new lib.Tween36("synched",0);
	this.instance_36.parent = this;
	this.instance_36.setTransform(620.6,383.5);
	this.instance_36._off = true;

	this.instance_37 = new lib.Tween37("synched",0);
	this.instance_37.parent = this;
	this.instance_37.setTransform(620.6,383.5);
	this.instance_37._off = true;

	this.instance_38 = new lib.Tween38("synched",0);
	this.instance_38.parent = this;
	this.instance_38.setTransform(620.6,383.5);
	this.instance_38._off = true;

	this.instance_39 = new lib.Tween39("synched",0);
	this.instance_39.parent = this;
	this.instance_39.setTransform(620.6,376.7);
	this.instance_39._off = true;

	this.instance_40 = new lib.Tween40("synched",0);
	this.instance_40.parent = this;
	this.instance_40.setTransform(620.6,370);
	this.instance_40._off = true;

	this.instance_41 = new lib.Tween41("synched",0);
	this.instance_41.parent = this;
	this.instance_41.setTransform(620.6,365.3);
	this.instance_41._off = true;

	this.instance_42 = new lib.Tween42("synched",0);
	this.instance_42.parent = this;
	this.instance_42.setTransform(620.6,362);
	this.instance_42._off = true;

	this.instance_43 = new lib.Tween43("synched",0);
	this.instance_43.parent = this;
	this.instance_43.setTransform(620.6,357.3);
	this.instance_43._off = true;

	this.instance_44 = new lib.Tween44("synched",0);
	this.instance_44.parent = this;
	this.instance_44.setTransform(620.6,352.6);
	this.instance_44._off = true;

	this.instance_45 = new lib.Tween45("synched",0);
	this.instance_45.parent = this;
	this.instance_45.setTransform(620.6,350.3);
	this.instance_45._off = true;

	this.instance_46 = new lib.Tween46("synched",0);
	this.instance_46.parent = this;
	this.instance_46.setTransform(620.6,350.1);
	this.instance_46._off = true;

	this.instance_47 = new lib.Tween47("synched",0);
	this.instance_47.parent = this;
	this.instance_47.setTransform(620.6,350.1);
	this.instance_47._off = true;

	this.instance_48 = new lib.Tween48("synched",0);
	this.instance_48.parent = this;
	this.instance_48.setTransform(620.6,350.1);
	this.instance_48._off = true;

	this.instance_49 = new lib.Tween49("synched",0);
	this.instance_49.parent = this;
	this.instance_49.setTransform(620.6,350.1);
	this.instance_49._off = true;

	this.instance_50 = new lib.Tween50("synched",0);
	this.instance_50.parent = this;
	this.instance_50.setTransform(620.6,350.1);
	this.instance_50._off = true;

	this.instance_51 = new lib.Tween51("synched",0);
	this.instance_51.parent = this;
	this.instance_51.setTransform(620.6,350.1);
	this.instance_51._off = true;

	this.instance_52 = new lib.Tween52("synched",0);
	this.instance_52.parent = this;
	this.instance_52.setTransform(620.6,350.1);
	this.instance_52._off = true;

	this.instance_53 = new lib.Tween53("synched",0);
	this.instance_53.parent = this;
	this.instance_53.setTransform(620.6,350.1);
	this.instance_53._off = true;

	this.instance_54 = new lib.Tween54("synched",0);
	this.instance_54.parent = this;
	this.instance_54.setTransform(620.6,350.1);
	this.instance_54._off = true;

	this.instance_55 = new lib.Tween55("synched",0);
	this.instance_55.parent = this;
	this.instance_55.setTransform(620.6,350.1);
	this.instance_55._off = true;

	this.instance_56 = new lib.Tween56("synched",0);
	this.instance_56.parent = this;
	this.instance_56.setTransform(620.6,350.1);
	this.instance_56._off = true;

	this.instance_57 = new lib.Tween57("synched",0);
	this.instance_57.parent = this;
	this.instance_57.setTransform(620.6,350.1);
	this.instance_57._off = true;

	this.instance_58 = new lib.Tween58("synched",0);
	this.instance_58.parent = this;
	this.instance_58.setTransform(620.6,350.1);
	this.instance_58._off = true;

	this.instance_59 = new lib.Tween59("synched",0);
	this.instance_59.parent = this;
	this.instance_59.setTransform(620.6,350.1);
	this.instance_59._off = true;

	this.instance_60 = new lib.Tween60("synched",0);
	this.instance_60.parent = this;
	this.instance_60.setTransform(620.6,350.1);
	this.instance_60._off = true;

	this.instance_61 = new lib.Tween61("synched",0);
	this.instance_61.parent = this;
	this.instance_61.setTransform(620.6,350.1);
	this.instance_61._off = true;

	this.instance_62 = new lib.Tween62("synched",0);
	this.instance_62.parent = this;
	this.instance_62.setTransform(620.6,350.1);
	this.instance_62._off = true;

	this.instance_63 = new lib.Tween63("synched",0);
	this.instance_63.parent = this;
	this.instance_63.setTransform(620.6,350.1);
	this.instance_63._off = true;

	this.instance_64 = new lib.Tween64("synched",0);
	this.instance_64.parent = this;
	this.instance_64.setTransform(620.6,350.1);
	this.instance_64._off = true;

	this.instance_65 = new lib.Tween65("synched",0);
	this.instance_65.parent = this;
	this.instance_65.setTransform(620.6,350.1);
	this.instance_65._off = true;

	this.instance_66 = new lib.Tween66("synched",0);
	this.instance_66.parent = this;
	this.instance_66.setTransform(620.6,350.1);
	this.instance_66._off = true;

	this.instance_67 = new lib.Tween67("synched",0);
	this.instance_67.parent = this;
	this.instance_67.setTransform(620.6,350.1);
	this.instance_67._off = true;

	this.instance_68 = new lib.Tween68("synched",0);
	this.instance_68.parent = this;
	this.instance_68.setTransform(620.6,350.1);
	this.instance_68._off = true;

	this.instance_69 = new lib.Tween69("synched",0);
	this.instance_69.parent = this;
	this.instance_69.setTransform(620.6,350.1);
	this.instance_69._off = true;

	this.instance_70 = new lib.Tween70("synched",0);
	this.instance_70.parent = this;
	this.instance_70.setTransform(620.6,350.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).to({state:[{t:this.instance_50}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_57}]},1).to({state:[{t:this.instance_58}]},1).to({state:[{t:this.instance_59}]},1).to({state:[{t:this.instance_60}]},1).to({state:[{t:this.instance_61}]},1).to({state:[{t:this.instance_62}]},1).to({state:[{t:this.instance_63}]},1).to({state:[{t:this.instance_64}]},1).to({state:[{t:this.instance_65}]},1).to({state:[{t:this.instance_66}]},1).to({state:[{t:this.instance_67}]},1).to({state:[{t:this.instance_68}]},1).to({state:[{t:this.instance_69}]},1).to({state:[{t:this.instance_70}]},1).to({state:[]},1028).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true,y:294.1},1).wait(1095));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:false},1).to({_off:true,y:309.8},1).wait(1094));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({_off:false},1).to({_off:true,y:317.9},1).wait(1093));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(2).to({_off:false},1).to({_off:true,y:326.1},1).wait(1092));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(3).to({_off:false},1).to({_off:true,y:332.9},1).wait(1091));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(4).to({_off:false},1).to({_off:true,y:355.6},1).wait(1090));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(5).to({_off:false},1).to({_off:true,y:367.1},1).wait(1089));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(6).to({_off:false},1).to({_off:true,y:375.9},1).wait(1088));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(7).to({_off:false},1).to({_off:true,x:695.4,y:381.9},1).wait(1087));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(8).to({_off:false},1).to({_off:true,x:693.9,y:382.8},1).wait(1086));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(9).to({_off:false},1).to({_off:true,x:677.7,y:383.5},1).wait(1085));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(10).to({_off:false},1).to({_off:true,x:632.2},1).wait(1084));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(11).to({_off:false},1).to({_off:true,x:628.9},1).wait(1083));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(12).to({_off:false},1).to({_off:true},1).wait(1082));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(13).to({_off:false},1).to({_off:true,x:626.5},1).wait(1081));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(14).to({_off:false},1).to({_off:true,x:622.3},1).wait(1080));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(15).to({_off:false},1).to({_off:true,x:621.5},1).wait(1079));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(16).to({_off:false},1).to({_off:true,x:620.6},1).wait(1078));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(17).to({_off:false},1).to({_off:true},1).wait(1077));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(18).to({_off:false},1).to({_off:true},1).wait(1076));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(19).to({_off:false},1).to({_off:true},1).wait(1075));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(20).to({_off:false},1).to({_off:true},1).wait(1074));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(21).to({_off:false},1).to({_off:true},1).wait(1073));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(22).to({_off:false},1).to({_off:true},1).wait(1072));
	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(23).to({_off:false},1).to({_off:true},1).wait(1071));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(24).to({_off:false},1).to({_off:true},1).wait(1070));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(25).to({_off:false},1).to({_off:true},1).wait(1069));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(26).to({_off:false},1).to({_off:true},1).wait(1068));
	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(27).to({_off:false},1).to({_off:true},1).wait(1067));
	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(28).to({_off:false},1).to({_off:true},1).wait(1066));
	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(29).to({_off:false},1).to({_off:true},1).wait(1065));
	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(30).to({_off:false},1).to({_off:true},1).wait(1064));
	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(31).to({_off:false},1).to({_off:true},1).wait(1063));
	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(32).to({_off:false},1).to({_off:true},1).wait(1062));
	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(33).to({_off:false},1).to({_off:true},1).wait(1061));
	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(34).to({_off:false},1).to({_off:true,y:376.7},1).wait(1060));
	this.timeline.addTween(cjs.Tween.get(this.instance_39).wait(35).to({_off:false},1).to({_off:true,y:370},1).wait(1059));
	this.timeline.addTween(cjs.Tween.get(this.instance_40).wait(36).to({_off:false},1).to({_off:true,y:365.3},1).wait(1058));
	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(37).to({_off:false},1).to({_off:true,y:362},1).wait(1057));
	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(38).to({_off:false},1).to({_off:true,y:357.3},1).wait(1056));
	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(39).to({_off:false},1).to({_off:true,y:352.6},1).wait(1055));
	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(40).to({_off:false},1).to({_off:true,y:350.3},1).wait(1054));
	this.timeline.addTween(cjs.Tween.get(this.instance_45).wait(41).to({_off:false},1).to({_off:true,y:350.1},1).wait(1053));
	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(42).to({_off:false},1).to({_off:true},1).wait(1052));
	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(43).to({_off:false},1).to({_off:true},1).wait(1051));
	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(44).to({_off:false},1).to({_off:true},1).wait(1050));
	this.timeline.addTween(cjs.Tween.get(this.instance_49).wait(45).to({_off:false},1).to({_off:true},1).wait(1049));
	this.timeline.addTween(cjs.Tween.get(this.instance_50).wait(46).to({_off:false},1).to({_off:true},1).wait(1048));
	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(47).to({_off:false},1).to({_off:true},1).wait(1047));
	this.timeline.addTween(cjs.Tween.get(this.instance_52).wait(48).to({_off:false},1).to({_off:true},1).wait(1046));
	this.timeline.addTween(cjs.Tween.get(this.instance_53).wait(49).to({_off:false},1).to({_off:true},1).wait(1045));
	this.timeline.addTween(cjs.Tween.get(this.instance_54).wait(50).to({_off:false},1).to({_off:true},1).wait(1044));
	this.timeline.addTween(cjs.Tween.get(this.instance_55).wait(51).to({_off:false},1).to({_off:true},1).wait(1043));
	this.timeline.addTween(cjs.Tween.get(this.instance_56).wait(52).to({_off:false},1).to({_off:true},1).wait(1042));
	this.timeline.addTween(cjs.Tween.get(this.instance_57).wait(53).to({_off:false},1).to({_off:true},1).wait(1041));
	this.timeline.addTween(cjs.Tween.get(this.instance_58).wait(54).to({_off:false},1).to({_off:true},1).wait(1040));
	this.timeline.addTween(cjs.Tween.get(this.instance_59).wait(55).to({_off:false},1).to({_off:true},1).wait(1039));
	this.timeline.addTween(cjs.Tween.get(this.instance_60).wait(56).to({_off:false},1).to({_off:true},1).wait(1038));
	this.timeline.addTween(cjs.Tween.get(this.instance_61).wait(57).to({_off:false},1).to({_off:true},1).wait(1037));
	this.timeline.addTween(cjs.Tween.get(this.instance_62).wait(58).to({_off:false},1).to({_off:true},1).wait(1036));
	this.timeline.addTween(cjs.Tween.get(this.instance_63).wait(59).to({_off:false},1).to({_off:true},1).wait(1035));
	this.timeline.addTween(cjs.Tween.get(this.instance_64).wait(60).to({_off:false},1).to({_off:true},1).wait(1034));
	this.timeline.addTween(cjs.Tween.get(this.instance_65).wait(61).to({_off:false},1).to({_off:true},1).wait(1033));
	this.timeline.addTween(cjs.Tween.get(this.instance_66).wait(62).to({_off:false},1).to({_off:true},1).wait(1032));
	this.timeline.addTween(cjs.Tween.get(this.instance_67).wait(63).to({_off:false},1).to({_off:true},1).wait(1031));
	this.timeline.addTween(cjs.Tween.get(this.instance_68).wait(64).to({_off:false},1).to({_off:true},1).wait(1030));
	this.timeline.addTween(cjs.Tween.get(this.instance_69).wait(65).to({_off:false},1).to({_off:true},1).wait(1029));

	// Layer 1 copy 2
	this.instance_71 = new lib.cloud3();
	this.instance_71.parent = this;
	this.instance_71.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_71).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(317));

	// Layer 1
	this.instance_72 = new lib.cloud3();
	this.instance_72.parent = this;
	this.instance_72.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_72).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(317));

	// Layer 1 copy
	this.instance_73 = new lib.cloud1("synched",0);
	this.instance_73.parent = this;
	this.instance_73.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_73._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_73).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).to({_off:true},91).wait(2));

	// Layer 1 copy 3
	this.instance_74 = new lib.cloud1("synched",0);
	this.instance_74.parent = this;
	this.instance_74.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_74).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(302));

	// Layer 1
	this.instance_75 = new lib.cloud1("synched",0);
	this.instance_75.parent = this;
	this.instance_75.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_75).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(302));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,215);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 38,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;