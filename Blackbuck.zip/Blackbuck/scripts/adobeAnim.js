var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
function init(exportId) {
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");
	var comp=AdobeAn.getComposition("A0F2311E12414503AFA66E6A0996A419");
	var lib=comp.getLibrary();
	handleComplete(exportId, {}, comp);
}
function handleComplete(exportId, evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	exportRoot = new lib[exportId]();
	console.log(exportRoot);
	stage = new lib.Stage(canvas);
	stage.addChild(exportRoot);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}	    
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {		
		var lastW, lastH, lastS=1;		
		window.addEventListener('resize', resizeCanvas);		
		resizeCanvas();		
		function resizeCanvas() {			
			var w = lib.properties.width, h = lib.properties.height;			
			var iw = window.innerWidth, ih=window.innerHeight;			
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;		
		}
	}
	makeResponsive(true,'both',true,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}

function addScript(rel,url){
		if($("#adobeAnim_"+rel).length > 0){
			$("#adobeAnim_"+rel).remove();
		}
		$("<script/>").attr({"src":url,id:"adobeAnim_"+rel}).appendTo("head");
	}
		var scrolled = false;
		$(window).scroll(function() {
			var height = $(window).scrollTop();
			// console.log("height",height,$(".timeline")[0].getBoundingClientRect().top);
			if(height  > $(".timeline")[0].getBoundingClientRect().top) {
				if(!scrolled) {
					scrolled=true;
					$(".milestone > li:first > span").trigger("click");

				}
			}
		});
		$(document).ready(function(){
			$(".milestone").find("li > span").on("click",function(e){
				e.preventDefault();
				var currentClass = $(this).attr("rel"),
					exportId = "";
				switch(currentClass){
					case "one":{
						addScript(currentClass,"scripts/aug2014.js");
						exportId = "handandlighttruck1";
						break;
					}
					case "two":{
						addScript(currentClass, "scripts/apr2015.js");
						exportId = "APR2015";
						break;
					}
					case "three":{
						addScript(currentClass, "scripts/jun2015.js");
						exportId = "JUN2015";
						break;
					}
					case "four":{
						addScript(currentClass, "scripts/july2015.js");
						exportId = "JULY2015";
						break;
					}
					case "five":{
						addScript(currentClass, "scripts/aug2015.js");
						exportId = "mobileandtruck1";
						break;
					}
					case "six":{
						addScript(currentClass, "scripts/dec2015.js");
						exportId = "DEC2015";
						break;
					}
					case "seven":{
						addScript(currentClass, "scripts/feb2016.js");
						exportId = "FEB2016";
						break;
					}
					case "eight":{
						addScript(currentClass, "scripts/jun2016.js");
						exportId = "JUN2016";
						break;
					}
					case "nine":{
						addScript(currentClass, "scripts/mar2017.js");
						exportId = "MAR2017";
						break;
					}
					case "ten":{
						addScript(currentClass, "scripts/july2017.js");
						exportId = "JULY2017";
						break;
					}
				}
				// $(".timeline > *").hide();
// 				$(".timeline > #"+ currentClass + "_animation_container").show();
				(function forceload(){
					if(typeof AdobeAn !== "undefined")
						init(exportId);
					else
						setTimeout(forceload,200);
				})();
			});
		});