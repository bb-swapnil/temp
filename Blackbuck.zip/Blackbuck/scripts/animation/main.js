function attachEventListener(target, eventType, functionRef, capture){

	 if(typeof target.addEventListener != "undefined"){
	   target.addEventListener(eventType, functionRef, capture);
	 }else{
	   target.attachEvent("on" + eventType, functionRef);
	 }

};


var initiate = function(){

	var tl1 = new TimelineLite();
	var tl5 = new TimelineLite();
	var tl3 = new TimelineLite();
	var tl4 = new TimelineLite();

	window.changeXValue = "+=0";



	// var localObj = {
	// 	getVideo : document.getElementById('adVideo'),
	// 	replayBtnWrap : document.getElementById('replayBtn'),
	// 	wrapper : document.getElementById('wrapper'),
	// 	muteBtn : document.getElementById('mute'),
	// 	unmuteBtn : document.getElementById('unmute'),
	// 	muteUnmuteWrap : document.getElementById('muteUnmute')
	// }

	console.log(tl1);

	// Start Animation
	var startAnimation = function() {

			 //tl1.to("#subCircle2", 0, {scaleX:2, scaleY:2});

			 tl1.to("#subCircle2", .3, {scaleX:35, scaleY:35, opacity: 1})
			    .to("#subCircle2", .3, {scaleX:30, scaleY:30})

			    .to("#horizLine1", .3, {width: 200, x:-200,  opacity: 1}, "-=.5")
			    .to("#horizLine2", .3, {width: 200,  opacity: 1}, "-=.5")


			    .to("#subCircle1", .3, {scaleX:35, scaleY:35, opacity: 1}, "-=.35")
			    .to("#subCircle1", .3, {scaleX:30, scaleY:30})

			    .to("#subCircle3", .3, {scaleX:35, scaleY:35, opacity: 1}, "-=.7")
			    .to("#subCircle3", .3, {scaleX:30, scaleY:30}, "-=.3")

			    .to(".imgWrap", .3, {opacity: 1}, "-=.1")

			    .to(".textNode", .3, {opacity:1, y:+20}, "-=.3")

			    .addLabel("spin1")

			   //.add(Tween).to("#orangeCircle", .3, {scaleX:30, scaleY:30, opacity: 1, x:0}, "+=.5")

			    tl4.to("#orangeCircle", .3, {scaleX:30, scaleY:30, opacity: 1, x:window.changeXValue, overwrite: true}, "+=.5")

			    .to("#mainVerticalLine", .3, {height: 50, y: -50, opacity: 1, x:changeXValue}, "-=.2")

			    .to("#yellowCircleMain", .3, {scaleX:140, scaleY:140, opacity: 1, y:-140, x:changeXValue}, "-=.1")

			    .to("#whiteCircleMain", .3, {scaleX:140, scaleY:140, opacity: 1, y:-140, x:changeXValue}, "-=.1")

			    .to("#mainText", .3, {opacity: 1, x:changeXValue});



			    tl5.addLabel("spin1")

			    .to("#orangeCircle2", .3, {scaleX:30, scaleY:30, opacity: 1}, "+=.5")

			    .to("#mainVerticalLine2", .3, {height: 50, y: -50, opacity: 1}, "-=.2")

			    .to("#yellowCircleMain2", .3, {scaleX:140, scaleY:140, opacity: 1, y:-140}, "-=.1")

			    .to("#whiteCircleMain2", .3, {scaleX:140, scaleY:140, opacity: 1, y:-140}, "-=.1")

			    .to("#mainText2", .3, {opacity: 1});



			    tl3.to("#orangeCircle3", .3, {scaleX:30, scaleY:30, opacity: 1}, "+=.5")

			    .to("#mainVerticalLine3", .3, {height: 50, y: -50, opacity: 1}, "-=.2")

			    .to("#yellowCircleMain3", .3, {scaleX:140, scaleY:140, opacity: 1, y:-140}, "-=.1")

			    .to("#whiteCircleMain3", .3, {scaleX:140, scaleY:140, opacity: 1, y:-140}, "-=.1")

			    .to("#mainText3", .3, {opacity: 1});


			    tl5.pause();
			    tl3.pause();




			//    .to("#bgImg", 1, {opacity: 0.3}, "+=1")
			//    .to("#bgImg", 1, {scaleX:1.1, scaleY:1.1, opacity: 0}, "+=1")
			//    .to("#phone, #pic1, #mask", 1, {scaleX:1.1, scaleY:1.1, opacity: 1, y:0},"-=1")
			//    .to("#pic1", .1, {opacity: 0})
			//    .to("#maskImg", 1, { x:-119 },"+=1")
			//    .to("#phone, #pic1, #mask", 1, { x:+100 },"+=1")
			//    //.to("#siteText", 0, { opacity: 1 })
			//    .to(".logo", .5, {scaleX:1, scaleY:1, opacity: 1},"-=1")
			//    .to(".welcome", .5, {scaleX:1, scaleY:1, opacity: 1},"-=.9")
			//    .to(".experience", .5, {scaleX:1, scaleY:1, opacity: 1},"-=.8")
			//    .to(".learn-more", .5, {scaleX:1, scaleY:1, opacity: 1},"-=.7")
			//    //.to("#pic1", 0, {opacity: 0},"+=.1")
			//    .to("#videoWrap", 0, {opacity: 1},"+=.2")
			//    .add(startVideo);
		
	}

	function resetImages(){

		$("#img1Wrap img").attr("src","images/animation/01.png");
		$("#img2Wrap img").attr("src","images/animation/02.png");
		$("#img3Wrap img").attr("src","images/animation/03.png");
	}

	function imgClickHandler(e){

		var getTarget = e.target;
		console.log(getTarget.className);

		resetImages();

		if(getTarget.className == "1"){
			tl5.pause(0, true);
			tl3.pause(0, true);
			 tl4.restart();

			 getTarget.src = "images/animation/01_active.png";

		} else if(getTarget.className == "2"){
		
			tl5.restart();
			tl4.pause(0, true);
			tl3.pause(0, true);

			getTarget.src = "images/animation/02_active.png";

		} else if(getTarget.className == "3"){
			
			tl3.restart();
			tl5.pause(0, true);
			tl4.pause(0, true);

			getTarget.src = "images/animation/03_active.png";

		}
	}

	function addEvents(){

		 attachEventListener(document.getElementById("img1Wrap"), 'click', imgClickHandler, false);

		 attachEventListener(document.getElementById("img2Wrap"), 'click', imgClickHandler, false);

		 attachEventListener(document.getElementById("img3Wrap"), 'click', imgClickHandler, false);


	}



	

	startAnimation();
	addEvents();

}

window.onload = function(){
	initiate();
};



