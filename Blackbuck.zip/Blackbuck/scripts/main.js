$( document ).ready(function() {

	$('.navbtn, .close').on('click', function() {
		$('.bar ').toggleClass('animate');
		$('.nav-slider').toggleClass('active');
	});


	$('.news').bxSlider({
		mode: 'horizontal',
		infiniteLoop:true,
		auto:true,
		speed:300,
		pause:5000,
		autoHover: true,
		adaptiveHeight:true,
	});

	$('.testimony').bxSlider({
		mode: 'horizontal',
		infiniteLoop:true,
		auto:true,
		speed:300,
		pause:5000,
		autoHover: true,
		adaptiveHeight:true,
	});	




$(window).scroll(function() {
if ($(this).scrollTop() > 1){  
    $('.top-header').addClass("sticky");
  }
  else{
    $('.top-header').removeClass("sticky");
  }
});



enquire.register("screen and (max-width: 1200px)", {
    match : function() {

 	$('.members li.hover').on('click', function() {
		 $('body').addClass('fixed');
	});
	$('.team-close').on('click', function() {
		$('body').removeClass('fixed');

	});

    },
    unmatch : function() {

    }

});






$(".btn-pos").on("click", function() {
  $(".btn-pos").removeClass("active");
  $(this).addClass("active");
  var position = $(this).attr("rel");

  $(".position-list .pos-all").hide();
  $(".pos-banner").hide();  
  $(".pos-" + position).fadeIn();
  $(".banner-" + position).show();  
});
    $(".position-list .pos-technology").show();

$(".position-list .head").on("click", function() {
  $(this).parent().toggleClass("open");
  // $(this).parent().find('.details').toggleClass('show');

});

	



// load video



	$('.culture-video').on('click', function() {
		$('.video ').show();
        $('.play-video').load('partials/video.php');
        $('body').addClass('fixed');
	});


	$('.hackathon').on('click', function() {
		$('.video ').show();
        $('.play-video').load('partials/videos/technology.php');
        $('body').addClass('fixed');
	});




		$('.video-close').on('click', function() {
		$( ".play-video" ).empty();
		$('.video').hide();
		$('body').removeClass('fixed');

	});


		$('.team-close').on('click', function(event) {
			event.stopPropagation();
		$(".members .details").hide();

	});		

 	$('.members li').on('click', function() {
		$(this).find('.details').show();
	});





enquire.register("screen and (max-width: 767px)", {
    match : function() {

		$(".current").on("click", function() {
		  $(this).parent().toggleClass('open');
		  $(".positions").toggle();
		  console.log('clicked');
		});

		$(".btn-pos").on("click", function() {
		  var position =  $(this).attr("rel");
		$('.current').text(position) ;
		   $(".positions").toggle();
		  $('.dropdown-menu').toggleClass('open');
		    console.log('menu clicked');
		});
		    $(window).scroll(sticky_relocate);
   			 sticky_relocate();

    },
    unmatch : function() {

    }

});



function sticky_relocate() {
    var window_top = $(window).scrollTop();
    var div_top = $('.open-positions').offset().top;
    var div_bottom = $('.photogallery').offset().top;
    if (window_top > div_top) {
        $('.dropdown-menu').addClass('stick');
        $('.open-positions').addClass('pad');
    } else {
        $('.dropdown-menu').removeClass('stick');
        $('.open-positions').removeClass('pad');
    }
        if (window_top > div_bottom) {
        $('.dropdown-menu').removeClass('stick');
        $('.open-positions').removeClass('pad');
       
    } else {
	return false;
    }
}

// $(function() {
//     $(window).scroll(sticky_relocate);
//     sticky_relocate();
// });


$(".milestone li span").on("click", function() {
 $(".milestone li span").removeClass("active");
  $(this).addClass("active");
  var position = $(this).attr("rel");
  $('.truck').removeClass().addClass( 'truck ' + position);
  console.log(position);
var content = '#'+position; 
$('.anim-content p').hide();
 $(content).fadeIn();
  console.log(content);

	
});

$(".milestone li+li").on("click", function() {
  $('.rightarrow').hide();

});



});

