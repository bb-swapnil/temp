(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.5,0,1).p("AD9ADIgWAAQgLgUgYAAIhOABIAAgWQAAgVgPgOQgPgPgVAAIhJABQgHgPgNgIQgOgJgQAAIhCAAQgWABgQAPQgQAQgBAWIgBAAQgUABgPAOQgPAPAAAVIgXAAQgSAAgMAMQgMAMAAARIAAAPQAAARANAMQAMAMARAAIBxgBQABAQALALQALALAQAAIEogCQAOAAALgKQALgKACgOIATAAQARAAALgMQAMgMAAgRQAAgQgMgMQgMgMgRAAg");
	this.shape.setTransform(29.4,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+BtQgLgLgBgQIhxABQgRAAgMgMQgNgMAAgRIAAgPQAAgRAMgMQAMgMASAAIAXAAQAAgVAPgPQAPgOAUgBIABAAQABgWAQgQQAQgPAWgBIBCAAQAQAAAOAJQANAIAHAPIBJgBQAVAAAPAPQAPAOAAAVIAAAWIBOgBQAYAAALAUIAWAAQARAAAMAMQAMAMAAAQQAAARgMAMQgLAMgRAAIgTAAQgCAOgLAKQgLAKgOAAIkoACQgQAAgLgLg");
	this.shape_1.setTransform(29.4,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-1,-1,60.8,26), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D6D4D5").ss(1.8,0,1).p("AG0AJIgnAAQgJgQgPgJQgRgLgTAAIiGAAIAAglQAAgjgZgaQgZgZgkAAIh+AAQgMgZgXgOQgYgQgcAAIhxAAQgmAAgcAbQgcAbgCAmIgBAAQgjAAgZAZQgZAaAAAjIgqAAQgdAAgVAVQgVAUAAAeIAAAaQAAAdAVAVQAVAVAdAAIDDAAQABAbATATQATATAbAAIH9AAQAZAAATgRQASgQAEgZIAhAAQAcAAAVgUQAUgUAAgdQAAgdgUgUQgVgVgcAAg");
	this.shape.setTransform(50.5,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AisDOQgbAAgTgTQgTgTgBgbIjDAAQgdAAgVgVQgVgVAAgdIAAgaQAAgeAVgUQAVgVAdAAIAqAAQAAgjAZgaQAZgZAjAAIABAAQACgmAcgbQAcgbAmAAIBxAAQAcAAAYAQQAXAOAMAZIB+AAQAkAAAZAZQAZAaAAAjIAAAlICGAAQATAAARALQAPAJAJAQIAnAAQAcAAAVAVQAUAUAAAdQAAAdgUAUQgVAUgcAAIghAAQgEAZgSAQQgTARgZAAg");
	this.shape_1.setTransform(50.5,20.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,103.1,43.2);


// stage content:
(lib.JULY2015 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D71E48").s().p("AhHBlQhHiTAAgyQAAg7AqgqQAqgqA6AAQA7AAAqAqQAqAqAAA7QAAAyhICTQgWAvgXArIgDACIAAAEIgXArQgjhAgkhLgAgsh8QgSATAAAaQAAAaASATQATASAZAAQAaAAASgSQATgTAAgaQAAgagTgTQgSgSgaAAQgZAAgTASg");
	this.shape.setTransform(467.2,282.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D71E48").s().p("AhHBlQhHiUAAgxQAAg7AqgqQAqgqA6AAQA7AAAqAqQAqAqAAA7QAAAxhICUQgjBLgkBAQgjhAgkhLgAgsh8QgSATAAAaQAAAaASASQATATAZAAQAbAAARgTQATgSAAgaQAAgagTgTQgRgSgbAAQgZAAgTASg");
	this.shape_1.setTransform(755.5,202.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#231F20").ss(3,0,1).p("AggAaIBBgy");
	this.shape_2.setTransform(752.2,235.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#231F20").ss(3,0,1).p("AgxAnIBjhN");
	this.shape_3.setTransform(750.5,237.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#231F20").ss(3,0,1).p("AhfBLIC/iV");
	this.shape_4.setTransform(745.9,240.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#231F20").ss(3,0,1).p("Ah6BgID1i/");
	this.shape_5.setTransform(743.2,242.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#231F20").ss(3,0,1).p("AiPBwIEfjf");
	this.shape_6.setTransform(741.2,244.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#231F20").ss(3,0,1).p("AikCBIFJkB");
	this.shape_7.setTransform(739.1,246.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#231F20").ss(3,0,1).p("Ai/CWIF/kr");
	this.shape_8.setTransform(736.3,248.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#231F20").ss(3,0,1).p("AjQCjIGhlF");
	this.shape_9.setTransform(734.6,249.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#231F20").ss(3,0,1).p("AjjCyIHHlj");
	this.shape_10.setTransform(732.7,251.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#231F20").ss(3,0,1).p("AkRDWIIjmr");
	this.shape_11.setTransform(728.1,254.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#231F20").ss(3,0,1).p("AkxDvIJjnd");
	this.shape_12.setTransform(724.9,257.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#231F20").ss(3,0,1).p("AlWEMIKtoY");
	this.shape_13.setTransform(721.2,260.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#231F20").ss(3,0,1).p("Al0EjILppF");
	this.shape_14.setTransform(718.3,262.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#231F20").ss(3,0,1).p("AmPE2QAJgGAIgGIMMpi");
	this.shape_15.setTransform(715.7,264.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#231F20").ss(3,0,1).p("AmxFAQAJAAAIgBQAqgFAigaIMMpi");
	this.shape_16.setTransform(711.5,265.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#231F20").ss(3,0,1).p("AnkEjIAeAOQAnASAqgEQAqgFAigaIMMpi");
	this.shape_17.setTransform(707.2,265.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#231F20").ss(3,0,1).p("AoIECIBlAvQAnASAqgEQAqgFAigaIMMpi");
	this.shape_18.setTransform(703.7,265.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#231F20").ss(3,0,1).p("AooDjICmBOQAmASArgEQAqgFAhgaIMMpi");
	this.shape_19.setTransform(700.5,265.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#231F20").ss(3,0,1).p("ApdCxIEQCAQAmASArgEQAqgFAhgaIMMpi");
	this.shape_20.setTransform(695.2,265.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#231F20").ss(3,0,1).p("Ap3CZIFDCYQAnASAqgEQAqgFAigaIMMpi");
	this.shape_21.setTransform(692.6,265.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#231F20").ss(3,0,1).p("AqYB6IGGC3QAnASAqgEQAqgFAigaIMMpi");
	this.shape_22.setTransform(689.2,265.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#231F20").ss(3,0,1).p("Aq0BfIG+DSQAnASAqgEQAqgFAigaIMMpi");
	this.shape_23.setTransform(686.4,265.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#231F20").ss(3,0,1).p("ArVBBIIADwQAmASArgEQAqgFAhgaIMMpi");
	this.shape_24.setTransform(683.2,265.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#231F20").ss(3,0,1).p("Ar2AiIJCEPQAmASArgEQAqgFAhgaIMMpi");
	this.shape_25.setTransform(679.9,265.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#231F20").ss(3,0,1).p("AsXADIKDEuQAnASAqgEQAqgFAhgaIMNpi");
	this.shape_26.setTransform(676.6,265.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#231F20").ss(3,0,1).p("As4gbILFFMQAnASAqgEQApgFAigaIMNpi");
	this.shape_27.setTransform(673.3,265.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#231F20").ss(3,0,1).p("At0hUIM+GFQAnASApgEQAqgFAigaIMNpi");
	this.shape_28.setTransform(667.2,265.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#231F20").ss(3,0,1).p("AuniEIOkG1QAlASArgEQAqgFAhgaIMNpi");
	this.shape_29.setTransform(662.2,265.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#231F20").ss(3,0,1).p("Av+iyQALgCALgCQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_30.setTransform(652.7,265.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#231F20").ss(3,0,1).p("AwbiXQAhgaAqgFQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_31.setTransform(650.3,265.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#231F20").ss(3,0,1).p("Aw3hqIA2gsQAhgbArgFQArgFAnASIPxHaQAnASAqgEQAqgFAigaIMNpi");
	this.shape_32.setTransform(647.5,265.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#231F20").ss(3,0,1).p("AxHhQIBWhGQAigbArgFQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_33.setTransform(645.9,265.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#231F20").ss(3,0,1).p("AxjgjICOhzQAigbArgFQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_34.setTransform(643.1,265.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#231F20").ss(3,0,1).p("AyCAOIDMikQAhgbArgFQArgFAnASIPxHaQAnASAqgEQAqgFAigaIMNpi");
	this.shape_35.setTransform(640,265.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#231F20").ss(3,0,1).p("AygA/IEJjVQAhgbArgFQArgFAnASIPxHaQAnASAqgEQAqgFAigaIMNpi");
	this.shape_36.setTransform(636.9,265.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#231F20").ss(3,0,1).p("AzBB0IFKkKQAigbArgFQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_37.setTransform(633.7,265.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#231F20").ss(3,0,1).p("AzeCiIGEk4QAhgbArgFQArgFAnASIPxHaQAnASAqgEQAqgFAigaIMNpi");
	this.shape_38.setTransform(630.8,265.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#231F20").ss(3,0,1).p("A0pEbIIamxQAigbArgFQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_39.setTransform(623.3,265.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#231F20").ss(3,0,1).p("A1IFIIJYnjQAigbArgFQAqgFAnASIPyHaQAmASArgEQAqgFAhgaIMNpi");
	this.shape_40.setTransform(620.2,266.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#D71E48").s().p("AhHBlQhHiTAAgyQAAg7AqgqQAqgqA6AAQA7AAAqAqQAqAqAAA7QAAAyhICTQgjBLgkBAQgjhAgkhLgAgsh8QgSATAAAaQAAAaASATQATASAZAAQAaAAASgSQATgTAAgaQAAgagTgTQgSgSgaAAQgZAAgTASg");
	this.shape_41.setTransform(467.2,282.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#231F20").ss(3,0,1).p("A14FvIK5oxQAhgbArgFQArgFAnASIPxHaQAnASAqgEQAqgFAigaIMNpi");
	this.shape_42.setTransform(615.3,270);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#231F20").ss(3,0,1).p("A2iGRIMMp0QAigbArgFQAqgFAnASIPyHaQAmASArgFQAqgFAhgaIMNpi");
	this.shape_43.setTransform(611.2,273.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},2).to({state:[{t:this.shape_3},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_4},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_6},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_7},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_8},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_9},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_11},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_11},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_12},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_14},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_15},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_16},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_17},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_18},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_19},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_20},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_21},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_22},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_23},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_24},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_25},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_26},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_27},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_28},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_29},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_30},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_31},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_32},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_33},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_34},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_35},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_36},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_37},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_38},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_39},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_40},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_42},{t:this.shape_1},{t:this.shape_41}]},1).to({state:[{t:this.shape_43},{t:this.shape_1},{t:this.shape_41}]},1).to({state:[{t:this.shape_43},{t:this.shape_1},{t:this.shape_41}]},1).to({state:[]},1090).wait(1));

	// Layer 133
	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#D6D4D5").ss(3,1,1).p("AjzDMIHmmX");
	this.shape_44.setTransform(555.5,332.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#D6D4D5").ss(3,1,1).p("EAiiAJOMglagRyQhSgnhbgCQhcgChTAlIjmBkQg2AXgsAkImJFAQhRBChnATIsECY");
	this.shape_45.setTransform(739.4,216.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#D6D4D5").ss(3,1,1).p("A6z5vMA1LAZUQAZAMADAaQAEAcgWARI+tY4");
	this.shape_46.setTransform(750.2,300);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#D6D4D5").ss(3,1,1).p("A07p9MAp4AT7");
	this.shape_47.setTransform(778.9,247.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#D6D4D5").ss(3,1,1).p("A7Js7MA2TAZ3");
	this.shape_48.setTransform(700.3,260.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#D6D4D5").ss(3,1,1).p("AEYwhI1FRBMAhbAQC");
	this.shape_49.setTransform(578.9,321.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#D6D4D5").ss(3,1,1).p("A04p7MApxAT3");
	this.shape_50.setTransform(630.4,368.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#D6D4D5").ss(3,1,1).p("A7Rs+MA2iAZ8");
	this.shape_51.setTransform(614.2,328.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#D6D4D5").ss(3,1,1).p("AChjLIkqDxQgaAVAEAhQAEAhAeAOICLBB");
	this.shape_52.setTransform(697.1,396.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#D6D4D5").ss(3,1,1).p("AC7iWIl1Et");
	this.shape_53.setTransform(718.7,354.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#D6D4D5").ss(3,1,1).p("AGklTItGKn");
	this.shape_54.setTransform(838.2,271);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#D6D4D5").ss(3,1,1).p("A6WoiIDEieQAagWAjgEQAigEAfAPMAvrAWr");
	this.shape_55.setTransform(645.6,318.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#D6D4D5").ss(3,1,1).p("ADxjCInhGF");
	this.shape_56.setTransform(640.5,262.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#D6D4D5").ss(3,1,1).p("AEFjSIoJGk");
	this.shape_57.setTransform(552.5,156.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#D6D4D5").ss(3,1,1).p("AGzlfItlK/");
	this.shape_58.setTransform(624.6,229.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#D6D4D5").ss(3,1,1).p("AxKN6MAiVgbz");
	this.shape_59.setTransform(795.8,338.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#D6D4D5").ss(3,1,1).p("AvKMSIeV4j");
	this.shape_60.setTransform(745.9,298);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#D6D4D5").ss(3,1,1).p("AtmLCIbN2C");
	this.shape_61.setTransform(674.7,309.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#D6D4D5").ss(3,1,1).p("AYCR9MgvngWqQgZgLgDgcQgDgbAVgRIOmr7");
	this.shape_62.setTransform(672.3,266.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44}]}).wait(1135));

	// Layer 1 copy 2
	this.instance = new lib.cloud3();
	this.instance.parent = this;
	this.instance.setTransform(333.4,248.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-796.4,y:200.1},773).to({_off:true},6).wait(356));

	// Layer 1
	this.instance_1 = new lib.cloud3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1603.7,208.1,1,1,0,0,0,29.4,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-108.2,y:200.1},773).to({_off:true},6).wait(356));

	// Layer 1 copy
	this.instance_2 = new lib.cloud1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(300).to({_off:false},0).to({x:-129.4,y:108.1},703).wait(132));

	// Layer 1 copy 3
	this.instance_3 = new lib.cloud1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:1099.5,y:101.6},141).to({x:-129.4,y:108.1},587).to({_off:true},66).wait(341));

	// Layer 1
	this.instance_4 = new lib.cloud1("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(1394.7,100.1,1,1,0,0,0,50.5,20.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:-129.4,y:108.1},728).to({_off:true},66).wait(341));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1003.3,378.5,1330.6,387.9);
// library properties:
lib.properties = {
	id: 'A0F2311E12414503AFA66E6A0996A419',
	width: 1400,
	height: 600,
	fps: 36,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A0F2311E12414503AFA66E6A0996A419'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;