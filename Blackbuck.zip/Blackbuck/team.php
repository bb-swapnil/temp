<?php $thisPage="team"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
    <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="products-banner">
          <p class="title">Driven by an incredible team</p>
        </div>
      </div>
    </section>

    <section class="section2">
      <div class="container">
        <div class="content">
          <p>Every person you meet here at BlackBuck is inimitable, from a curious business developer, to a designer who thinks out of the box, and from an engineer who always looks to push the boundaries, to a highly energetic set of leaders. Together, it is indeed an incredible team.
</p>
        </div>
      </div>
    </section>

    <section class="section3 teammembers">
      <div class="container">
        <ul class="member">
          <ul class="members">
            <li><img src="images/team/members/banner_web-14.jpg"></li>
            <li><img src="images/team/members/banner_web-15.jpg"></li>
            <li><img src="images/team/members/banner_web-16.jpg"></li>
            <li><img src="images/team/members/banner_web-17.jpg"></li>
<!--             <li  class="hover two"><img src="images/team/members/banner_web-17.jpg">
            <span class="flag"></span>
            <div class="details">
            <span class="team-close">X</span>
            <div class="inner">
            <figure>
              <img src="images/team/members/banner_web-17.jpg">
              </figure>
              <div class="titles">
              <h4>Shilpy</h4>
              <span class="designation">Head of products and Data Science</span>
              <a href="#"><img src="images/linkedin.png" alt=""></a>
              </div>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit, et. Deleniti odit voluptatum amet blanditiis laborum maxime aliquid nulla incidunt culpa porro temporibus esse, soluta reiciendis cumque quos animi voluptates.</p>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti perferendis obcaecati aut velit, veniam vitae quod blanditiis quae sunt, sapiente asperiores, alias eveniet laboriosam, atque quo at nam consectetur error?</p>
              </div>
            </div>


            </li> -->
            <li><img src="images/team/members/banner_web-18.jpg"></li>
            <li><img src="images/team/members/banner_web-19.jpg"></li>
            <li><img src="images/team/members/banner_web-20.jpg"></li>
            <li><img src="images/team/members/banner_web-21.jpg"></li>
            <li><img src="images/team/members/banner_web-22.jpg"></li>
            <li><img src="images/team/members/banner_web-23.jpg"></li>
            <li><img src="images/team/members/banner_web-24.jpg"></li>
            <li><img src="images/team/members/banner_web-25.jpg"></li>
            <li><img src="images/team/members/banner_web-26.jpg"></li>
            <li><img src="images/team/members/banner_web-27.jpg"></li>
            <li><img src="images/team/members/banner_web-28.jpg"></li>
           <!--  <li  class="hover one"><img src="images/team/members/banner_web-28.jpg">
            <span class="flag"></span>
            <div class="details">
            <span class="team-close">X</span>
            <div class="inner">
            <figure>
              <img src="images/team/members/banner_web-28.jpg">
              </figure>
              <div class="titles">
              <h4>Indraneel Bommisetty</h4>
              <span class="designation">Head of products and Data Science</span>
              <a href="#"><img src="images/linkedin.png" alt=""></a>
              </div>

              <p>Indra as he is fondly called as leads the team of Products and Data Sciences at BlackBuck. A specialist with over 10 years of experience in product management and software development, Indra is ever excited to solve open ended problems with his team of smart people. For Indra, BlackBuck is about making logistics more efficient through technology, thereby creating value for everyone.</p>
              <p>Indra has completed his B.Tech & M.Tech in Mechanical Engineering from IIT Kharagpur</p>
              </div>
            </div>

            </li> -->
            <li><img src="images/team/members/banner_web-29.jpg"></li>
            <li><img src="images/team/members/banner_web-30.jpg"></li>
            <li><img src="images/team/members/banner_web-31.jpg"></li>
            <li><img src="images/team/members/banner_web-32.jpg"></li>
            <li><img src="images/team/members/banner_web-33.jpg"></li>      
            <li><img src="images/team/more.jpg"></li>
          </ul>

        </ul>
      </div>
    </section>

<section class="view-positions">
  <div class="container">
    <div class="viewp">
      <div class="content">
      <p>Here’s the opportunity for you to be part of the incredible team</p>
      <a href="careers.php#positions" class="btn btn-viewpos">View Open Positions</a>
      </div>
    </div>
  </div>
</section>



    <!-- connect -->
    <?php include "partials/connect.php" ?>
    <?php include "partials/footer.php" ?>
  </body>
</html>