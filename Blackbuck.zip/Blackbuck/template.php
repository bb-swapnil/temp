<?php $thisPage=""; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
        <!-- section 1 -->
    <section class="section1">
      <?php @include "partials/page-header.php";  ?>
      <div class="container">
        <div class="banner-content">
          <p>Making freight simple and effective,using technology</p>
          <button class="btn-play"> Play video</button>
        </div>
      </div>
    </section>
    
    <!-- connect -->
    <?php include "partials/connect.php" ?>
    <?php include "partials/footer.php" ?>
    <div class="video">
      <span class="video-close"></span>
      <div class="play-video">
      </div>
    </div>
  </body>
</html>