<?php $thisPage="products-fleet_operators"; ?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <?php
    @include "partials/head.php"
    ?>
  </head>
  <body  class="<?php echo $thisPage ?>" >
    <?php include "partials/oldbrowser.php" ?>
      <!-- section 1 -->
  <section class="section1">
     <?php @include "partials/page-header.php";  ?>
     <div class="container">
        <div class="products-banner">
           <figure class="shadow">
             <img src="images/products/blackbuck_shippers_02.gif" alt="">
           </figure>
           <div class="txt">
              <p class="title">GUARANTEED LOADS ON PREFERRED ROUTES FOR <strong>FLEET OPERATORS</strong></p>
              <p class="downloadapp">
                 Download the BlackBuck – Trucker App
              </p>
              <a href="https://play.google.com/store/apps/details?id=in.zinka.androidclient" target="_blank" class="googleplay ">download google app</a>
           </div>
        </div>
     </div>
  </section>
      <!-- section 2 -->
  <section class="pro-details">
     <div class="container">
        <ul class="pro-details-tile">
           <li>
              <div class="thumbnail">
                 <figure><img src="images/products/icons-fleet1.svg" alt=""></figure>
                 <span class="caption">Daily Loads across India</span>
                 <span class="desc">Presence in over 300 locations to help you view and book loads every day, and at the right price</span>
              </div>
           </li>
           <li>
              <div class="thumbnail">
                 <figure><img src="images/products/icons-fleet2.svg" alt=""></figure>
                 <span class="caption">Fast Payment Settlements</span>
                 <span class="desc">Instant advance on trips and fast payment settlements for every single load</span>
              </div>
           </li>
           <li>
              <div class="thumbnail">
                 <figure><img src="images/products/icons-fleet3.svg" alt=""></figure>
                 <span class="caption">Ease of Operations</span>
                 <span class="desc">Fast loading and unloading by the operations team to ensure that your truck is constantly on the move</span>
              </div>
           </li>
           <li>
              <div class="thumbnail">
                 <figure><img src="images/products/icons-fleet4.svg" alt=""></figure>
                 <span class="caption">Quick Issue Resolution</span>
                 <span class="desc">Quick and effective resolution process for all in-transit issues so that your business never stops</span>
              </div>
           </li>
           <li>
              <div class="thumbnail">
                 <figure><img src="images/products/icons-fleet5.svg" alt=""></figure>
                 <span class="caption">Facilities for Drivers</span>
                 <span class="desc">Dhaba network in major locations with facilities for drivers</span>
              </div>
           </li>
           <li>
              <div class="thumbnail">
                 <figure><img src="images/products/icons-fleet6.svg" alt=""></figure>
                 <span class="caption">Assured Savings</span>
                 <span class="desc">Attractive discounts on Fuel cards, Toll tags and Cash cards</span>
              </div>
           </li>
        </ul>
     </div>
  </section>

<section class="testimony-container"> 
  <section class="section5 testimonials">
    <h2>Testimonials</h2>
    <div class="container">
      <ul class="bxslider testimony">
        <li>
     
          <p>My experience with BlackBuck has been wonderful. Their services are excellent which has made me to attach 30 trucks with them. I really liked the promptness of their payment system.</p>
          <p>

            <span class="person">Mahesh Bairagi </span>
            <span class="company">Bhaishnav Motor, Rajasthan</span>
          </p>
        </li>
        <li>
        
         <p>BlackBuck has a great team and they are with you at every step. My business moves faster and more easily just in few clicks when I use the BlackBuck app.</p>
          <p>
  
            <span class="person">Tarsem Singh</span>
            <span class="company">Joshan Roadlines - Punjab</span>
          </p>
        </li>
        <li>
       
        <p>My trucks are able to make more trips and earn more. Very professional company and every process is transparent. I am happy to have attached my trucks with BlackBuck.</p>
          <p>

            <span class="person">Mohammed Ilias Khan</span>
            <span class="company">Sonu Transport, Rajasthan</span>
          </p>
        </li>
        <li>
          <p>I have attached 150 of my trucks with BlackBuck and have done more than 200 loads till date from Kandla to Haryana. I have never had any issue and I’m happy that my business has grown.</p>
            <span class="person">Dharmendar Dhaiya</span>
            <span class="company">JSSRG, Haryana</span>
        </li>
        <li>
          <p>The BlackBuck app makes the entire transaction hassle free. Improved tracking, immediate payments makes business move in a very simple manner. The number of trips has significantly increased too.</p>
          <span class="person">Siddharth Goutham</span>
          <span class="company">Millenium Cargo Carriers, Delhi-Chennai-Pune-Bangalore-Hosur</span>
        </li>
                       
      </ul>
    </div>
  </section>
  </section>

<!-- connect -->

<section class="section7 connect">
  <div class="container">
    <div class="content">
      <span class="blackbuck-logo"><img src="images/blackbuck-icon.svg" alt=""></span>
      <div class="connect-options">
      <p>Attach your truck with BlackBuck today!</p>
      <div class="buttons">
       <a href="tel:+ 917676955555" class="btn"><i class="fa fa-phone" aria-hidden="true"></i>  + 91 76769 55555</a>
          <a href="mailto:sales@blackbuck.com" class="btn"><i class="fa fa-envelope-o" aria-hidden="true"></i> sales@blackbuck.com</a>
        </div>
       <a href="https://play.google.com/store/apps/details?id=in.zinka.androidclient" target="_blank" class="googleplay ">download google app</a>
      </div>
      <nav>
        <ul class="foolinks">
          <li><a href="about.php">About</a></li>
          <li><a href="career.php">Career</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="signin.php">Sign in</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
            <ul class="social">
              <li><a href="https://www.facebook.com/blackbucklogistics/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/company-beta/10152397/" taret="_blank" > <i class="fa fa-linkedin" aria-hidden="true"></i> </a></li>
              <li><a href="https://www.youtube.com/channel/UCbyL5ThNIRgDQdB45s6CBMQ/videos" target="_blank" ><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
    </div>
  </div>
</section>


<?php include "partials/footer.php" ?>
</body>
</html>